SpaceFleet playtest build
=========================
Build 1130a7a (built 2026-11-22)

How to start
------------
1. Unzip/extract the whole archive into a normal folder first (do not run it from inside the archive).
   Any folder will do. Keep the folder; it is where the game updates itself.
2. Double-click  Play-SpaceFleet.cmd  .
   You do NOT need to install .NET, git or anything else: the game is all in this folder.
3. The launcher checks for a newer build, downloads it if there is one (showing what is new),
   and then starts the game. From now on, always start the game with  Play-SpaceFleet.cmd :
   that is how it keeps itself up to date. You never have to download the archive again.
   If you are offline, or the update does not work, it just starts the build you already have.

"Windows protected your PC" (SmartScreen)
-----------------------------------------
The game is not code-signed (it is a private playtest build), so Windows may show a blue
"Windows protected your PC" window the first time. That is expected. Click "More info", then
"Run anyway". If your browser or Explorer says the zip is blocked, right-click the zip, choose
Properties and tick "Unblock" before unzipping. Updates that the game downloads for itself
are not blocked like that.

How to play
-----------
Open PLAYING.md (in this folder, any text editor) for the goal, the first ten minutes and
the full list of controls. In the game, the pause menu is Esc and the key list is under
Controls in the main menu.

Your saves and settings
-----------------------
They are kept outside this folder, so updating, deleting or moving the game folder never loses them:
  %APPDATA%\SpaceFleet   (paste that into the Windows Explorer address bar)
The game autosaves every few minutes and when you quit. F5 quicksaves, F8 loads it.

Where things are in this folder
-------------------------------
  Play-SpaceFleet.cmd   the thing to start
  launcher             the launcher's own files (launcher.log says what it did last time)
  versions             the game builds: the one you play and the one before it
  To remove the game: delete this whole folder.

Sending feedback
----------------
Please tell the person who sent you this build, in any way you like:
  - what you were doing and what you expected,
  - what happened instead (a screenshot helps a lot),
  - the build number above (1130a7a), and the version stamp at the bottom-left of the main menu,
  - for a crash or a freeze: the newest autosave from the Saves folder inside  %APPDATA%\SpaceFleet
    (if you are happy to send it: it lets the exact situation be reloaded).
What was fun, what was confusing and where you got stuck are the most useful things.

Mods
----
The Mods screen in the main menu lists the example mods that come with the game. They are
off until you switch them on there.
