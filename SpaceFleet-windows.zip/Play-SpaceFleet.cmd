@echo off
rem ============================================================================================================
rem  SpaceFleet launcher for Windows. Double-click this file to play.
rem
rem  1. Make a new, empty folder (for example Documents\SpaceFleet) and put this file in it.
rem  2. Double-click Play-SpaceFleet.cmd. If Windows says "Windows protected your PC", click "More info", then
rem     "Run anyway" (the launcher is not code-signed).
rem  3. The first start downloads the newest game build (about 50 MB) into this folder and starts it. Every later
rem     start checks for a newer build first; offline it starts the build you have. Nothing else needs installing.
rem
rem  Your saves and settings are in %APPDATA%\SpaceFleet (outside this folder), so updates never touch them.
rem  To report a problem: say what happened and give the build number (shown while the launcher starts and at the
rem  bottom-left of the main menu). The launcher's log is launcher\launcher.log in this folder.
rem
rem  How it works: the launcher itself (PowerShell) is the text after the marker line at the end of this file. It is
rem  written to launcher\SpaceFleetLauncher.ps1 on every start and run from there. The game is the file
rem  SpaceFleet-windows.zip on https://github.com/StarkBotha/spacefleet-releases (no login needed); it is downloaded again only
rem  when that file changed (its ETag differs from the one in current-download.txt).
rem ============================================================================================================
setlocal
set "SF_CMD=%~f0"
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -Command "$c=$env:SF_CMD; $s=$c; $n=$c+'.new'; if ((Test-Path -LiteralPath $n) -and [IO.File]::ReadAllText($n).Contains('##SF'+'PS1##')) { $s=$n }; $t=[IO.File]::ReadAllText($s); $i=$t.IndexOf('##SF'+'PS1##'); $t=$t.Substring($t.IndexOf([char]10,$i)+1); $d=Join-Path (Split-Path -Parent $c) 'launcher'; [void][IO.Directory]::CreateDirectory($d); $p=Join-Path $d 'SpaceFleetLauncher.ps1'; [IO.File]::WriteAllText($p,$t); & $p -LauncherCmd $c; exit $LASTEXITCODE"
exit /b
##SFPS1##
# SpaceFleet self-updating launcher (Windows PowerShell 5.1). This text is embedded at the end of Play-SpaceFleet.cmd,
# which writes it to launcher\SpaceFleetLauncher.ps1 on every start and runs it with -LauncherCmd <path of the .cmd>.
# Source: tools/release/launcher-win/ in the game's repo; tools/release/build-launchers.sh makes the .cmd.
#
# Layout of the install folder (the folder that holds Play-SpaceFleet.cmd):
#   Play-SpaceFleet.cmd                         the launcher (a newer one is staged as Play-SpaceFleet.cmd.new)
#   launcher\SpaceFleetLauncher.ps1, launcher.log, (optional) launcher.json
#   versions\<tag>\SpaceFleet.Game.exe ...      one folder per installed build (the current one and the previous one)
#   current.txt, previous.txt                   the tags of those two builds
#   .dl\                                  temporary files of an update in progress (always safe to delete)
# Everything this script creates or deletes is inside that folder. Saves and settings live in %APPDATA%\SpaceFleet
# and are never touched.
#
# Test override (not needed by players): environment variable SPACEFLEET_RAW_BASE, the address that holds
# SpaceFleet-windows.zip (default https://github.com/<owner>/<repo>/raw/main). launcher\launcher.json may set "owner" / "repo".
param([string]$LauncherCmd)

$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class SfNative { [DllImport("user32.dll")] public static extern bool SetProcessDPIAware(); }
'@
try { [void][SfNative]::SetProcessDPIAware() } catch { }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Net.Http
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch { }
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$script:LauncherDir = $PSScriptRoot
$script:Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
$script:VersionsDir = Join-Path $script:Root 'versions'
$script:DownloadDir = Join-Path $script:Root '.dl'
$script:LogPath = Join-Path $script:LauncherDir 'launcher.log'
$script:ExeName = 'SpaceFleet.Game.exe'
$script:Ell = [string][char]0x2026
$script:Cancel = $false
$script:PlayNow = $false

# ---------------------------------------------------------------- log

function Write-Log([string]$Message) {
    try {
        $line = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $Message + "`r`n"
        [IO.File]::AppendAllText($script:LogPath, $line)
    } catch { }
}

try {
    if ((Test-Path -LiteralPath $script:LogPath) -and ((Get-Item -LiteralPath $script:LogPath).Length -gt 200000)) {
        Remove-Item -LiteralPath $script:LogPath -Force
    }
} catch { }

# ---------------------------------------------------------------- file safety

function Test-ValidTag([string]$Tag) {
    return ($Tag -match '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$')
}

# True when $Path is strictly inside $Base (both full paths). The only paths this script ever deletes are
# inside <install>\versions or <install>\.dl, and every deletion goes through Remove-InsideInstall.
function Test-StrictlyInside([string]$Path, [string]$Base) {
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    $b = [IO.Path]::GetFullPath($Base).TrimEnd('\')
    return $full.StartsWith($b + '\', [StringComparison]::OrdinalIgnoreCase)
}

function Remove-InsideInstall([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $true }
    $isDl = ([IO.Path]::GetFullPath($Path).TrimEnd([char]92) -ieq $script:DownloadDir)
    $ok = $isDl -or (Test-StrictlyInside $Path $script:VersionsDir) -or (Test-StrictlyInside $Path $script:DownloadDir)
    if (-not $ok) { Write-Log "REFUSED to delete outside the install folder: $Path"; return $false }
    try {
        if ((Get-Item -LiteralPath $Path -Force).PSIsContainer) { [IO.Directory]::Delete($Path, $true) }
        else { [IO.File]::Delete($Path) }
        return $true
    } catch {
        Write-Log "Could not delete $Path ($($_.Exception.Message))"
        return $false
    }
}

# A running game keeps its exe open, so this is false while the build is in use.
function Test-FolderFree([string]$Dir) {
    $exe = Join-Path $Dir $script:ExeName
    if (-not (Test-Path -LiteralPath $exe)) { return $true }
    try {
        $fs = [IO.File]::Open($exe, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $fs.Close()
        return $true
    } catch { return $false }
}

function Write-TextFile([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($false)))
}

function Read-Tag([string]$Name) {
    $p = Join-Path $script:Root $Name
    if (-not (Test-Path -LiteralPath $p)) { return $null }
    try { $t = ([IO.File]::ReadAllText($p)).Trim() } catch { return $null }
    if (-not (Test-ValidTag $t)) { return $null }
    if (-not (Test-Path -LiteralPath (Join-Path (Join-Path $script:VersionsDir $t) $script:ExeName))) { return $null }
    return $t
}

function Get-InstalledTag {
    $t = Read-Tag 'current.txt'
    if ($t) { return $t }
    return (Read-Tag 'previous.txt')
}

# ---------------------------------------------------------------- finish an earlier launcher self-update

function Get-LauncherCmdPath {
    if ($LauncherCmd) { return [IO.Path]::GetFullPath($LauncherCmd) }
    return (Join-Path $script:Root 'Play-SpaceFleet.cmd')
}

function Complete-SelfUpdate {
    # A new launcher arrives inside a game build and is staged as "<launcher>.new". For Play-SpaceFleet.cmd the .cmd
    # already ran from the .new text this start, so the swap is only a file rename. SpaceFleet-Launcher.exe swaps
    # itself (a running exe cannot be overwritten), so nothing is done here for an .exe.
    $cmd = Get-LauncherCmdPath
    if ($cmd -match '\.exe$') { return }
    $new = $cmd + '.new'
    if (Test-Path -LiteralPath $new) {
        for ($i = 0; $i -lt 5; $i++) {
            try {
                Move-Item -LiteralPath $new -Destination $cmd -Force
                Write-Log ('Installed the new ' + (Split-Path $cmd -Leaf))
                break
            } catch { Start-Sleep -Milliseconds 400 }
        }
    }
}

# ---------------------------------------------------------------- UI

$script:Sf = 1.0
try {
    $g = [Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    $script:Sf = [double]$g.DpiX / 96.0
    $g.Dispose()
} catch { $script:Sf = 1.0 }
function S([double]$n) { return [int][Math]::Round($n * $script:Sf) }

$form = New-Object Windows.Forms.Form
$form.Text = 'SpaceFleet'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object Drawing.Font('Segoe UI', 9)
$form.ShowInTaskbar = $true

$lblTitle = New-Object Windows.Forms.Label
$lblTitle.Text = 'SpaceFleet'
$lblTitle.Font = New-Object Drawing.Font('Segoe UI', 15, [Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $false
$lblTitle.Location = New-Object Drawing.Point((S 18), (S 12))
$lblTitle.Size = New-Object Drawing.Size((S 444), (S 32))

$lblStatus = New-Object Windows.Forms.Label
$lblStatus.AutoSize = $false
$lblStatus.Location = New-Object Drawing.Point((S 18), (S 48))
$lblStatus.Size = New-Object Drawing.Size((S 444), (S 40))
$lblStatus.Text = 'Checking for updates' + $script:Ell

$bar = New-Object Windows.Forms.ProgressBar
$bar.Location = New-Object Drawing.Point((S 18), (S 94))
$bar.Size = New-Object Drawing.Size((S 444), (S 18))
$bar.Style = 'Marquee'
$bar.MarqueeAnimationSpeed = 30
$bar.Minimum = 0
$bar.Maximum = 1000

$lblDetail = New-Object Windows.Forms.Label
$lblDetail.AutoSize = $false
$lblDetail.Location = New-Object Drawing.Point((S 18), (S 116))
$lblDetail.Size = New-Object Drawing.Size((S 444), (S 20))
$lblDetail.ForeColor = [Drawing.Color]::DimGray

$lblNotes = New-Object Windows.Forms.Label
$lblNotes.Text = "What's new"
$lblNotes.Font = New-Object Drawing.Font('Segoe UI', 9, [Drawing.FontStyle]::Bold)
$lblNotes.AutoSize = $false
$lblNotes.Location = New-Object Drawing.Point((S 18), (S 142))
$lblNotes.Size = New-Object Drawing.Size((S 444), (S 20))
$lblNotes.Visible = $false

$txtNotes = New-Object Windows.Forms.TextBox
$txtNotes.Multiline = $true
$txtNotes.ReadOnly = $true
$txtNotes.ScrollBars = 'Vertical'
$txtNotes.BackColor = [Drawing.Color]::White
$txtNotes.Location = New-Object Drawing.Point((S 18), (S 164))
$txtNotes.Size = New-Object Drawing.Size((S 444), (S 130))
$txtNotes.Visible = $false

$btnPlay = New-Object Windows.Forms.Button
$btnPlay.Text = 'Play now without updating'
$btnPlay.Size = New-Object Drawing.Size((S 190), (S 30))
$btnPlay.Enabled = $false

$btnCancel = New-Object Windows.Forms.Button
$btnCancel.Text = 'Cancel'
$btnCancel.Size = New-Object Drawing.Size((S 100), (S 30))

$form.Controls.AddRange(@($lblTitle, $lblStatus, $bar, $lblDetail, $lblNotes, $txtNotes, $btnPlay, $btnCancel))

function Set-Layout([bool]$WithNotes) {
    if ($WithNotes) {
        $lblNotes.Visible = $true
        $txtNotes.Visible = $true
        $y = 308
    } else {
        $lblNotes.Visible = $false
        $txtNotes.Visible = $false
        $y = 150
    }
    $btnPlay.Location = New-Object Drawing.Point((S 18), (S $y))
    $btnCancel.Location = New-Object Drawing.Point((S (462 - 100)), (S $y))
    $form.ClientSize = New-Object Drawing.Size((S 480), (S ($y + 46)))
}

$btnPlay.Add_Click({ $script:PlayNow = $true })
$btnCancel.Add_Click({ $script:Cancel = $true })
$form.Add_FormClosing({ $script:Cancel = $true })

function Pump([int]$Ms = 15) {
    [Windows.Forms.Application]::DoEvents()
    if ($Ms -gt 0) { Start-Sleep -Milliseconds $Ms }
}

function Set-Status([string]$Text) { $lblStatus.Text = $Text; Pump 0 }
function Set-Detail([string]$Text) { $lblDetail.Text = $Text; Pump 0 }
function Set-Progress([double]$Fraction) {
    if ($bar.Style -ne 'Continuous') { $bar.Style = 'Continuous' }
    $v = [int][Math]::Round($Fraction * 1000)
    if ($v -lt 0) { $v = 0 }
    if ($v -gt 1000) { $v = 1000 }
    $bar.Value = $v
}
function Set-Marquee { $bar.Style = 'Marquee'; $bar.MarqueeAnimationSpeed = 30 }

function Test-Abort { return ($script:Cancel -or $script:PlayNow) }

# ---------------------------------------------------------------- network

$script:Http = New-Object Net.Http.HttpClient
$script:Http.Timeout = [TimeSpan]::FromMilliseconds(-1)

function New-Request([string]$Url, [string]$Accept, [string]$Method = 'GET') {
    $req = New-Object Net.Http.HttpRequestMessage((New-Object Net.Http.HttpMethod($Method)), $Url)
    [void]$req.Headers.TryAddWithoutValidation('User-Agent', 'SpaceFleetLauncher')
    if ($Accept) { [void]$req.Headers.TryAddWithoutValidation('Accept', $Accept) }
    return $req
}

function Wait-Task($Task, [int]$TimeoutSec) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while (-not $Task.IsCompleted) {
        Pump 15
        if (Test-Abort) { throw 'USER_ABORT' }
        if ($TimeoutSec -gt 0 -and $sw.Elapsed.TotalSeconds -gt $TimeoutSec) { throw 'the server did not answer in time' }
    }
    if ($Task.IsFaulted) { throw $Task.Exception.GetBaseException() }
    if ($Task.IsCanceled) { throw 'the request was cancelled' }
}

function Get-Url([string]$Url, [string]$Accept, [string]$Method = 'GET') {
    $t = $script:Http.SendAsync((New-Request $Url $Accept $Method), [Net.Http.HttpCompletionOption]::ResponseHeadersRead)
    Wait-Task $t 30
    $resp = $t.Result
    $code = [int]$resp.StatusCode
    if ($code -lt 200 -or $code -ge 300) {
        $resp.Dispose()
        throw "HTTP $code"
    }
    return $resp
}

# The identity of the file the server holds now: its ETag (GitHub's raw files carry one that changes with the
# content), else its size. Nothing else is needed: no login, no API, no extra file in the repo.
function Get-RemoteId($Resp) {
    if ($Resp.Headers.ETag -and $Resp.Headers.ETag.Tag) { return ('etag:' + $Resp.Headers.ETag.Tag.Trim('"')) }
    if ($Resp.Content.Headers.ContentLength) { return ('size:' + [string]$Resp.Content.Headers.ContentLength) }
    return $null
}

function Get-Config {
    # The public repo: the zip and the launchers are plain files on its main branch.
    $cfg = @{ owner = 'StarkBotha'; repo = 'spacefleet-releases' }   # @public-repo@ (set by build-launchers.sh)
    $p = Join-Path $script:LauncherDir 'launcher.json'
    if (Test-Path -LiteralPath $p) {
        try {
            $j = [IO.File]::ReadAllText($p) | ConvertFrom-Json
            if ($j.owner) { $cfg.owner = [string]$j.owner }
            if ($j.repo) { $cfg.repo = [string]$j.repo }
        } catch { Write-Log "launcher.json is not valid JSON ($($_.Exception.Message)); using defaults" }
    }
    if ($cfg.owner -notmatch '^[A-Za-z0-9._-]+$' -or $cfg.repo -notmatch '^[A-Za-z0-9._-]+$') { throw 'launcher.json has an invalid owner or repo' }
    $cfg.rawBase = 'https://github.com/' + $cfg.owner + '/' + $cfg.repo + '/raw/main'
    if ($env:SPACEFLEET_RAW_BASE) { $cfg.rawBase = $env:SPACEFLEET_RAW_BASE }   # tests: a local stand-in
    $cfg.rawBase = $cfg.rawBase.TrimEnd('/')
    return $cfg
}

function Format-Mb([double]$Bytes) { return ('{0:N1}' -f ($Bytes / 1MB)) }

function Receive-File([string]$Url, [string]$Dest, [bool]$ShowProgress) {
    $resp = Get-Url $Url $null
    $out = $null
    try {
        $total = [double]0
        if ($resp.Content.Headers.ContentLength) { $total = [double]$resp.Content.Headers.ContentLength }
        $id = Get-RemoteId $resp
        $st = $resp.Content.ReadAsStreamAsync()
        Wait-Task $st 30
        $in = $st.Result
        $out = [IO.File]::Create($Dest)
        $buf = New-Object byte[] 262144
        $got = [double]0
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $last = [Diagnostics.Stopwatch]::StartNew()
        while ($true) {
            $rt = $in.ReadAsync($buf, 0, $buf.Length)
            Wait-Task $rt 60
            $n = $rt.Result
            if ($n -le 0) { break }
            $out.Write($buf, 0, $n)
            $got += $n
            if ($ShowProgress -and $last.ElapsedMilliseconds -gt 100) {
                $last.Restart()
                if ($total -gt 0) { Set-Progress ($got / $total) }
                $rate = 0
                if ($sw.Elapsed.TotalSeconds -gt 0.5) { $rate = $got / $sw.Elapsed.TotalSeconds }
                $line = (Format-Mb $got) + ' of ' + (Format-Mb $total) + ' MB'
                if ($rate -gt 0) { $line += '   (' + (Format-Mb $rate) + ' MB/s)' }
                Set-Detail $line
            } elseif ($last.ElapsedMilliseconds -gt 100) { $last.Restart(); Pump 0 }
        }
        return @{ Size = [long]$got; Total = [long]$total; Id = $id }
    } finally {
        if ($out) { $out.Close() }
        $resp.Dispose()
    }
}

function Expand-ZipSafely([string]$ZipPath, [string]$Dest) {
    $destFull = [IO.Path]::GetFullPath($Dest).TrimEnd('\')
    [void][IO.Directory]::CreateDirectory($destFull)
    $zip = [IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $count = $zip.Entries.Count
        $i = 0
        foreach ($e in $zip.Entries) {
            $i++
            $target = [IO.Path]::GetFullPath((Join-Path $destFull $e.FullName))
            if (-not $target.StartsWith($destFull + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'the download contains an unsafe path' }
            if ($e.FullName.EndsWith('/') -or $e.FullName.EndsWith('\')) {
                [void][IO.Directory]::CreateDirectory($target)
            } else {
                [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
                [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
            }
            if (($i % 15) -eq 0) {
                Set-Progress ($i / $count)
                Set-Detail ("Unpacking $i of $count files")
                if (Test-Abort) { throw 'USER_ABORT' }
            }
        }
    } finally { $zip.Dispose() }
}

# ---------------------------------------------------------------- update

function Remove-OldVersions([string]$Current, [string]$Previous) {
    if (-not (Test-Path -LiteralPath $script:VersionsDir)) { return }
    foreach ($d in (Get-ChildItem -LiteralPath $script:VersionsDir -Directory -Force)) {
        if ($d.Name -eq $Current -or $d.Name -eq $Previous) { continue }
        if (-not (Test-FolderFree $d.FullName)) {
            Write-Log "Old build $($d.Name) is in use; it will be cleaned up next time"
            continue
        }
        if (Remove-InsideInstall $d.FullName) { Write-Log "Removed old build $($d.Name)" }
    }
}

function Install-SelfUpdate([string]$PackageRoot) {
    # New launcher: the build carries SpaceFleet-Launcher.exe and Play-SpaceFleet.cmd. The one matching the launcher
    # that started this script is staged as "<launcher>.new" when it differs (used from the next start). For the .cmd,
    # its embedded PowerShell part must parse; for the .exe, it must at least be a Windows program ("MZ").
    $cmd = Get-LauncherCmdPath
    if ($cmd -match '\.exe$') {
        $srcExe = Join-Path $PackageRoot 'SpaceFleet-Launcher.exe'
        if (Test-Path -LiteralPath $srcExe) {
            $newBytes = [IO.File]::ReadAllBytes($srcExe)
            $same = $false
            if (Test-Path -LiteralPath $cmd) {
                $oldBytes = [IO.File]::ReadAllBytes($cmd)
                $same = ($oldBytes.Length -eq $newBytes.Length) -and ([Convert]::ToBase64String($oldBytes) -eq [Convert]::ToBase64String($newBytes))
            }
            if ($same) { }
            elseif ($newBytes.Length -lt 1024 -or $newBytes[0] -ne 0x4D -or $newBytes[1] -ne 0x5A) { Write-Log 'The new launcher is not a Windows program; kept the old one' }
            else {
                [IO.File]::WriteAllBytes($cmd + '.new', $newBytes)
                Write-Log 'Staged a new launcher (active next start)'
            }
        }
    } else {
    $srcCmd = Join-Path $PackageRoot 'Play-SpaceFleet.cmd'
    if (Test-Path -LiteralPath $srcCmd) {
        $cmd = Get-LauncherCmdPath
        $newText = [IO.File]::ReadAllText($srcCmd)
        $oldText = ''
        if (Test-Path -LiteralPath $cmd) { $oldText = [IO.File]::ReadAllText($cmd) }
        $i = $newText.IndexOf('##SF' + 'PS1##')
        if ($newText -eq $oldText) { }
        elseif ($i -lt 0) { Write-Log 'The new launcher has no embedded script; kept the old one' }
        else {
            $ps = $newText.Substring($newText.IndexOf([char]10, $i) + 1)
            $tokens = $null; $errs = $null
            [void][Management.Automation.Language.Parser]::ParseInput($ps, [ref]$tokens, [ref]$errs)
            if ($errs.Count -eq 0) {
                Copy-Item -LiteralPath $srcCmd -Destination ($cmd + '.new') -Force
                Write-Log 'Staged a new launcher (active next start)'
            } else { Write-Log 'The new launcher script did not parse; kept the old one' }
        }
    }
    }
    foreach ($n in @('README-FIRST.txt', 'PLAYING.md')) {
        $s = Join-Path $PackageRoot $n
        if (Test-Path -LiteralPath $s) { try { Copy-Item -LiteralPath $s -Destination (Join-Path $script:Root $n) -Force } catch { } }
    }
}

# The download that made the current build ("etag:..." or "size:..."), kept in current-download.txt.
function Read-DownloadId {
    $p = Join-Path $script:Root 'current-download.txt'
    if (-not (Test-Path -LiteralPath $p)) { return $null }
    try { return ([IO.File]::ReadAllText($p)).Trim() } catch { return $null }
}

# Returns the tag now installed (the new one on success). Throws 'USER_ABORT' or an error message otherwise.
function Update-Game([string]$Installed) {
    $cfg = Get-Config
    $url = $cfg.rawBase + '/SpaceFleet-windows.zip'
    Write-Log "Checking $url"
    $head = Get-Url $url $null 'HEAD'
    $remoteId = Get-RemoteId $head
    $head.Dispose()
    $haveId = Read-DownloadId
    Write-Log "Server: $remoteId; installed: $Installed from $haveId"
    if ($Installed -and $remoteId -and ($remoteId -eq $haveId)) {
        try { Remove-OldVersions $Installed (Read-Tag 'previous.txt') } catch { Write-Log "Cleanup failed: $($_.Exception.Message)" }
        return $Installed
    }

    $heading = 'Downloading SpaceFleet'
    if ($Installed) { $heading = 'A new build is available   (you have ' + $Installed + ')' }
    Set-Layout $false
    $btnPlay.Enabled = [bool]$Installed
    Set-Progress 0

    if (-not (Remove-InsideInstall $script:DownloadDir)) { Write-Log 'Could not clear .dl' }
    [void][IO.Directory]::CreateDirectory($script:DownloadDir)
    $part = Join-Path $script:DownloadDir 'SpaceFleet-windows.zip.part'
    Set-Status ($heading + "`r`nDownloading" + $script:Ell)
    $r = Receive-File $url $part $true
    Write-Log "Downloaded $($r.Size) bytes ($($r.Id))"
    if ($r.Size -le 0) { throw 'the download did not arrive (0 bytes)' }
    if ($r.Total -gt 0 -and $r.Size -ne $r.Total) { throw "the download is incomplete ($($r.Size) of $($r.Total) bytes)" }

    Set-Status ('Unpacking' + $script:Ell)
    Set-Marquee
    $ex = Join-Path $script:DownloadDir 'u'
    try { Expand-ZipSafely $part $ex } catch {
        if ($_.Exception.Message -eq 'USER_ABORT') { throw }
        throw ('the download is damaged (' + $_.Exception.Message + ')')
    }
    [void](Remove-InsideInstall $part)

    # The build's tag comes from inside the archive: current.txt next to versions\<tag>\SpaceFleet.Game.exe.
    $pkg = $null; $tag = $null
    $candidates = @($ex) + @(Get-ChildItem -LiteralPath $ex -Directory | ForEach-Object { $_.FullName })
    foreach ($c in $candidates) {
        $t = $null
        $cf = Join-Path $c 'current.txt'
        if (Test-Path -LiteralPath $cf) { $t = ([IO.File]::ReadAllText($cf)).Trim() }
        if ($t -and (Test-ValidTag $t) -and (Test-Path -LiteralPath (Join-Path $c ("versions\$t\" + $script:ExeName)))) { $pkg = $c; $tag = $t; break }
    }
    if (-not $pkg) { throw 'the download does not contain the game' }
    Write-Log "The download holds build $tag"

    if ($Installed -and ($tag -ieq $Installed)) {
        Write-Log "Build $tag is already installed"
    } else {
        Set-Status ('Installing build ' + $tag + $script:Ell)
        [void][IO.Directory]::CreateDirectory($script:VersionsDir)
        $dst = Join-Path $script:VersionsDir $tag
        if (Test-Path -LiteralPath $dst) {
            if (-not (Remove-InsideInstall $dst)) { throw "build $tag is already there and in use" }
        }
        [IO.Directory]::Move((Join-Path $pkg "versions\$tag"), $dst)
        if (-not (Test-Path -LiteralPath (Join-Path $dst $script:ExeName))) { throw 'the new build did not install' }
        if ($Installed) { Write-TextFile (Join-Path $script:Root 'previous.txt') $Installed }
        $tmpCur = Join-Path $script:Root 'current.txt.tmp'
        Write-TextFile $tmpCur $tag
        Move-Item -LiteralPath $tmpCur -Destination (Join-Path $script:Root 'current.txt') -Force
        Write-Log "Switched to build $tag"
    }
    if ($r.Id) { Write-TextFile (Join-Path $script:Root 'current-download.txt') $r.Id }

    try { Install-SelfUpdate $pkg } catch { Write-Log "Self-update step failed: $($_.Exception.Message)" }
    [void](Remove-InsideInstall $script:DownloadDir)
    try { Remove-OldVersions $tag $Installed } catch { Write-Log "Cleanup failed: $($_.Exception.Message)" }
    return $tag
}

# ---------------------------------------------------------------- main

function Get-Reason($Err) {
    $m = ''
    if ($Err -is [Exception]) { $m = $Err.Message } else { $m = [string]$Err }
    if ($m -match '^HTTP 403' -or $m -match '^HTTP 429') { return 'GitHub is limiting requests right now, try again later' }
    if ($m -match '^HTTP 404') { return 'no build has been published yet' }
    if ($m -match 'remote name could not be resolved|No such host|actively refused|An error occurred while sending the request|Unable to connect|No connection|timed out|did not answer') { return 'no internet connection' }
    return $m.TrimEnd('.')
}

function Start-Game([string]$Tag) {
    $dir = Join-Path $script:VersionsDir $Tag
    $exe = Join-Path $dir $script:ExeName
    $p = Start-Process -FilePath $exe -WorkingDirectory $dir -PassThru
    Write-Log "Started SpaceFleet build $Tag (process id $($p.Id))"
}

$mutexName = 'Local\SpaceFleetLauncher_' + (([BitConverter]::ToString([Security.Cryptography.MD5]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($script:Root.ToLowerInvariant())))).Replace('-', ''))
$createdNew = $false
$mutex = New-Object Threading.Mutex($false, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
    Write-Log 'Another launcher is already running for this folder; exiting'
    exit 0
}

Write-Log ('---- launcher started (' + (Get-LauncherCmdPath) + ')')
$exitCode = 0
try {
    Start-Sleep -Milliseconds 100
    Complete-SelfUpdate
    Set-Layout $false
    $form.Show()
    $form.Activate()
    Pump 0

    $installed = Get-InstalledTag
    $btnPlay.Enabled = [bool]$installed
    if (-not $installed) { $btnPlay.Enabled = $false }

    $note = $null
    $startTag = $installed
    try {
        $startTag = Update-Game $installed
        if ($startTag -ne $installed) {
            Set-Layout $false
            Set-Status ('Updated to build ' + $startTag + '. Starting SpaceFleet' + $script:Ell)
            Set-Progress 1
            Set-Detail ''
            Pump 0
        }
    } catch {
        $err = $_
        $isAbort = ($err.Exception.Message -eq 'USER_ABORT')
        if (-not $isAbort) {
            $reason = Get-Reason $err.Exception
            Write-Log "Update failed: $($err.Exception.Message)"
            $note = "Could not update ($reason)."
        } else { Write-Log ("Update stopped by the player (" + $(if ($script:Cancel) { 'cancel' } else { 'play now' }) + ')') }
        [void](Remove-InsideInstall $script:DownloadDir)
        $startTag = Get-InstalledTag
    }

    if ($script:Cancel) {
        Write-Log 'Cancelled by the player; the game was not started'
    } elseif ($startTag) {
        Set-Layout $false
        $btnPlay.Enabled = $false
        Set-Progress 1
        Set-Detail ''
        if ($note) {
            Set-Status ($note + ' Starting build ' + $startTag + ' instead.')
            Pump 0
            Start-Sleep -Milliseconds 2500
        } elseif ($startTag -eq $installed -and -not $script:PlayNow) {
            Set-Status ('SpaceFleet is up to date (build ' + $startTag + '). Starting' + $script:Ell)
        } else {
            Set-Status ('Starting SpaceFleet build ' + $startTag + $script:Ell)
        }
        Pump 0
        Start-Game $startTag
        Start-Sleep -Milliseconds 400
    } else {
        if (-not $note) { $note = 'Could not find an installed version.' }
        Set-Layout $false
        Set-Marquee
        $bar.Style = 'Continuous'; $bar.Value = 0
        $lblStatus.Height = (S 44)
        Set-Status ($note + ' The game is not installed in this folder yet: connect to the internet and try again.')
        Set-Detail ''
        $btnPlay.Visible = $false
        $btnCancel.Text = 'Close'
        $script:Cancel = $false
        $form.Add_FormClosing({ })
        while (-not $script:Cancel) { Pump 30 }
        $exitCode = 1
    }
} catch {
    Write-Log ("Launcher error: " + $_.Exception.Message + ' ' + $_.ScriptStackTrace)
    try {
        $fallback = Get-InstalledTag
        if ($fallback -and -not $script:Cancel) { Start-Game $fallback }
    } catch { }
    $exitCode = 1
} finally {
    try { $form.Dispose() } catch { }
    try { $script:Http.Dispose() } catch { }
    try { $mutex.ReleaseMutex() } catch { }
}
exit $exitCode
