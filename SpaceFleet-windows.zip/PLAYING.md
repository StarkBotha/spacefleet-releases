# How to play SpaceFleet

SpaceFleet is a real-time strategy game about one faction among several in a big 2D star system. You run stations,
mine and trade, build and design ships, command fleets and deal with your neighbours. Everyone else is played by the
AI, and the world keeps going whether you act or not.

This page is the player's guide. For making mods see [MODDING.md](MODDING.md); for how save files work inside see
[SAVES.md](SAVES.md).

## Installing and updating

- **Linux, from the repository:** `tools/launcher/spacefleet-launcher.sh --install` adds SpaceFleet to the
  application menu. Since 2026-11-19 it no longer builds the game: it runs the same launcher friends use
  (`play-spacefleet.sh`, kept in `~/.local/share/spacefleet-launcher/public`), which downloads the newest published
  build, always with the developer tools (`--dev`). If that cannot start a game, the build it compiled before starts.
- **Friends on Windows (a link from the owner):** download **`SpaceFleet-Launcher.msi`** and double-click it. It
  installs for you only (no administrator password) and adds **SpaceFleet** to the Start menu. Start SpaceFleet from
  there: the first start downloads the game (about 50 MB) into `%LOCALAPPDATA%\SpaceFleet`, every later start checks
  for a newer build first, and offline it starts the build you have. The installer is not code-signed, so Windows says
  "Windows protected your PC": click **More info**, then **Run anyway**. To remove it: Settings, Apps, Installed apps,
  SpaceFleet, Uninstall (the downloaded game and your saves stay; delete `%LOCALAPPDATA%\SpaceFleet` to remove the game).
- **Friends on Linux:** on Ubuntu / Debian install **`spacefleet-launcher.deb`** (`sudo apt install
  ./spacefleet-launcher.deb`, then SpaceFleet is in the app menu), or download **`play-spacefleet.sh`**, put it in a
  new, empty folder and run `bash play-spacefleet.sh` in a terminal there. The first start downloads the game (about
  50 MB) and starts it; nothing else needs installing (no .NET, no git). Every later start checks for a newer build,
  downloads it if there is one and then starts the game; if you are offline or the update fails it just starts the
  build you already have. Always start the game this way: that is how it stays up to date.
- Your saves and settings are kept outside the game folder (`%APPDATA%\SpaceFleet` on Windows, `~/.config/SpaceFleet`
  on Linux), so updating or deleting the game never touches them.

## The goal

- **You win** when every other faction has been eliminated. Allies count too: if everyone left is your ally, the game
  goes on until you break an alliance and finish them (owner ruling: no "allied victory").
- **You lose** when your faction is eliminated, which happens when you have no station left (ships alone do not
  keep you in the game).
- A faction that loses its last station is out. You can eliminate a rival by destroying every one of its stations.
- When the game is decided, the game-over screen shows the final standings. You can **keep watching** (the world
  keeps running) or start a **new game**.
- Along the way the **objectives** guide you and pay credits for each step. The long-term ones (hold three
  stations, field twelve warships, eliminate a rival, top the standings) are a good measure of how you are doing.
- The **standings** score counts your stations, ships, kills, credits and the alliances you hold.

## Starting a game

- **New game** on the main menu opens the setup page.
- **Every new game is a different galaxy.** The page opens on the **Random galaxy** world with a fresh random
  **seed**: the factions are drawn anew (some familiar archetypes, some never seen before) and they start at
  random places across the map. **New seed** deals another galaxy. Each faction's row says in a few words what
  it is like ("Warlike and treacherous - a raider", "Peaceful and mercantile - a trader").
- **Fair starts:** the factions always include at least one warlike and one trading faction, and no trader starts
  with a raider as its nearest neighbour.
- **Universe size:** the **Universe** button cycles Small, Standard, Large, Huge and Massive. A new game opens on
  **Standard**, a large galaxy about 324,000 units across (nine times the area of Small, the compact galaxy of
  earlier versions) with wormholes and pirates to match. Bigger steps are wider and hold a little more rock (about
  100 asteroids for every step of width: Small 100, Standard 300, Massive 600), so travel is longer, the fields are
  further apart and wormholes matter more; Huge and Massive say "may run slowly" (they need a fast machine). The line
  beside the button says how wide the world is and how many asteroids it holds. Worlds with a fixed size (the
  classic ring world, or starts placed on a ring) show the button switched off and say why.
- **Factions: N** (with **-** and **+**) sets how many factions a drawn cast has (2 to 12). Each size suggests a
  count (Standard 8, Large 10, Huge and Massive 12); change it after picking the size. The classic cast is always
  its own list: add or remove rows instead.
- **Replaying a map:** the seed is shown on the setup page and in the pause menu. Type it into the Seed box (with
  the same settings) to play the same galaxy again, or pass it to a friend.
- **Factions:** "Random mix" (the default), "All new factions", or "Classic factions" (the world's fixed cast).
  **Starting places:** "Scattered (fair)" (the default) or "On a ring" (then "Distance apart" sets the ring).
  The **Standard** world is the classic one: the six archetypes on a ring.
- **Tick the box on a faction's row to play as it.** With no box ticked you only watch the AI factions play; the
  button at the bottom says which it will be ("Play as Iron Dominion" or "Watch the AI play").
- **Pick your colour.** Once a faction's box is ticked, a row of colour swatches ("Your colour") appears above the
  list, the current one marked with a white frame. Click one to play in it. Another faction that would have had that
  colour takes a different free one, so no two factions share a colour; red is not offered (red is the pirates'). The
  colour you pick is remembered as the default for your next new game.
- **Asteroids box, Asteroids button and Ore per asteroid** all say what the galaxy really gets, and the line under
  them adds it up ("300 asteroids, about 1,590 ore each: about 477,000 ore in the galaxy."). The same count is on the
  Universe size line and in the summary at the top.
  - The **Asteroids box** is the real number of asteroids on the map, the starters' own rocks included. Type a number
    and the galaxy has exactly that many (the same seed and the same number give the same galaxy). It goes from 0 to
    100,000, but never lower than the starter rocks every faction gets (two each): a lower number is lifted to that,
    and a number too small for every start to have a home field (about ten rocks a faction) turns the line orange and
    says some factions will starve early.
  - **Asteroids: Scarce / Normal / Plentiful** (the button beside the box) sets how much rock the galaxy holds and
    fills the box and the slider. **Normal** is the default: a Standard galaxy has about 300 asteroids of about 1,600
    ore each (the starters' rocks hold a little more) - enough to grow on, not enough for everyone forever.
    **Scarce** has fewer, poorer rocks (180 and about 1,300 ore at Standard: the fields run dry early and the wars over
    them come soon); **Plentiful** more, richer ones (450 and about 2,000). Your home field and starter rocks are the
    same whichever you pick.
  - **Ore per asteroid** is the average ore in a rock, all its picks together. Move the slider and every rock holds
    that much on average (rocks still differ: a few hold several times the average).
  - **Choosing Universe size or the Asteroids button always refills the box and the slider** from that step. A number
    you typed (or a slider you moved) stays until you next touch one of those two buttons or pick another world, and
    the button then reads **Asteroids: Custom**.
- **Rocks and ores...** (the **Rock layout** row) opens the **ROCKS AND ORES** window: where the asteroids lie and how
  common each ore is. The line beside the button says what is set ("Clustering 50% (the world's own); every ore as
  common as usual."). It turns orange when something could not be done as asked.
  - **Clustering** says how strongly the rocks gather. **50%** is the world's own layout. Lower spreads the rocks out:
    at **0%** every rock is scattered evenly over the map, apart from your starter rocks and your home field. Higher
    gathers them: at **100%** they all lie in a quarter as many fields, each half the size (a few dense fields).
  - **The numbers behind it** start from the world you picked (and its universe size and Asteroids setting). You can set
    each one yourself: **Random fields** (how many), **Smallest / Largest field radius**, **Other rocks in fields (%)**
    (of the rocks that are not starter rocks or home fields, how many lie in fields; the rest are scattered),
    **Fewest rocks in a field**, **Fields keep apart**, **Fields keep from starts**, and for every start's home field
    **Rocks in each home field**, **Home field, nearest / farthest** (from your station) and **Home field radius**.
    Each row shows the world's own value; a number you set stays until you move the Clustering again (for the four
    numbers Clustering drives) or reset.
  - **How common each ore is**: a weight for every ore, starting from the game's own (Iron 4, Aluminium 3, Copper, Uranium and Ice 2,
    the others 1), and the share of the rocks' picks it gives. Set a weight to **0** and that ore is in no rock's random picks.
    That includes your two **starter rocks**: they hold whatever ores they draw, like any other rock, so a start may
    have no Iron close by (the owner, 2026-11-19, on the old guarantee: "that is the bullshit rule. drop it"). At least
    one ore must keep a weight above 0.
  - The **map** on the left shows the layout: your starts (cyan), the random fields, the home fields (green), the starter
    rocks (orange) and the scattered rocks (grey). The fields and starts are exactly the galaxy you will get; the single
    dots are only a sample of where its rocks lie.
  - When the galaxy cannot be built as asked (no room to keep the fields that far from the starts or from each other,
    not enough rocks for the home fields or the fewest rocks in a field, a home field pulled in from the edge of the
    map), the window says so in orange under the map. The galaxy is still built: the fields go where there is room.
  - Only the **Random galaxy** and **The Expanse** with scattered starts have fields to lay out; the classic
    **Standard** ring spreads its rocks evenly, and the window says so (the ore weights still work there).
  - **Reset to the world's own** puts both parts back. Your settings stay while you change the rest of the page, go
    back to the main menu and return, or start the game, and they are saved with your game.
- The **Pirates** button shows its level; the line at the top says how many bands that means ("pirates: normal (up to
  6 bands at once)").
- **Gas clouds: None / Few / Normal / Many** (the **Gas clouds** row, under Rock layout) sets how many gas clouds the galaxy
  has; the line beside the button says the number ("9 gas clouds."), and the summary line at the top says it too.
  **Normal** is the default (the world as it is made: about nine at Standard). **Few** is about half as many, **Many**
  twice as many, and **None** none at all: no gas to collect anywhere. The setting is kept with your save. Every map
  type of the base game has gas clouds, on a ring too. A map type made without clouds (a mod's) greys the button ("No gas
  clouds") and the line says which map types have them.
- **Pace** (the slider under Gas clouds) sets how fast the economy and conflict run in this game, in whole steps. The left
  end is **pace 10, the shipped pace (slowest)**; each step to the right is faster, up to **pace 1** at the right end: ten
  times faster, the old pace. The line beside it says what the step means ("Pace 5: 2 times faster than the shipped pace").
  One slider moves both paces together (see "The pace of the economy" and "The pace of conflict" below): building,
  factories, mining, research, people and money, and pirates, wars, truces and diplomacy. Ships still fly, fight, dock and
  load at full speed at every pace. The slider starts on the content's pace (the shipped 10, or a mod's), and a game
  started without touching it is exactly the game you would get without the slider. The pace is kept with your save and
  holds for every faction, AI or player; every new game starts the slider back on the content's pace.
- **AI CEOs' cut** (the row under Universe size): the share of each station's profit every other faction's CEO is paid, with
  **-** and **+** (1% a step), and the button beside it says where it is taken from: **from the faction's share**, **off
  the top of the profit** (before the station, manager and faction shares), or **from the station's share**. The line after
  it shows the split that gives, for example "station 50 / manager 10 / faction 35 / CEO 5". It starts at 0% and is
  kept with the game.
- **What CEOs may steer** (the row under it): four switches for how every other faction's CEO steers its fleets.
  **Ware goals send scouts** (a ware it needs makes it explore more, to find someone who makes or sells it), **Ware goals
  aim raiders** (its raiders go for ships carrying that ware; off at the start, because it starts fights), **Character
  tilts goals** (a curious CEO explores more, a caring one holds back to defend, an outward-looking one raids more) and
  **Grow the fighting fleet** (at war, or when a faction it distrusts has more warships, it builds more warships). Kept
  with the game.
- **Starting kit** says what every faction (you and the AI alike) starts with:
  - **Standard start**: a main station (3 Medium docking bays, a Small yard, holds, a repair bay, a gun, a shield and a
    lab) and a supply station with the basic factories nearby; 2,000 credits; a Scout, two Miners and a Courier.
  - **Bare base**: the station's hub with one Small docking bay, one Small Cargo Hold and a Small shipyard; one
    **Small Miner** and one Scout. No other modules, no second station. The same 2,000 credits as the
    Standard start, and only as much stock as the one Small Cargo Hold holds (1,200 units: the hold starts full). A
    miner unloads only into holds below 90% full, so your miner's first load waits until the station has used some
    stock (building a ship or a module uses it) or a second hold is built; its activity line says so meanwhile.
  - The kit window warns when a kit's stock is more than its starting holds take ("Stock 1,254, room for 1,200: ...");
    the game still starts.
  - **Edit kit...** (beside the picker) opens the **STARTING KIT** window, where you change what every faction starts
    with. The kit you picked fills it in. You can change:
    - **Credits**;
    - **Docking bays**: their size (the **Size** button cycles Tiny to Huge) and how many;
    - **Shipyard**: none, or a size (the **Yard** button cycles them);
    - **Station modules** besides the bays and the yard: pick one in **Add a module**, choose its size with the
      **Size** button and press **Add**; each module line has its own size, a count and **Remove**;
    - **More starting stations** besides the main one: pick a station type in **Add a station** and press **Add**;
      each line has a count, its distance from the main station and **Remove**;
    - **Starting ships**: a number for every ship design. A design marked **(needs research)** is one your factions
      could not build yet; you can still start with it;
    - **Starting stock**: a number for every ware and ore at the main station (scroll down the list).
  - Every number has **-** and **+** buttons and a box you can type in. Numbers cannot go below 0.
  - **Reset to the kit** puts back what the picked kit gives. **Done** closes the window; your changes stay while you
    change the rest of the page, go back to the main menu and return, or start the game. The button reads **Kit
    edited...** while the kit differs from the one you picked. Picking another kit in the picker starts again from it.
  - The changed kit is saved with your game.
  - A station keeps materials only in **Cargo Holds**. A kit without holds still starts with its stock, but nothing
    more can be stored there until you build a hold. A ship that cannot unload says why on its activity line ("flying
    to Kestrel Reach to sell 75 cargo, but Kestrel Reach's holds are full (1200 / 1200)", "... no dock large enough at
    Kestrel Reach (needs a Medium dock)", "... has no cargo hold, so it can store nothing").
- You can add, remove and rename factions, and open a faction's row to set its personality (militarism, commerce,
  expansionism, honour). The **Personality** dropdown at the top of the opened row is a quick way in: pick
  **Measured**, **Warlord**, **Peaceful Trader** and so on (or any of the standard factions' cultures) and the four
  sliders jump to that style; then tune them as you like. The dropdown shows **Custom** as soon as the sliders match
  no preset. It works for every faction on the page, the one you play included.

## The first ten minutes

The objective chip (under the top bar, **O** opens the full list) walks you through this. Each step pays credits.
Building takes real time (a Corvette about eight minutes, a Miner or a Medium yard about ten minutes at normal
speed), so queue the next thing while you wait, or speed time up. The whole economy runs at this slower pace
(see **The pace of the economy** below).

1. **Take the helm.** Your station starts selected; the inspector on the right shows its stock and its drawers.
   Press **Space** to pause and resume and **,** / **.** to slow down or speed up time.
2. **Build a warship.** In the inspector's **Build** drawer press **Build Ships** and click the Corvette. Your
   starting yard is Small, so it builds Small hulls only.
3. **Upgrade your shipyard.** In the Build drawer press **Buy Modules** and pick **Medium** in the size row and click the
   Ship Yard. You can buy a yard of any size directly (bigger sizes need research first).
4. **Build a miner.** Miners are Medium hulls, so they need the Medium yard. Miners bring ore home, and that is
   where most of your credits come from.
5. **Create a fleet.** Drag a box around some of your ships and press **G**.
6. **Set a rally point.** Click your station (or press **Tab**) to select it on its own, then right-click in
   space. New ships from that station gather there.
7. **Research a technology.** Press **T** (or the **Research** button at the bottom left), click
   **Outpost Construction** and press **Queue**. Your stations earn research points all the time.
8. **Build a constructor and found an outpost.** Select the constructor, press **F** and left-click a free spot.
   Stations must be well apart (6,000 units in the base game) and not on an asteroid; the banner at the top says
   why a spot is refused.
9. **Open the Market (F2)** and **set a trade policy** in your station's **Trade** drawer.
10. **Meet your neighbours (F1)** and **win a battle** - destroy three enemy ships or stations.

## Controls

**Every key can be rebound** on the **Controls** screen (main menu, pause menu or Settings). Your bindings are
saved in `keybindings.json` (see [Where things are kept](#where-things-are-kept)). The table below lists the
default keys.

**Mouse**

- **Left-click** selects a ship or a station; **double-click** a ship to follow it with the camera - or press the
  **Follow** button in the right dock's action row (it then reads **Stop following**; with several ships selected it
  follows the fleet's flagship, or the first ship). Panning or clicking elsewhere stops
  following too. A ship parked on
  a station is picked only when you click right on the ship; otherwise you get the station. **Click again at the
  same spot** (not a quick double-click) to pick the next thing stacked there, round and round.
- **Zoomed out, a click on a station always selects the station** - not one of its modules or docking bays, and not a
  ship docked, parked or flying over it. This applies below the Close zoom band (the minimap header reads anything but
  "Close - ship detail", where ships are icons). Zoom in to pick a module, a bay or a ship on the station; drag a box
  or use the tray to reach a ship near a station while zoomed out.
- **Zoomed out, every asteroid you know of is a small asterisk** (eight arms and a thin dark outline, so it never
  reads as a star): a surveyed rock in its ore colour, a rock you have only spotted in a warm tan. Rocks that are
  nearly mined out are dropped, and at whole-map zoom a dense field is thinned a little. An asterisk can be clicked
  and right-clicked ("mine this") like the rock; a ship, station or portal under the cursor still wins. Rocks you
  do not know of are not drawn.
- **Blue lines in the inspector are links.** Click a ship's home station, the station it is docked at, its target or
  its fleet to jump there and select it; click a module (a ship's loadout, a station's guns, shield, scanner or built
  modules) to open the **Module window**: a picture, what it does in plain words and its full specs. Esc or Close
  shuts it.
- **Left-drag** draws a box that selects every one of your ships inside it.
- **Shift + left-click** adds a ship to the selection or takes it out (in space and in the Empire list).
- **Right-click** gives an order to the selected ships: move to a point, attack an enemy, mine an asteroid,
  salvage a wreck or cargo pod, escort a friendly ship, travel through a wormhole or jump gate, or (on one of your
  stations) make it their home. **Damaged ships right-clicked onto one of your stations - or an ally's - dock there
  and stay until they are fully repaired** ("Dock and repair"); then their next queued order runs. With only your
  station selected, right-click sets its rally point. **Right-click a station of a faction you are at war with, or a
  pirate hideout, to attack it**: your armed ships go in, unarmed ones fly alongside.
- **Hovering a wormhole or gate** shows what a right-click would do: "Right-click: travel through Wormhole (leads to
  unknown space)", where it leads once you know, the toll, or why it is closed to you.
- **Hovering anything else with ships selected** does the same: "Right-click: help build Kestrel Reach site",
  "deliver cargo to ...", "salvage the wreck of a Corvette", "dock and repair at Cinder Station", "trade at Port
  Coin", "mine Asteroid #12", "attack Corvette #9", "escort Miner #3" - or why not ("no tractor beam", "no mining
  laser aboard"). The inspector of a selected ship lists every right-click action it is fitted for.
- **Shift + right-click adds a waypoint** instead of replacing the order (see [Waypoints](#waypoints)).
- **Right-drag** pans the camera; the **mouse wheel** zooms.
- **What you see up close:** a ship shows what it is fitted with - its guns, engines, holds, drills and dishes sit
  on the hull where they are mounted, so a laser frigate looks different from a cannon frigate - and its owner's
  colour is painted on the hull's stripes and panels. A station's blocks show their colour the same way. Zoom out
  and ships become their role icons as before.
- **Minimap:** click or drag to move the camera, right-click to send the selection there; click the zoom line above
  it to jump between the usual view, the strategic view and the whole map.

**Control groups:** hold **Ctrl** and press a digit to store the selection; press the digit to select it again,
twice to centre the camera on it.

**Speed:** `,` and `.` step through 0.25x, 0.5x, 1x, 2x, 4x, 8x and 16x. The top bar shows the speed you chose
("4x"). When your computer cannot run the world that fast, a small amber note follows it ("running at 2.5x"): the
world is going as fast as the machine allows. Hover the speed to see why; a smaller universe or fewer factions runs
faster.

<!-- The tables below are checked by a test (ControlsDocTests): every GameAction, with its default keys. -->
CONTROLS-TABLE-START

**Simulation**

| Action | Default key |
|---|---|
| Pause / resume | `Space` |
| Slower | `,` |
| Faster | `.` |
| Quicksave | `F5` |
| Quickload | `F8` |
| Send this game to the developer | `Ctrl+F12` |

**Camera**

| Action | Default key |
|---|---|
| Pan up | `W` or `Up` |
| Pan down | `S` or `Down` |
| Pan left | `A` or `Left` |
| Pan right | `D` or `Right` |
| Reset camera | `R` |
| Next own station | `Tab` |
| Next known wormhole or jump gate | `K` |

**Fleet orders**

| Action | Default key |
|---|---|
| Hold position | `H` |
| Clear orders | `X` |
| Return home | `B` |
| Found station (constructor) | `F` |
| Found defence platform (constructor) | `L` |
| Build jump gate (constructor) | `J` |
| Turn the station block you are placing | `E` |
| Transfer cargo between your stations (cargo ship) | `C` |
| Fire the afterburners of the selected ships | `N` |
| Create fleet from selection | `G` |
| Cycle the fleet's stance | `V` |
| Standing order of the fleet (choose; finish a patrol route) | `U` |
| Queue a waypoint (hold + right-click) | `LeftShift` or `RightShift` |
| Attack-move (hold + right-click) | `LeftAlt` or `RightAlt` |
| Add patrol point (hold + right-click) | `P` |

**Screens**

| Action | Default key |
|---|---|
| Diplomacy | `F1` |
| Market | `F2` |
| Ship Designer | `F6` |
| Research | `T` |
| Reference (what everything is for) | `F7` |
| Ore survey (what the known rocks hold) | `Y` |
| Fleets panel | `F4` |
| Objectives list | `O` |

**Manual control**

| Action | Default key |
|---|---|
| Manual control on / off (selected ships) | `M` |

**Selection**

| Action | Default key |
|---|---|
| Add to selection (hold) | `LeftShift` or `RightShift` |
| Assign control group (hold) | `LeftControl` or `RightControl` |
| Control group 1 | `1` |
| Control group 2 | `2` |
| Control group 3 | `3` |
| Control group 4 | `4` |
| Control group 5 | `5` |
| Control group 6 | `6` |
| Control group 7 | `7` |
| Control group 8 | `8` |
| Control group 9 | `9` |
| Control group 0 | `0` |

**Window and debug**

| Action | Default key |
|---|---|
| Menu | `Escape` |
| Debug view | `F3` |
| Dev tools (when Developer cheats are on) | `` ` `` |
| Borderless fullscreen | `F11` or `Alt+Enter` |
| Next resolution | `F10` |
| Exclusive fullscreen | `F9` |

CONTROLS-TABLE-END

- **Escape** closes the screen or panel on top first (a dialog, the Diplomacy / Market / Designer screens, the
  build gallery, the objectives list, the Fleets panel, station placement, a selected station block); with nothing
  open it opens the pause menu.
- **Manual control** keeps a ship from doing anything on its own. The selection dock's **Manual control: Off / On**
  button (key **M**) switches it for the selected ship - or for every selected ship, or a whole fleet (it then reads
  "Manual control: 2 of 5" when only some are; a click turns them all on, and a second click all off). It stays on
  until you switch it off: selecting other things, giving orders, docking, repairs, saving and loading change
  nothing. Any number of your ships can be under manual control at once.
  - A ship under manual control **never acts on its own**: no mining, trading, patrolling or repair trips its crew
    would choose. It does exactly what you last told it and then **holds** where it is.
  - You order it like any other ship: select it and **right-click** (move, attack, mine, salvage, dock, travel
    through a wormhole ...), use **H** / **X** / **B**, waypoints, **Found station (F)**, **Build jump gate (J)**,
    a refit, a Market trade run, a cargo transfer, a repair order. It carries the order out, then holds again -
    still under manual control.
  - While it holds it **answers fire**: it shoots back at whoever hit it, if that ship is within its guns' reach
    (it does not chase). In a fleet it follows the fleet's orders, and its stance: **Aggressive** also fires at
    any enemy ship in reach, **Passive** never fires.
  - A standing order (Auto-Mine, Protect ...) still runs on it, because you gave it; clearing the order leaves it
    holding.
  - Ships under manual control have a double cyan ring on the map, "manual" after their name in the Empire list
    and on the tray cards, and their own **Manual** filter chip in the Empire list, where **Release all** switches
    every one of them back to its crew.

## The screen

- **Top bar** (the whole width): **pause**, **slower** and **faster** with their keys, the game speed and the game
  clock (and the frame rate when Settings shows it); the screen buttons with their keys - **Diplomacy** (an amber
  "1 offer" badge while an offer waits), **Market**, **Fleets**, **Designer**, **Research** (what is being researched,
  a progress bar and the time left; amber "idle - pick one" when nothing is) and **Objectives**; then **Credits** (your pool) with
  your income per minute (green, or red when you are losing money), a red **At war** button when you are at war
  (it opens the Empire dock's Wars tab), **Alerts** with a count of the alarms since you last looked (click: jump to
  the latest) and **Menu** (**Esc**). On a narrow window the key labels go first, then the research name, then Designer, **Rules** and
  Objectives move into a **More** drop-down (click it to reach them). Watching
  without a faction (or with the debug view on) the bar names who you are viewing.
- **Under the top bar:** your materials as chips with their ore colour (with a station of several selected, its own
  amount in brackets), then your ship and station counts. What does not fit goes into a **+N** chip that lists
  the rest. Below them, the **objective chip**: the current step, its reward and **List** (**O**); click the chip to
  open what to do and the next steps (and **Hide**).
- **Left: the Empire dock**, the full height of the window, with four tabs:
  - **Empire** - everything you own in one list: **Stations** (with a site's progress, and a +N badge for builds in
    the yard and queue), **Fleets** (click the arrow at the right of a fleet to open it and see its ships, the
    flagship first) and **Ships**. Each row has a coloured mark (yellow for stations, red for warships, orange for
    miners, green for traders, blue for scouts), the name, a second line saying what it is doing right now ("Mining
    Asteroid #1567 60/100", "Waiting for a berth (2nd)", "Repairing - 40 s left") and a hull bar. The second line
    turns amber when the unit is damaged or away repairing, red while it is under attack.
    - **Click** a row to select it (a fleet row selects the whole fleet and opens it). **Shift + click** adds a ship
      to the selection or takes it out. **Double-click** also centres the map on it.
    - **Search** finds by name or type ("cor" finds every Corvette). The **filter chips** carry counts: All, War,
      Mining, Trade, Damaged (hull under 75%), Idle and **Manual** (ships under manual control; a ship under manual
      control also has a small "manual" after its name). With the Manual chip on, **Release all** at the bottom
      switches manual control off for all of them. **Sort** (bottom right) orders each group by type, name,
      hull (worst first) or newest.
    - The list scrolls with the mouse wheel or a click on its scroll bar, however many ships you have; the selected
      row has a cyan edge and is scrolled into view. "Showing 9 of 68" at the bottom says how many rows are in view.
  - **Factions** - the viewed faction's sheet: relations (only the factions you have met; the rest are one line,
    "3 factions not yet met"), research ("Now: Heavy Hulls 40%", how long it has left, what is next, how many
    technologies it knows and **View tech tree**, which opens the Research screen on that faction's tree), values,
    behaviour, economy, stations and fleet. At the foot: **View as** (the faction legend - in a game you play it
    stays on your own faction unless the debug view is on) and the **scanner rings** switch. Watching with nothing
    or **All** picked, the tab asks you to pick a faction under View as.
  - **Wars** - every war you know of listed once, grouped under the faction fighting the most of them ("Iron
    Dominion vs Free Traders, Solar Concord", or "No wars"), then the alliances and any truces. Click a line to view
    that faction. Playing a faction, it lists only the factions you have met.
  - **Money** - your pool and where it came from and went, the profit split for all your stations (steps of 10%),
    automatic subsidy approval, and every station asking for or getting a subsidy with **Approve** / **Refuse** /
    **Cancel** (see Economy).
- **Small windows:** the Empire dock (left) and the inspector (right) each have a fold button (**«** / **>>**) in
  their top corner. A folded Empire dock leaves a narrow **rail** with your counts - Stations, Fleets, Ships,
  Damaged and War; click a count to open the dock on it (Damaged opens the Damaged filter, War the Wars tab), or
  **»** to open it. A folded inspector leaves a small **<< Inspector** tab. The game remembers your choice. The
  messages along the top (PAUSED, the placement line and its cost) stack between the
  side panels and wrap instead of running under them, and the objective chip stays one line while a station's
  name is under it.
- **Bottom right: the minimap box** - along its top, one line with the **zoom** ("Zoom 33% - Tactical": what the
  map draws at that level - **Close - ship detail**, **Tactical**, **Strategic - icons** or **Whole map**) and a bar
  with a tick at each band (click the line to jump between the usual view, the strategic view and the whole map).
  Under it the minimap, the whole width of the box (click or drag on it to move the camera, right-click it to send
  the selected ships there). It shows your stations and ships, your fleets as badges, the stations, wormholes,
  gates and links you know (and, in a modded regional world, faint circles for the regions you have found something
  in), a yellow ring around what
  you have selected and a red ping where the latest alert happened. The white frame is what the main view shows: it
  is always drawn whole inside the map - a small square when you are zoomed right in, the map's outline when the
  whole galaxy is in view. The camera cannot be panned more than an eighth of the screen past the edge of the
  galaxy. Along the bottom one row of **Layers** switches: **Rings** (the scanner rings), **Routes** (where the selected
  ships are going), **Names** (station and portal names), **Rocks** (the asteroids) and **Links** (the wormhole and
  gate links). All five fit at 1280 x 720 and above; if the interface is so large that they do not, the last ones
  sit behind a **+N** chip - click it to see the rest.
- **Right: the selection dock** (the inspector). A header in the owner's colour: the name (with **Rename** for your
  own station, gate or ship), what it is and whose ("Capital station - Golden Traders (you)"), and hull and shield bars. A ship's
  header also has one line (two when long) under that, above the bars, saying what it is doing right now with a named
  target and the purpose: "Flying to Port Lantern to buy 74 Steel", "Flying to (3000, 2000) on your move order",
  "Flying to Asteroid #332 to mine it", "Going to park off Ledger Yards, nothing to do", "Idle, nothing to do". It is the same
  text as the Empire list, it shows on every tab, and hovering a line that was cut shows the whole text. A fleet shows its
  order there; several loose ships show nothing.
  Then **tabs** - a station: **Info**, **Build**, **Trade**, **Defence**, **Docks**; a ship: **Orders**, **Info**,
  **Loadout**, **Refit**, **Cargo**; a fleet (all its ships selected): **Orders**, **Ships**, **Fleet**; several
  ships: **Orders**, **Ships**; a gate: **Info**, **Travel**, **Controls**; a site, a wreck, a rock: one tab. The
  drawers of before are inside the tabs (the Build drawer under Build, Standing Order under Orders ...). The action
  buttons sit in a row above the tabs' content, each with its key: **Manual control: Off / On** (**M**), **Follow**, **Transfer
  cargo** (**C**), **Found station**, **Build jump gate** (**J**), **Cancel construction**, **Clear waypoints**.
  - **A fleet's Fleet tab:** stance (Aggressive / Defensive / Passive) and formation (Wedge / Line) chips, its name
    and **Rename**, and **Disband fleet**. Its **Orders** tab: **Now** (what the fleet is doing), **Then** (its
    queued waypoints, numbered - Shift + right-click adds them), **Hold**, **Return home**, **Clear order**, **Remove
    all from fleet**, and **Warnings** in amber: a ship close to the hull at which its crew breaks off to go for
    repairs ("Cruiser #12 is at 35% hull. It will break off to repair at 30%.") and, when the fleet is ordered to
    attack a station, the **siege check** - whether the fleet is strong enough to break it at full repair, the same
    sum the AI uses before it sends a task force. For loose ships: **Create fleet** (**G**), **Add to current fleet**
    and **Remove from fleet**; and one line of the right-click orders.
- **Bottom left: News** - what happened to your faction, newest first, each line with the game time and a coloured
  dot; the chips filter it (**All**, **War**, **Economy**, **Diplomacy**) and the mouse wheel scrolls back through
  it. Click a line to read all of it: it opens in place, wrapped over as many lines as it needs, with its game time and a **Go to** button
  (jumps to its place; a diplomatic line opens Diplomacy). Click it again, click another line, or press **Esc** to close it. A line
  that is cut short shows a small arrow. Click the strip to open the panel with the latest line open. **Hide** folds it to a one-line strip
  with the latest line; **Open** brings it back. The **Alerts** count in the top bar counts the alarms among them.
  A line about something a station did names the faction, then the station: "Solar Concord, Cinder Station built a Corvette", "Solar Concord, Cinder Station finished an Armoury" (your own faction by its name, a rival the same; **Go to** takes you to that station). The other lines speak to you about your own faction: "You lost 3 ships near Kestrel Reach" (the ships lost in one fight share one line
  that counts up, and the same for the ships you destroy), "Your fleet "Strike" was destroyed", "Your Kestrel Reach
  is under attack" and "Your Kestrel Reach was destroyed".
- **Bottom middle: the selection tray** - pictures of what is selected. A fleet or several ships: a card per ship
  (its picture in your colour, name, what it is doing, hull and shield bars; amber while away repairing, red when
  badly damaged) - scroll with the arrows or the wheel, click a card to pick that ship out; the fleet's name, count,
  stance and formation and **Follow** on the left. One ship: a large picture with its role, hull size, bars and
  what it is doing, its speed, weapons, cargo, scanner range and home. A station: its picture, how many ships are
  docked, waiting for a berth and in the yard, then their cards and the builds in the yard ("Building - 25 s") and
  the queue ("Needs 29 Tungsten"). Nothing selected: no tray. **The line above the tray** says what a right-click
  would do where the pointer is ("Right-click: travel through Wormhole #12"), or what the tray is for.
- **Small windows:** below 1400 pixels wide the game starts with both docks folded to their rails and the news as
  its strip; on a wider window they open again. Unfold them yourself any time.
- **Station names:** every station has a name ("Kestrel Reach", "Port Halcyon", "Fort Anvil"), drawn at random to
  suit its owner (traders get ports and markets, warlike factions forts and citadels). On the map a station shows
  its name with its faction on a smaller line underneath; zoomed far out, one faction's stations that crowd
  together become one line, "Iron Dominion x3". **Rename one of your stations:** select it and press **Rename
  station** under the inspector's title, type the new name and press **Enter** (or OK); **Esc** (or Cancel) keeps
  the old name, and so does an empty box. A name is at most 32 characters and two stations cannot share one. While
  you type, the game's keys do nothing. Other factions' stations cannot be renamed. A rename shows in the feed
  ("Cinder Station is now called Kestrel Reach").
- **Jump gates have names too** ("Halcyon Gate", "Coin Passage"); rename one of yours the same way (**Rename gate**).
  A construction site says so on the map: "Kestrel Reach (site 42%)", "Halcyon Gate (site 42%)".
- **Rename one of your ships** the same way: select just that one ship and press **Rename** in the header of the
  selection dock. The dialog says **RENAME SHIP**; **Enter** (or OK) takes the name, **Esc** (or Cancel) or an empty box
  keeps the old one. A name is at most 32 characters, and two of your own ships cannot share one (another faction's
  ship may have the same name). While you type, the game's keys do nothing. Other factions' ships cannot be renamed,
  and neither can several ships at once. The new name replaces "Corvette #3072" everywhere the ship is named: the
  Empire list on the left, the selection dock, the tray card, fleet lists, orders, the feed and the advisor's lines. It
  is saved with the game and stays through refits, repairs, docking and moving between fleets. A rename shows in the
  feed ("Small Miner #12 is now called Lucky Star"). Ships have no name on the map itself.
- **Crowded names:** zoomed far out, a faction's stations close together read "Iron Dominion x3"; put the mouse on
  the cluster (or select one of its stations) and the names are spelled out.
- **Typing:** while any text box has the keyboard (a fleet's name, a station's name, a save's name ...), the
  one-key shortcuts (C, G, J ...) do nothing, so the letters go into the box.
- You only see what your ships, stations and scanner buoys can see, **and what your allies' can see**. Space none of
  them reach is in the **fog of war**: the map is shaded darker there (the minimap too). Other factions' ships and
  stations are only shown outside the fog; a station you charted earlier stays on the map as you last saw it, shaded.
  **F3** (debug view) lifts the fog, for testing.
- **Territory:** the map is split into small hex tiles (2,000 across). Each faction's territory is drawn as **one
  outline in its colour** around all of its tiles; inside the fog the outline shows fainter. Who holds a tile:
  - A tile your station's or defence platform's **guns** reach is yours, whatever else reaches it.
  - Otherwise each faction adds up its **scanners** that reach the tile: a station or outpost counts 1, a defence
    platform counts half. The biggest total holds the tile.
  - Two factions' guns on one tile, or an exact tie, make the tile **contested**: it is nobody's and gets a faint
    grey edge.
  - Ships, scanner buoys and pirate hideouts claim nothing. Only finished stations claim.
  - You only see the territory of factions you have **met**, and a faction's territory is worked out only from the
    stations of theirs you have **charted**: a station you never found claims nothing on your map.
  - **What owning a tile does:** foreign ships seen on your tiles cause **border friction** (you think less of their
    faction, which can become a cause for war), and **your airspace rule applies on your tiles** (see
    [Airspace](#airspace)). The game itself works this out from every faction's real stations; what your map draws is
    still only what you know.
  - **Building into someone else's territory is an act of aggression.** When your station, outpost or defence platform
    is finished and another faction loses tiles it held (to you, or because they become contested), that faction holds
    it against you as soon as it finds the station: a grievance of the border-friction kind, bigger the more tiles it
    lost (0.005 opinion a tile, at most 0.2), a quarter of that between allies. How it reacts is up to its own values and
    its leader. The same goes for every faction, AI or you: if another faction builds into your tiles, the news tells you
    once you have found the station ("X built Y inside your territory"), and you are told when a faction finds one of
    yours. A faction that never finds the station holds nothing against the builder.
  - **Before you place a station,** the placement line warns you when it would take tiles from a faction you know
    ("Act of aggression: this takes 7 tiles from ..."), worked out from what you know. It is only a warning: you can
    still build there.
  - A faction's **Expansionism** no longer changes how much space it claims: every faction holds the tiles its stations
    claim.
  - **The AI weighs this too.** When an AI faction (or your Outposts automation) picks a site for an outpost or a
    defence platform, a site that would take tiles from a faction it knows counts for less, by its character: an
    honour-bound or mercantile faction, or one led by a warm CEO, mostly avoids it; an expansionist or militarist one,
    or one led by an outward-looking CEO, minds less; at war a militarist takes its enemy's tiles freely; and an
    opportunist that thinks a neighbour weak may take its tiles on purpose. It knows only the stations it has charted,
    so it can still build into your tiles by accident if it never found your station. A militarist also likes to put
    its defence platforms where they shore up its own contested or threatened border.

## Economy

**How money, wares and people fit together (the short version):**

- Every station has its **own account**. Your **pool** is your own funds as the head of the faction. The top bar shows the pool.
- **Ore is the only new money.** When a miner unloads ore at your station, new credits appear in that station's account.
- **Factories** turn ore into **wares** (metals, parts, components). Wares are what ships and modules are built from.
- **People** live on your stations and work its modules. The station pays them **wages**. They save the wages and
  **spend them at the station**: rent, food and medicine, and services from its amenities. That is income again.
- **Sister stations pay each other.** A supply run or a transfer between your own stations is paid for by the
  station that receives the goods. When it is short, the pool and then a levy on your other stations (see Faction
  orders) pay the rest, so supplies are not held back because the money sits at the station that sells them.
- **Upkeep is the only drain.** It is what your stations and crews cost to run. Credits paid as upkeep are gone.
- Every few minutes each station's **profit is split**: the station keeps a share, a share is paid to its manager,
  and the rest goes to your pool. You choose the shares.
- A station that cannot pay asks your pool for a **subsidy**. By default you approve them automatically.

**Food, medical, power (your people need supplies):**

- Each person **eats Food Rations** and **uses Medical Supplies** every minute.
- Every working module **burns Energy Cells** (a little per size step). Factories already burn them in their recipe.
- Fed and treated people **spend more** at the station: what they pay for food rides on how well they are fed, what
  they pay for medicine on how well they are treated.
- **Hungry people stop arriving and start to leave.** A module without power works at down to half speed.
- **What makes them:**
  - **Solar Array**: Energy Cells from nothing.
  - **Water Purifier**: Water from Ice (+ Energy Cells). Open from the start.
  - **Food Farm**: Food Rations from Water + Energy Cells.
  - **Pharma Lab**: Medical Supplies from Food Rations + Water (+ Energy Cells).
  - So feeding people needs **Ice**: a raw ore like Iron, mined by any miner with a drill. Most of it lies in **ice
    fields** further out (see "Field types"); any rock may hold some (about as much as Copper), but no start is promised any. The farms and
    labs themselves are built from Steel and Light Alloys.
- **You start with** about 15 minutes of food and medical supplies at each of your two stations, and your supply station
  holds some Ice. Build a Water Purifier, a Food Farm and a Pharma Lab early (the supply station is a good place), and
  send miners to Ice: pick Ice in a miner's Mining focus, or let your automation do it (with Auto-command fleet on it
  focuses miners on what your refineries are short of, Ice included). Ice is sold and bought on the market like any ore, and creates money when a
  station takes it in, like any ore.
- **Outposts** get theirs by supply runs from your other stations, like any material.

### Gas clouds and gas collectors

- **Gas clouds** are soft pink patches on the map, a few per galaxy (about nine at Standard; the New game page's Gas clouds setting changes that), mostly far from the
  starts; no start is promised one. You see a cloud once one of your scanners (a ship, a buoy or a station) reaches its
  edge; it is labelled "Hydrogen cloud (8,400)" with the gas left as you last saw it.
- **Hydrogen** is in clouds only. A **gas collector** (Small Gas Collector or Gas Collector; no research needed, built at
  a Small or Medium yard) carries a **gas scoop**: it flies into a cloud your faction has charted, scoops while it is
  inside, and when its hold is full it docks at your station to unload, like a miner. A drill cannot scoop and a scoop
  cannot drill. Any number of collectors may work one cloud.
- **Clouds run dry** like asteroids; they do not refill. An empty cloud is shown as empty in its inspector.
- **Inside a cloud scanners see less:** a ship or station inside a cloud that still holds gas sees only half its usual scanner range (every faction alike). Its scanner ring shrinks and says "(inside a gas cloud)", and so does the Scanner line of the ship tray and a station's Sensors line. It changes nothing else: ships in a cloud take no damage and are seen from outside as usual. An empty cloud does nothing.
- Hydrogen **creates money** when a station takes it in (1.5 Cr a unit), and it is bought, sold and hauled like any ore.
- The **Propellant Refinery** (open from the start) makes Propellant from Hydrogen and Energy Cells. Nothing uses
  Propellant yet.
- **Orders:** right-click inside a cloud with a collector selected: "Collect gas in Gas Cloud #N" (other selected
  ships move there). Click the middle of a cloud to see its inspector.
- **The AI** builds a collector (at most two) when its refineries are short of Hydrogen and it has charted a cloud.
- **Where to look:** the station's Info tab (Staff and Industry drawers):
  - "Fed 100%, medical 100%: supplied 100%"
  - "Food out in 9 min: build a Food Farm" (warning before it runs out)
  - "Medical short: build a Pharma Lab or buy" (it ran out)

- **Station accounts and the pool.** Each station pays its own wages, upkeep, purchases and builds (ships of every
  kind, warships and carriers included, modules and defences) from its own account, and its income goes into it. Your **pool** (the top bar's Credits) is your own funds: gifts, hiring fees and
  subsidies are paid from it. At the start, half of your starting credits are in your stations'
  accounts and half in the pool. Losing a station does not lose its money: its account and its people's savings go to
  your pool.
- **What the pool pays.** The owner's rule (2026-11-19): "everything comes from the station except for constructors and
  what constructors build". Your **pool** pays only for **constructor ships** and what they build: a **construction
  site** (outpost, platform, gate), the goods your stations give a site and what your capital buys for its sites. When
  the pool is short, that order waits and says so ("Waiting for 400 credits from the faction pool"). Everything else is
  paid by the station where it happens, from its own account: every ship its yard builds (warships and carriers too,
  for you and for the AI factions alike), its modules and defences, goods it buys from a sister station or a trader, and
  **research**, which your **capital** pays (credits and materials). A station that cannot pay asks for a subsidy as
  before and otherwise waits, naming its account ("Rook Spire cannot afford it: 310 of 800 credits"); give it money
  from the pool (Money drawer: Give 500 / Give 2,000 / Give the N it needs) or set a subsidy.
- **Where money comes from.** Only **ore** makes new money: credits appear in a station's account when it takes ore.
  Everything else moves money around: wages go to the people, the people spend them back at the station, sister
  stations pay each other for supply runs and transfers, and trade with other factions brings money in or sends it out.
  **Upkeep** is the only thing that takes money out of the game.
- **What people spend.** A station's people spend their savings there every minute: **rent** for their housing, **food**
  and **medicine** (as far as the station supplies them) and **services** from its amenities (Hydroponics,
  Entertainment Deck, Medical Bay; each kind counts fully, a repeat much less). Content people spend more on services.
  So more **Habitats** (more people) and amenities (happier people) mean more income. The station's **Info** tab shows
  "People spend +42 cr/min here: rent, food, services (70 people)" under the upkeep, and what would raise it; the
  selected Habitat or amenity says what it adds. Defence platforms and ship crews spend nothing at a station; pirates
  have no people economy.
- **The profit split.** Every 5 minutes each station's profit (income minus costs) is split: by default the station
  keeps **50%**, **10%** is paid to its manager, and **40%** goes to your pool. A loss is not split.
  - Change the split for the whole faction on the **Empire dock's Money tab** (steps of 10%; **Default shares** puts
    it back).
  - Change one station's share in its **Money** drawer (Info tab): **-10%** / **+10%**, and **Faction setting** to
    follow the faction again.
- **Subsidies.** A station that runs short asks your pool for help:
  - a **one-off** amount, when a build or goods it needs cost more than it holds;
  - a **recurring** amount a minute, when its income does not cover its wages and upkeep.
  - With **automatic approval** on (the default) the pool pays them at once while it can. Switch it off on the Money
    tab (**Approve myself**) to decide each one: the news tells you when a station asks.
  - **Approve** pays it, **Refuse** says no, **Cancel** stops a recurring subsidy. A refused station asks again after
    10 minutes.
- **Moving money yourself.** In a station's **Money** drawer (Info tab, your own stations) and on the **Money** tab
  (one row per station):
  - **Give 500**, **Give 2,000** and **Give the ... it needs** move credits from your pool into the station's account (a
    subsidy, not profit; what it needs is its open subsidy request, else what it lacks of 5 minutes of its own wages and
    upkeep). The drawer says how much the pool has to give, and says plainly when it is empty. Money the
    pool owes your stations for goods they gave a construction site is not given away.
  - **By hand: N cr/min** with **-** / **+** sets a recurring subsidy of your own (0, 1, 2, 5, 10, 20, 50, 100 or 200
    credits a minute), paid from the pool with every upkeep round on top of any subsidy the station asked for.
- **Where to look:**
  - **Top bar:** the pool. Point at it: "Pool 12,000 cr, your stations hold 8,400 cr, people's savings 2,100 cr. Money
    a minute: ore +120, upkeep -46".
  - **A station's Money drawer** (Info tab): its account, last period's income and costs a minute by source, its
    profit and how it was split, its people's savings, the manager's share held, its subsidy and the buttons.
  - **The station header** (right dock, under Cargo, your own stations only): "Money 4,200 cr, +12 a min" (its account
    and last period's profit a minute; amber when it lost money) and "Staff 28 / 32 needed" (amber when short).
  - **The Empire dock's Money tab:** the pool, where it came from (starting credits, profit shares) and where it went
    (subsidies, levies), ore made and upkeep paid so far, the faction's split, automatic approval, and every station asking
    for or getting a subsidy, with Approve / Refuse / Cancel; below that every station with its account and Give 500.
- **Cargo holds** are where a station keeps its materials. A station can store only as much as its holds hold: the
  station header shows "Cargo 4,120 / 6,000" with a bar (amber when nearly full, red when full) and the news warns
  you once. A full station takes no more ore - miners take it to another of your stations with room, or wait - and
  buys nothing; a transfer to it is refused ("no room"). Build more cargo holds (bigger ones store more).
- **What a cargo hold may hold.** Click a Cargo Hold block of your station: its card says "Holds: anything" (the default)
  or "Holds only: Iron, Aluminium", and what is in it ("In it: 410 / 600" and the wares). **Holds...** opens a picker:
  click ores and wares to keep the hold to those only (lit = allowed; nothing lit = anything), or use **Anything**,
  **Only ores**, **Only wares** and **Copy to N same-size holds** (the other holds of that size on this station get the
  same list). A ware is stored only in holds that allow it, so the room for Iron is the room in the holds that take
  Iron: miners, traders, supply runs, purchase orders, transfers and factory output all go by it ("Juniper Anchorage's
  holds have no room for Titanium (its holds for Titanium are full: 600 / 600)"), while other wares still unload.
  The station decides where its stock sits (holds with a list first for their wares). Changing a list never destroys
  anything: stock no hold may take any more stays (over capacity) and the card and the news say so; no more of it
  comes in. With lists set, the **Stock** tab shows each ware's room ("room 300 of 600"). AI stations use lists too:
  a station with full holds whose factory waits for an input keeps its last hold for those inputs until they come.
- **Staff.** A station's modules need people to work. Its **Info** tab opens with a **Staff** drawer: "Staff 148 / 160
  needed (92%)", the population and how fast it grows, the station's amenities, one sentence on what would help and the
  upkeep. Every module that needs people has a row with a bar: at 100% it works fully; with extra people it works up to
  **120%**; below 100% it works in proportion (amber); **below half its staff it is OFFLINE** (red, "OFFLINE - needs N
  staff") and does nothing. The hub is staffed first, then docks, guns, shields, repair bays, yards, labs and
  amenities. Cargo holds, docks, habitats and connectors need nobody, so a station never loses its stock. **Switch
  off** on a row frees that module's people and stops its upkeep until you switch it on again. A station with nobody
  left is inert but stays yours.
- **People and habitats.** People live in the hub and in **Habitats**; the population grows toward the housing while
  the station is paid (faster at a bigger station). Without enough housing a station cannot staff its modules ("Needs
  40 more staff: build a Habitat"). **Amenities** - Hydroponics, Entertainment Deck, Medical Bay (each needs its
  technology) - make people come faster and stay longer when wages are late; a Medical Bay also saves some of the
  people who would die in an attack. Each different amenity counts fully; a second of the same kind counts much less.
- **People going without.** The Staff drawer's population line shows the real change now: "Population 65 / 70, no
  growth, about 1 leaving every 2 min (hungry)". The supply line turns red while the people go without food or medicine,
  the power and "what is short" lines amber; the station's row in the Empire list says "people going without food or
  medicine" in red, and the news says so once when it starts.
- **What going without does to people.** The owner: "people can also get weak or angry (both of which affect
  productivity of modules) or leave", and people die of "starvation because a station has no food or disease because a
  station has no medicine". Each is a state of the station's people you can see on the Staff drawer, with its cause:
  - **Weak**: the share left without food or medicine. Every staffed module works worse in proportion: at 0% fed down to
    `supply.hungryEfficiency` (60%), at 0% treated down to `supply.untreatedEfficiency` (80%).
  - **Angry**: anger rises while the people are left short or unpaid and fades once that is put right; at full anger a
    staffed module works at `supply.angryEfficiency` (70%). Weak and angry multiply: a hungry, angry crew works at
    60% x 70% = 42%. Each module's "works at N%" line names what lowers it ("hungry, angry").
  - **Leave**: hungry people leave as before (the population line says how fast).
  - **Die**: after `supply.hungerDeathAfterMinutes` without food in a row people start to die of hunger; after
    `supply.diseaseDeathAfterMinutes` without medicine, of disease. Both are counted apart from those who leave, and the
    news says "3 people died of hunger at Kestrel Reach".
  - **The crew threatens the manager** (the owner: "hell they might even threaten to execute the manager") when its anger
    has stayed high (`supply.threatAnger`) for `supply.threatAfterMinutes`; the Staff drawer shows it in red, the manager's
    briefing and the news say so, and it lifts when the anger falls again. **The execution** (the owner: "hell they might
    even do it"): from `supply.executeAfterMinutes` after the threat, while it holds, there is a chance each minute
    (`supply.executeChancePerMinute`) that the crew kills its manager. The post goes to a temp, as when a manager dies with
    a station; the news says why. The anger goes on until its cause is put right.
  - Power shortage is unchanged: modules without Energy Cells work at down to `supply.unpoweredEfficiency`.
  The numbers are the lead's reading of "common sense", not the owner's.
- **Casualties.** When a station's hull is hit (its shield is down), some of its people may die - bigger hits, more
  often. The news says "Kestrel Reach lost 12 staff in the attack". Ships lose crew the same way, more rarely.
- **Ship crews.** Every ship needs a crew (by hull size: 1 for a Tiny hull up to 16 for a Huge one; drones and
  towers none). Every tile in the **Build Ships** gallery says it, with the wages ("Crew 6, wages 0.9 cr/min"), and
  warns in amber when the station cannot crew it now ("Crew 6 - only 2 spare"); you can still queue it. A yard takes
  the crew from its station's people that the station can spare above its own staff; until then the finished ship
  waits in the yard (the Build drawer: "Corvette - waiting for crew", "Needs 6 crew, 2 spare - more people come with
  a habitat"; its tray card: "Waiting for 4 crew"). A ship short of crew fights and mines in
  proportion ("Crew 4 / 6 (67%)" in its Overview); below half it cannot operate and limps. Docked at one of your
  stations with people to spare, a ship takes on new crew.
- **Upkeep.** Stations and crews cost credits to run: each hub and module (switched-off modules cost nothing) plus
  wages for every person on a station and every crew member. Each station pays its own every 10 seconds from its
  account (a recurring subsidy from the pool helps one that cannot). The top bar shows the total ("-46/min upkeep")
  and turns red when all your money - pool and station accounts - will run out within a few minutes. An **unpaid**
  station's people start to leave (modules go offline as they do), and after 8 minutes unpaid it is **abandoned** and
  becomes a wreck. Your last station is never abandoned - it just empties. AI factions pay upkeep the same way.
- **Station managers.** Every station has a named manager, always, defence platforms too (a station still being built
  has none until it is finished). The station's **Info** tab has a **Manager** drawer:
  their name, whether they are permanent or a temp, their salary ("Manager: 2.4 cr/min (part of the upkeep)"), how
  long they have been in post, their results in plain figures (people fed and with medical supplies, factories idle,
  modules gained) and a few words on their character ("sharp, cold"). You never see raw numbers for a person: what
  they can do shows only in their record. Buttons: **Briefing** (their dated log: hired, salary set, results every ten
  minutes, people going hungry, idle factories, the station attacked, and their decisions, requests and orders they went against), **Replace** (hire someone from the pool),
  **Promote** (a temp only) and **Fire** (a permanent manager goes to the pool with their record; a temp from the staff
  steps up in their place at once).
  - **The hiring pool** is one list of at most 20 people shared by every faction. **Replace** opens it: each candidate's
    name, asking salary and signing fee, character words, record ("Untested: has never run a station" for a newcomer)
    and past posts with how each ended. **Hire** pays the signing fee (it goes to the person) and they start at once.
    New people join the pool every couple of minutes; people who wait an hour leave. Other factions hire from the same
    pool.
  - **Temps.** A new station, or one whose manager was fired or lost, gets a temp at once: someone from its own staff,
    usually less able than a hire, paid like the staff. Promote them if they do well (they then ask their own salary),
    or replace them.
  - **Pay.** A manager asks a salary from their market value and how highly they rate themselves - confident people
    ask more, which is not the same as being better. The salary is a named line of the station's upkeep ("Upkeep 46
    cr/min (Manager: 2.4 cr/min)") and goes into the manager's own wealth; they spend some of it living on the station,
    which comes back to you. A destroyed or captured station's manager may die with it or return to the pool.
  - **Managers run their station.** A manager decides what the station builds (which module or factory, if any), which
    factories to switch off while their input has no source and back on when it returns, what to buy (a purchase
    order from a sister station or a market your faction has charted), which working ship to order for a station with
    no yard of its own (a hauler, a miner), and what to ask you for. They look at what really flows through the
    station: factories waiting for an input, factories standing full because nobody uses their output, people going
    short, the holds filling, the account against the running costs, and what sister stations and charted buyers lack.
    A good manager weighs this accurately and looks at every option; a poor one misjudges, looks at fewer options and
    may build a factory that will stand idle or miss a shortage. A temp is ordinary. Managers get better with time in
    the job.
  - **Your orders.** Your build queue, the yard's ship queue and the **Automation** switches are orders. Switch
    "Expand station" off and the manager builds and switches nothing on their own; "Supply" off, no purchase orders;
    "Build ships" off, no ship orders. A switch that is off is absolute: the manager never acts against it, however bad
    things get; they may still say what they would do and ask you for help. Your queues are orders a manager almost
    always obeys. Very rarely - when the station is in real trouble and they think little of your authority - one goes
    against a queued order (builds a farm before your queued dock, holds the yard while the people starve). Every such case is in their briefing with the reason, and counted on the card
    ("went against your orders 2 times"). Fire those who do it too often.
  - **Their briefing** lists every decision with a plain reason ("Built a Small Steel Mill: Iron Ore was piling up in
    the holds and the yards need Steel for ships"), every request and every order they went against.
  - **What they are doing now.** The Manager drawer's **Now** line always says what the manager is doing or waiting for:
    "Building a Small Steel Mill (40% done)", "Wants a Small Gun Battery but the station is 300 cr short", "Wants a
    Medium ship yard but is short of 12 Hull Parts", "Waiting to build your queued Small docking bay: short of 40 Hull
    Parts", "Nothing to do: every need is met", "Nothing to do: a Small Steel Mill and 2 other options would not be worth
    it now" (they looked and nobody needs what it would make), "Building nothing on their own because your Expand station
    switch is off", or "New here: taking stock (first reading in about 5 s)". The **Needs** line below it is the station's
    needs as the manager sees them, worst first, in words ("Money: 1,240 cr to spend, tight; Factory inputs: short
    (waiting for Steel); good: people fed and treated, output used, room in the holds, staff"); open purchase orders follow.
  - **When they build nothing, the briefing says why** - once, when the reason starts or changes ("Wanted to build a
    Small Steel Mill: cannot afford it (300 cr short)", "Holding back: your Expand station switch is off, so they build
    nothing on their own", "Nothing needed for now: ..."), never the same line twice in a row. A reason must hold about
    half a minute before it is written, so a flicker is not.
  - **What a manager may build, and in what order they look.** Everything the station could build now and pay for is a
    candidate: every size of hold, gun and shield, a habitat, each amenity researched, every factory of a ware the faction
    wants (also at an outpost, also before anything runs short). There is no fixed order ("guns before shields", "a farm
    first at an outpost") and no fixed count: the manager turns to the options in the order of the needs THEY feel most
    (their own reading, people's needs weighed by their Empathy, others' by their Locus), and a less able manager weighs
    fewer of them. Two things still follow the old rule, because the game cannot yet measure how much they are needed: a
    repair bay only at the capital, at war or where warships gather, and a research lab only where there is none.
  - **What they did not do, and why.** At every look, each need the manager reads as short and did not act on gets one
    line in the briefing saying why not, read from the very scores the decision used: "People fed and treated: very short
    (Food Rations lasts about 4 min). Did not build a Small Food Farm: it would not run: no Water here and nothing here
    makes it", "... Did not build a Small Solar Array: not worth it yet - it would cost 900 cr, more than what it would
    fill is worth to me now", "... I weigh only 3 of 7 options at a time, and it was not among them" (a less able manager
    weighs fewer), "... not allowed - the CEO's switch \"Expand station\", which is off", "Did not order Food Rations: no
    station I know has at least 20 to spare". The same line again replaces the earlier one: "Still: ... (since 0:12:00)".
    Where the manager's character shaped a decision, the line says so in the people table's own words ("clever: plans 2
    steps ahead", "warm: weighs the people's needs higher", "traditional: sticks to what it has done before").
  - **Numbers that matter.** The Needs line says how long the people's food, medicine and power last at the present use
    ("Food Rations lasts about 40 min"), or that they are going without ("Food Rations: going without (0% supplied)"), and
    since when people go hungry and leave. Every per-minute flow and "runs out in" time in the game (the Stock tab, the
    drawers, the briefing) is in game minutes at the world's economy pace.
  - **A new manager** says on arrival what they are taking stock of (the station's money, stock and holds, what its
    factories wait for, its people, staff and defences) and, a few seconds later (their first reading), what they found ("Found: money tight
    (300 cr to spend); fine: people fed and treated, ..."). Their briefing
    starts with the last few lines of the manager they replaced, marked "Before them, <name>:", so the station's recent
    history does not leave with the old manager.
  - **Requests.** A manager asks for what the station cannot do itself: money when the account runs low (the subsidy
    request on the Money drawer, as before), a hauler or miner when no yard of yours can take the order, a ware nobody
    you know makes or sells. The oldest open request shows on the Manager drawer with **Grant** and **Refuse**. A
    granted ship request orders the ship from your nearest yard. Managers warm to an employer who grants their requests
    and cool to one who refuses them, and that is part of why they obey.
  - **Their share.** The 10% of profit held for the manager is paid to them; like their salary, they spend it where they
    live, so it comes back to the station. The card shows what they have been paid.
  - Other factions' stations have managers too, and they decide with the same rules.
- **Your advisor (the Advisor tab of the left dock).** You can hire an advisor from the same pool as your managers:
  **Hire advisor...** opens the pool; pick someone and they start at once. You pay the signing fee and their salary from
  your pool. **Fire** sends them back to the pool; **Replace...** hires someone else. Without an advisor the game runs
  exactly as it did before. The tab reads top to bottom: who your advisor is and the Hire / Replace, Fire and mode
  buttons; then **RECOMMENDS AND WAITING ON YOU** (the advice comes first); then **WHAT THEY DID AND WHY**, **THE
  ADVISOR'S CUT**, **STEERING THE FLEETS** and **OTHER FACTIONS' CEOS**. Those four fold open and shut with a click on
  their heading (the small triangle); the cut, steering and CEOs start shut, and a shut heading still says where things
  stand in one sentence ("5% of each station's profit, out of the faction's share.", "3 of 4 switches on. It recommends
  only."). The tab remembers what you opened until you quit. An advisor works in one of two ways, and you choose with
  the button under their name:
  - **Point things out only** (the start): they act on nothing and list what needs your eye under **RECOMMENDS AND
    WAITING ON YOU**: a manager failing or going against your orders, a temp who did well (or badly), a request waiting
    for your answer, a station stuck because it cannot pay for or get what it wants to build, people going short, a
    station running out of money, and wares your factories wait for that none of your stations makes. Each line says
    what they would do and why. In both modes they also point out anything of yours that has been held up for about a
    minute (sim time) for a reason the game knows: a ship that cannot dock because no bay at the station takes its size
    ("Miner #12 cannot dock at Kestrel: no docking bay there takes a Medium ship. A Medium docking bay at Kestrel would fix
    it."), a ship that cannot unload because the holds there are full, a station whose holds are full (a hub without a
    Cargo Hold stores nothing), a construction site held up, a ship waiting for a berth. Each such line has a **Show**
    button for the ship, station or site and goes away when the situation ends; for these they only recommend.
    **Show** selects that station (or ship) and centres the map on it. The tab has no Grant or Refuse buttons: you answer
    a manager's request in the station's **Info** tab, in its **MANAGER** drawer (Grant / Refuse). When the asking station
    has started making the ware itself, the line says the request is no longer needed.
  - **Act as chief of staff**: they do what the other factions' CEOs do, for you. They answer your managers' requests
    (pay money from your pool, order a hauler or miner from one of your yards, or make a ware a **faction goal**), make
    a temp who did well permanent, replace a temp who did badly with someone better from the pool, fire a manager whose
    results stay poor or who went against orders three times, and set faction goals of their own. Your **automation
    switches** decide what they may do alone: with "Auto-build ships" off at a station they only recommend a ship for
    it, with "Auto-expand station" off they only recommend a goal. Anything they may not do shows under recommendations.
  - **WHAT THEY DID AND WHY** lists every step, dated, newest first, with the reason ("Granted Ada Brook's request for
    800 cr for Kestrel: its account covers 12% of what it needs to run on and the pool has 9,200 cr to spare"). A line
    about a station has a **Show** button that selects the station on the map.
  - **Every review is written down**, even when they do nothing: "Reviewed 2 stations. Pelican Market: people fed and
    treated: very short (Food Rations: going without (0% supplied)); manager Bram Szabo: wants a Medium Gun Battery but is
    short of 18 Hull Parts. Did nothing: I only point things out (set me to act as chief of staff to let me act). Pointing
    out 3 things under Advice. Next review about 2:45:00." A review with nothing new replaces the last one ("Still: ...
    (since 2:05:00)"). Every station need that is short stays under RECOMMENDS AND WAITING ON YOU while it lasts, with
    what its manager is doing about it. AI factions' CEOs keep the same entries; you see only your own advisor's.
  - **Faction goals** ("more Steel: 3 of our factories wait for it and none of our stations makes it") go down to your
    stations as orders: one station that can build a factory making that ware is ordered to; the goal ends when one of
    your stations makes it, or after about half an hour.
  - **STEERING THE FLEETS**: the same four switches as the New game page's "What CEOs may steer", for your advisor. They
    always shape what the advisor recommends ("I would steer the fleet: grow the fighting fleet: we are at war"), and the
    advisor steers the fleets by them only when it is your chief of staff and "Auto-command fleet" is on. Every change it
    makes to the fleet's goals is a line in WHAT THEY DID AND WHY.
  - The tab also lists the **other factions' CEOs** you have met. Every other faction is run by a named CEO with the same
    kind of character as a manager: they hire, fire and promote their managers, answer their requests and set their
    faction's goals, and like a manager, a poor one misjudges and may overlook part of the faction's plan for a while.
  - CEOs and your advisor are paid a salary from the faction's pool and spend it at the faction's capital, so it comes
    back into the economy. They may also be paid a cut of each station's profit. **You set your advisor's cut on the Advisor
    tab** (THE ADVISOR'S CUT): **-1%** and **+1%**, or type a number and press **Set %**; then pick where it is taken from:
    **From the faction's share**, **Off the top, before the split** or **From the station's share**. Above 0% each choice
    shows the split of a station's profit it gives, in plain numbers ("station 50 / manager 10 / faction 35 / advisor 5");
    at 0% all three give the same split, so it is shown once. A change
    counts from the next time the stations close their books (every few minutes), and the tab shows what your advisor was
    paid as cut last time. With no advisor hired nobody is paid it. The other factions' CEOs' cut is set on the New game
    page. Both start at 0%.
- **Materials** (Iron, Titanium, Aluminium, Copper, Silicon, Carbon, Tungsten, Uranium and Ice in the
  base game) are mined from asteroids and stored at your stations. **Hydrogen** is a gas: it is in no asteroid but in
  **gas clouds** (see "Gas clouds and gas collectors"). Every ship and module costs credits plus materials.
- **Shipyards** come in six sizes: Tiny, Small, Medium, Large, ExtraLarge, Huge. A yard builds hulls up to its own
  size, so bigger ships need a bigger yard. The build gallery's size buttons choose the size of a new yard, like every
  other module; you can buy any size directly (Large and up need research).
- **Every ship yard builds its own ship.** A station with three Ship Yards builds up to three ships at once, each in a
  yard at least as big as its hull. A new ship goes into the smallest free yard that fits it (a yard that is working
  before one that is offline for want of staff), so a Corvette does not take the Medium yard a Frigate needs. Each
  yard works at the speed its own staff allow. The Build drawer's **In the yards** block has one row per yard
  ("Ship Yard (Medium): Frigate - 1 min 20 s", "Ship Yard (Small): idle"), each with its own Cancel button, and the
  map draws each ship in its own yard. Finished ships wait in their yards for a free bay to launch through.
- **Docks** (docking bays) are where ships dock to unload, load, trade, refit or be repaired - a ship does nothing at
  a station without docking in one of its bays (see "Docking" below). A ship needs a bay at least its own size. The
  build gallery's size buttons choose how big a new dock is.
- **A station builds only what it can launch:** a new ship leaves the yard through one of the station's bays, so a
  station can queue a ship only when it has a yard big enough AND a finished dock of the ship's size or larger. A
  ship too big for every dock is greyed in the build gallery ("Needs a Large dock at Kestrel Reach to launch from");
  clicking it queues that dock for you. A dock still being built does not count.
- **The build queue:** every click in the build gallery adds one build to the station's queue. The **Build**
  drawer shows what is being built, the queue in order, why each ship is waiting (no yard big enough, no free yard yet,
  not enough credits or a material) and a **Cancel** button per entry.
- **Cancelling what is already being built:** the ship in the yard and the station module under construction each
  have a **Cancel** button in the Build drawer (and on the "Selected module" card when you click the yard block or
  the scaffold). A ship that is finished but still waiting in the yard for its crew or for a free bay to launch from
  shows **Scrap** instead. The first click asks ("Cancel the Corvette? The work done so far (40%) is lost. Back to
  the station: ..."), the button turns into **Confirm**, and the second click does it. The work done is lost, but
  everything the build cost comes back: its materials into the station's holds (even if that overfills them, like
  every refund) and its credits into the station's own account. The credits paid for a build went to the station's
  people as their pay for the work, so they come back out of those people's savings, and only as far as their
  savings still hold them. No crew is lost: a ship's crew only leaves the station when it
  launches. The yard is free at once and the next build in the queue that fits it starts. With several yards, each
  yard's ship is cancelled on its own. A ship or module your station's
  automation started can be cancelled the same way; the automation then waits half a minute before it builds
  there again. Modders can make cancelling cost something (`production.cancelMaterialRefund`, `cancelCreditRefund`).
- **You can queue what you cannot pay for yet.** Anything the station can build at all (its yard is big enough and
  you have researched it) goes into the queue; only a ship too big for every yard you have, or something not yet
  researched, is refused. Modules keep their order: a module that lacks materials waits at the head and nothing
  jumps ahead of it. **Ships do not wait for each other:** the queue fills every free yard in order, earlier ships
  first, and a ship that cannot start yet (it lacks materials or credits, needs research, or no free yard is big
  enough) no longer holds up a ship behind it that can start in a free yard. One thing is kept for the earlier ship: a
  ship that could be paid now but only waits for its yard to come free keeps what it needs, so a later ship never
  takes its materials. A ship that waits for materials keeps nothing back. The Build drawer says for each build what
  it is waiting for and what is being done about it: "waiting for 40 Steel, 20 Light Alloys - on order", "on the way from your other station", "on order - a hauler is
  fetching it", "blocked by your trade policy: Steel is on Hold", "no room: the holds are full (6701 / 3900), so nothing can be delivered" or "cannot afford the order". When none of your
  stations makes a ware it also says so plainly: "No Steel: build a Steel Mill or buy Steel". Credits are paid when
  the build starts, not when you queue it.
- **Ship-building automation never eats your queue.** With the station's **Build ships** automation on, the ships
  it picks by itself are paid only out of what is left after what your queue waits for next (the first ship and
  the first module in it); the Build drawer then adds "(auto-build keeps this back for it)".
- **The station fetches what its queue lacks.** For the first three builds in its queue it posts **buy orders** for
  the missing materials (other factions' traders and your own free haulers fill them), and your other stations send
  what they can spare beyond what they keep and need themselves. This happens whether or not ship-building
  automation is on. It respects your trade policy: a material you set to **Hold** or **Sell** is never ordered.
  The orders are sized to what the station itself can spend: at most half of its own account plus the subsidy your
  pool would approve at once (`trade.buyBudgetFraction`), and never for more than the station's cargo holds have
  room for. The **Trade** drawer shows the orders
  ("order 120 for builds") and has a switch, **Buy materials for queued builds** (on by default), to stop it.
- **You can queue what the station cannot pay for yet.** Such a tile reads "short of 26 more Titanium - click to queue it anyway"; once queued, the build waits at the head of the queue, the station orders the missing materials, and the credits are paid when it starts.
- **A locked tile says why:** "needs Medium yard" or "Needs Heavy Hulls" (click such a
  tile to open the Research screen on that technology).
- **Building takes time,** and bigger hulls take much longer. At normal speed (1x) a Scout or Courier spends about
  five minutes in the yard, a Corvette about eight, a Miner about ten, a Frigate about a quarter of an hour, a
  Cruiser nearly half an hour and a Carrier nearly an hour. A new Ship Yard takes about 7 minutes (Small) to 10
  minutes (Medium) and up to 21 minutes (Huge); an outpost takes over half an hour of work by one constructor once
  its materials are there, a jump gate over 40 minutes. The Build drawer shows how long the current build has left.
  Speed time up (**.**) when you are waiting.
- **The pace of the economy.** Everything economic runs at the same slow pace as building: a factory cycle takes
  ten minutes (a Steel Mill makes its Steel every ten minutes), the first technologies take tens of minutes, a repair
  bay mends a Corvette from nothing in about four minutes, people eat, grow, pay taxes and draw wages at a tenth of
  the old rate. Ships still fly, fight, dock and load at full speed. A mod can change the pace with one tuning key,
  `pace.economy` (10; 1 = the old, ten times faster economy - the `faster-economy` example sets it); for one game, the New game
  page's **Pace** slider sets it (and `pace.conflict`).
- **The pace of conflict.** Pirates, wars and diplomacy keep step with the slow economy: the first pirate hideouts
  turn up after about two and a half hours and new ones come ten times less often, a band raids in short bursts with
  long rests, the AI factions declare their first wars later and less often, fight them out over longer, and truces,
  pacts, alliance notices and trust run ten times slower. A battle itself plays at full speed. A mod sets this with
  `pace.conflict` (10; 1 = the old pace - the `faster-economy` example sets both keys to 1), or the New game page's **Pace**
  slider for one game.
- **Cargo takes time to move.** A miner fills its hold in about three minutes at the asteroid and takes about 8
  seconds to unload at a dock; a hauler loads and unloads at about 12 units a second (a Courier about 7 seconds
  each way, a Freighter about 25 seconds). A docked ship holds its bay while it works, so more docks mean less
  waiting. The ship's inspector shows the progress ("unloading at Station #3 60/100 aboard (7 s left)").
- **Automation** (the station's **Automation** drawer) lets the AI run parts of your faction for you: building
  ships, expanding the station, deploying defences, commanding your fleet, diplomacy, refitting ships, founding
  outposts and supplying your other stations. Fleet, diplomacy, refit and outposts follow your capital; the others
  are set per station. A new game starts with everything switched on except Auto-diplomacy, and so does every station you gain later: a new station copies your capital's current switches (untick one on the capital and later stations start with it unticked), unless you stored a default below. The starting switches are the `playerAutomation` tuning keys.
- **Build rules** (the **Rules** button in the top bar when there is room, **Build rules** at the foot of the Empire
  dock, **Rules for this station...** on a station's Build tab, or **Build rules for this station...** in its
  Automation drawer) tell the automation what it may build. One table, two scopes:
  - **Faction-wide**: each category - outposts, jump gates, laser towers and mines, each station module (docks,
    yards, connectors), each ship role (miners, haulers, scouts, warships, carriers, constructors, salvage ships),
    each ship type including your own designs, and automatic refits - is **Allowed** or **Forbidden**, with an
    optional **At most** cap (the - / + buttons; "none" = no cap). A ship role row also has **Prefer design**: click
    it to walk through that role's ships and your designs; the automation then builds that one first.
  - **One station** (pick it in the scope row): the same list as overrides - **Inherit** follows the faction-wide
    rule, **Allowed** or **Forbidden** overrides it here ("this yard builds only warships", "no more docks here").
    A station cap counts that station only (ships based there and in its yard, its modules, its defences).
  - **Pause all automatic building** is the moratorium in one click; **This station builds nothing
    automatically** does the same for one station.
  - The **Now** column counts what you have (things being built included); the last column says what the
    automation does about it here ("forbidden faction-wide", "cap of 4 reached at this station").
  - A forbidden thing is never started; something already being built is left alone until you press **Cancel all
    forbidden builds** (the automation's own builds only, refunded in full). Your own build queue is never
    restricted. Each automation switch says underneath what the rules stop ("not building jump gates - forbidden
    faction-wide").
  - A jump gate cap counts gate ends (a pair is two); an outpost cap counts every station beyond your first.
- **Set as default for new stations** (the Automation drawer) stores that station's switches and its build-rule
  overrides as the starting settings of every station you gain afterwards (a new outpost has them from the moment
  its construction site is placed). The drawer says what new stations start with; **Reset new stations to follow my capital**
  goes back to copying your capital. **Apply to all my stations** still copies the switches to the
  stations you already have. Both are saved with the game.
- The station's inspector says what the automation is doing ("Automation is building warships"), or "You decide
  what this station builds" while ship building is left to you. An AI station's inspector shows its plan.
- **Scouts explore by themselves.** A scout with no orders charts space for your faction, outward from your home:
  it flies to the nearest stretch your faction has not seen yet, and several scouts spread out into different
  directions. On the way its survey radar surveys every asteroid it passes within radar range (a surveyed rock can be
  mined); it never turns aside for rocks. It keeps away from known stations of factions you are at war with. Your
  faction learns where space ends only by reaching the edge. Once everything it can reach is charted, the scout
  patrols: it revisits the areas seen longest ago and keeps an eye on known foreign stations, which keeps the
  Market and Diplomacy screens up to
  date. A right-click order always comes first; the scout goes back to exploring when the order is done. AI
  factions' scouts work the same way.
- **Finding your first neighbour.** A Scout's long-range scanner sees about 9,000 units (as far as a station sees).
  Until your faction has found another faction's station, your scouts fly wide rings round your home station (the
  first about 20,000 units out, then further) instead of creeping outward, because that is where neighbours live. With
  station building left to the automation, your yard builds a second scout early while you have found nobody. Once a
  foreign station is on your chart, the scouts go back to charting outward from home as above.

## Factories and wares

Ships, equipment and most station modules are built from **wares**, not from raw ore - like X4. Your miners still
bring in ore; your stations' **factories** turn it into wares, step by step:

- **Energy Cells** come from a **Solar Array** and go into every other factory.
- **Tier 1 (refined):** refineries turn ore into Steel (Iron), Light Alloys (Aluminium + Titanium),
  Superalloys (Tungsten), Silicon Wafers (Silicon), Conductors (Copper), Graphene (Carbon), Fuel Rods (Uranium) and
  Water (Ice).
- **Tier 2 (components):** Hull Parts, Engine Parts, Armour Plating, Microchips, Plasma Conductors, Reactor Cores,
  Scanning Arrays.
- **Tier 3 (advanced):** Advanced Electronics, Weapon / Turret / Shield / Drone / Missile Components, Field Coils and
  Claytronics.

**You start with two stations:**
- **Your main station (the capital):** the shipyard, three docks, three cargo holds, a repair bay, a gun battery, a
  shield generator and a research lab. **No factories.** It holds the wares the yard and your first builds use: Steel, Light Alloys, enough Hull Parts and Engine
  Parts for the first few warships, food and medicine for about 15 minutes.
- **Your supply station**, about 3,000 away (outside the capital's parking traffic, inside its scan range): two docks,
  two cargo holds, a gun, a shield and the **basic chain** - a Solar Array, a Medium Steel Mill, a Medium Alloy
  Smelter, a Superalloy Foundry, a Hull Part Factory and an Engine Part Factory. It holds your ore and the chain's inputs, a few
  parts, and food and medicine for its own people. It counts as one of your outposts.

**How the first chain keeps going:** your miners sell their ore at whichever of your stations is nearest. Your
**Courier** hauls between the two on its own: a station whose factories run low on an input (Iron, Tungsten...) is
sent it from your other station, and the Hull Parts and Engine Parts the supply station makes go to the capital when
its yard's queue needs them, whatever your automation switches say. With **Supply** automation on (the default) a
station also keeps your other stations topped up with its surplus, parts included.

**Where to build more factories is up to you:** any factory can go on any station. Keeping a chain on one station
saves hauling; the AI adds its new factories to the station that already has the most.


**Nothing you build costs raw ore** - not a ship, a ship module, a station module, an outpost, a jump gate or a
mine: ore only feeds factories. A miner is built from Steel and Light Alloys, not from Iron; a scout from Steel and Light
Alloys; a cargo hold from Steel. Your supply station starts with its basic chain **already built** (above) and both stations hold a stock of wares to
build the first things while the chain warms up. A warship needs Hull Parts and Engine Parts; bigger ships and better
equipment need the higher tiers. The Solar Array, the Steel Mill and the Alloy Smelter cost wares too (Steel and Light
Alloys), so **guard the station that holds your refineries**: if you lose them, your remaining stock, another station of
yours, or buying Steel and Light Alloys at a station you know (or an ally's help) is the only way back. Your stations
keep enough Steel and Light Alloys back from the factories to build one replacement miner. Miners fill a station's holds only
to 90%, so there is always room for the wares its factories make and the ones it buys. When none of your stations makes
a ware, your station orders it from the market even when money is tight.

- **Building factories:** they are in the station's module gallery, grouped by tier (the tile caption says which).
  A bigger factory makes more. Each needs a little staff and upkeep, like any working module.
- **Most factories need research** (the **Manufacturing** branch of the Research screen). Open from the start: the
  Solar Array, Steel Mill, Alloy Smelter, Superalloy Foundry, Hull Part and Engine Part factories, Water Purifier,
  Food Farm and Pharma Lab. **Advanced Refining** unlocks the Wafer Fab, Conductor Works, Graphene Plant and Fuel Rod Plant;
  **Component Manufacturing** the Armour, Chip, Plasma Conductor, Reactor Core and Scanning Array factories; then
  **Advanced Electronics** (Electronics Assembly, Claytronics Fab), **Weapon**, **Shield**, **Drone** and **Missile
  Manufacturing** the advanced component factories. A locked factory tile says "Needs ... - click to research".
  Everything you can research comes with the factories it needs: a weapon, shield, missile or drone technology
  requires its manufacturing technology, cruisers need Advanced Electronics, and new shield
  generators, repair bays and labs need the factories for their parts (your starting station already has one of each).
  **Gun batteries need no research** (2026-11-21): Small and Medium ones can be built from the start, from Hull Parts,
  Engine Parts and Superalloys; a Large one needs Heavy Hulls and Extra-large / Huge ones Capital Hulls, like any
  module of that size.
- **Why is it idle?** Click a factory block: the "Selected module" card shows what it makes a minute, what it uses,
  and why it is idle - "no Silicon Wafers", "output full" (build a cargo hold), "stock full" (it reached a
  "make up to" limit; the card says whose: "your limit 400" or "the manager's limit 300"), "no staff" or "switched off".
- **Make up to.** On the Trade drawer, a ware the station makes has a line **Make up to [-] [number] [+]** with
  **No limit** and **Auto**, and under it the rule in force: "make up to 400 (yours)", "no limit (yours)", "make up to
  300 (the manager's)" or "no limit". Its factories stop while the station holds that much and start again below it.
  With no number at all there is no limit: a factory makes until the holds are full ("output full"). **No limit**
  keeps your factories running even where the manager set a number; **Auto** hands the ware back to the manager. To
  make none, switch the factory off. Every station's manager sets a number by its own rule (about 20 minutes of what
  your stations use, plus what charted buyers want, at least the starting value), and none for a ware a faction goal
  asks for; your own number or your "no limit" always wins. The copy-to-all and new-stations buttons carry it too.
- **Industry drawer:** a station's Info tab, under the line "What this station makes and uses each minute", shows how many
  factories work and what is short, then a table with one row for every ware its factories make or use: **Made /min**,
  **Used /min**, **Net** and **In stock**, numbers lined up on the right. A ware you use more than you make comes first
  (the biggest hole at the top), then the rest by tier. **Net** is green for a surplus, amber for a deficit and red only
  when the stock would run out in a few minutes or a factory is already waiting for it. Nothing is cut off: the tab scrolls.
- **Station inventory:** the station's **Stock** tab lists every item with what is in stock, its net a minute and when it
  runs out or fills the holds, in two parts under headings: **MANUFACTURED GOODS** (made in factories) first, then **RAW
  RESOURCES (ORES)** (mined; only factories use them). In each part the items running out come first; nothing is cut off.
  **Click an item** to open its page in the Reference (below). **Open full
  view** (also the **Full inventory** button in the Info tab's Industry drawer) opens a wide window: every ore, ware, food, medical
  and energy item the station holds or handles, in the same two parts (the goods grouped by tier), with In stock, Made /min, Used /min, Net /min, Reserved
  (held for traders' purchase orders), Runs out / fills and the buy / sell price or your trade policy. Click a column
  title to sort (again to reverse), **Only active** hides what nothing makes or uses, the search box filters by name;
  rows about to run out are tinted. Esc or Close shuts it.
- **Reference (the in-game wiki): what is this, and what can I do with it?** Click an item in a station's Stock tab or in
  the full inventory window, or press **F7** anywhere for the index. A material's page says what it is (raw ore or a
  manufactured good and its tier), its base price, where it comes from (mined from asteroids, or which factory makes it
  from what, how fast, and the research that factory needs) and **everything that uses it**: the factories that take it,
  the people (food, medical supplies) and working modules (energy cells) that use it up, and every station module, ship,
  ship module, defence, station type, jump gate and research whose cost includes it, with the amounts; and your own ship
  designs. Opened from a station, it starts with **At <station>**: how much is in stock, made and used there, what on the
  station uses it now (factories, people, queued builds), and what you could start there with it - marked *you could build
  here* (with whether you have the whole bill), *needs something built here first* (a bigger ship yard, a dock), *needs
  research first* (the research it needs, nearest first) or *not on this kind of station*. Raw ore is never a build cost,
  so an ore's page lists only the refineries. Every name on a page is a link to its own page; factories, station modules,
  ships, ship modules, defences, station types, jump gates and technologies all have pages (cost, research, what it
  makes, what it carries; *Open the full spec sheet* opens the Module window, *Open it in the Research screen* the
  Research screen). **Back** goes back, **Index** lists everything by kind, the search box finds a name. Esc or **Close**
  shuts it. It is built from the game's content, so a mod's items appear in it by themselves.
- **Wares overview:** open the Market (F2) and pick "Wares overview" in the material list: your stations added up,
  tier by tier - stock, factories, made and used a minute, and where a factory waits for the ware.
- **Wares trade like ore:** they have market prices, traders carry them, supply runs move them between your stations
  and pirates loot them. A station short of a ware pays a high price for it, which draws traders.
- **Repairs** use the materials the damaged ship was built from (a warship: its Hull Parts and Engine Parts).

## Getting around: wormholes and jump gates

- **The map is big and open.** A new game is a galaxy a third wider than the Standard world. There are
  no sectors or regions: the factions start wherever the seed puts them (never right next to each other, never at
  the edge, and never a peaceful faction with a raider as its nearest neighbour), so every game's map is different.
  **Rock is scarce** (owner ruling 2026-11-15): every faction has a small **home field** a short trip from its
  station - two starter rocks and eight more, each holding whatever ores it drew (no metal is guaranteed) - and the rest of the asteroids lie in
  a few small **fields** of four to a dozen rocks out in the galaxy, with a few lone rocks between. A field is worth
  an outpost, and worth a fight: your home field runs dry within the first half hour or so, and after that your
  miners must fly further, you must expand to a field, trade for what you lack, or take a field from a neighbour.
  A rock that is mined out is gone.
  - You start knowing your **home field** (every rock in it is analysed, so all your miners can work at once).
  - You also start with a rough chart of your **home sector** (rocks within about 35,000): you can see where the
    nearest fields are. Survey them before your miners can work them: fly any ship with a survey radar past
    the rocks (see "How to survey an asteroid").
  - An **outpost** costs 400 credits, Steel 80 and Light Alloys 60: put one at a field.
  Crossing the whole map takes a
  Corvette about four minutes and a Freighter about six and a half.
- **Wormholes** are natural shortcuts: a pair of swirling mouths far apart, placed at random anywhere in the
  galaxy (never right on top of a starting station). Your scouts find them
  while they explore, and they go through the ones nobody in your faction has used yet - the far side is new
  ground. You only know where a wormhole leads once one of your ships has been through.
- **Travel through:** select ships and **right-click a wormhole** (or one of your gates). They fly into the mouth,
  wait a few seconds there (they can be shot while they wait) and come out at the far end, keeping their heading.
  Other ways to do the same:
  - **Hover** a wormhole or gate with ships selected: the hint at the cursor says "Right-click: travel through
    Wormhole (leads to unknown space)" (or where it leads, the toll, or why it is closed to you).
  - **Click the wormhole** after selecting ships: its inspector's **Travel** drawer has **Send the ships you had
    selected through**. With no ships selected it says how.
  - **One ship selected:** its inspector's **Wormholes and gates** drawer lists the two nearest ones you know, each
    with a **Travel through** link.
  - A ship under **manual control** goes the same way; it stops on the far side and holds there.
  - A wormhole you have charted but nobody of yours has been through is a valid target - that is how you explore.
- **Ordering a ship beyond a wormhole:** your ships only plan routes through wormholes your faction has been through.
  Until then a long order flies straight, and the ship's **Wormholes and gates** drawer says so ("Flying straight to
  (40,000, 12,000), about 4 min - no known shortcut ..."). Send a ship through first and later orders use it.
- **Your ships use the network on their own.** Every move - your orders, fleets, miners and haulers going home,
  trade, supply, constructors, the AI's attacks - goes through the wormholes and gates your faction knows whenever
  that is clearly quicker. The selected ships' planned route is drawn on the map (dotted legs, a dashed jump), and
  their inspector says it ("to (12000, -4000) via Wormhole #12, 1 leg left").
- **On the map:** wormholes are rings of purple and blue light; gates are square frames in their owner's colour.
  Zoomed out, each one you know keeps a clear mark of a fixed size (a turning ring of dots for a wormhole, the
  owner's frame for a gate) and, zoomed far out, its name under it ("Wormhole", "Jump gate"). You only see the
  wormholes your faction has charted. A dashed line joins the two ends of every pair you know. **K** jumps the camera from one known wormhole or gate
  to the next; the minimap shows them too, and clicking it moves the camera anywhere on the map. Zoom right out
  to see the whole galaxy.
- **Jump gates** are wormholes you build. Research **Jump Gates** (Logistics), select a constructor and press
  **J** (or **Build jump gate** in its inspector), then click a clear spot - the banner says why a spot is refused
  (gates keep 2,500 units from stations, wormholes and other gates). The constructor sets up a **construction site**
  there and stays to build it (see "Construction sites" below); it is free again when the gate is finished. The
  bill is shown before you send the constructor: hover the **Build jump gate** button, and the second line under the
  placement banner lists it (credits and each material, from the game's content) - in amber, "Capital is short: 80
  Steel", when your capital has not got it all right now. That no longer stops the build: the site waits while your
  haulers and buy orders fetch the rest. Build a second one far away the same way: while you have a gate with no
  partner yet, the next one costs **half** (credits and materials) - it is the other end of the pair, and the cost
  shown says so.
- **Linking:** select a finished gate; its **Gate controls** list **Link to Jump Gate #...** for each of your other
  gates. A new link charges for ten seconds before it carries ships, and a gate can only be relinked after a
  minute. **Unlink** breaks it.
- **Who may use your gates:** you and your allies always; factions at war with you never; everyone else as you
  set it - **Allies only** (a new gate), **Open to all not at war** (with a toll you can raise and lower, paid into
  your capital), or **Closed**. Click the Access line to change it.
- **Gates can be attacked and destroyed**; a destroyed gate breaks its link ("Your jump gate #12 is under
  attack"). A gate is not a station: losing your gates never knocks you out of the game.
- **The AI** charts and uses wormholes the same way, builds gates when the trip they save is long, and opens or
  closes its gates by how much it likes to trade. Every AI faction sends one scout through the nearest wormhole
  near its own stations as soon as it knows of one, and any faction holding a far outpost links it home with a gate
  pair.

## Salvage: wrecks, cargo pods and tractor beams

- **Every destroyed ship leaves a wreck** (a destroyed station a bigger one) holding part of what it was built from:
  30% of its hull and module materials, give or take a little. A ship that was **carrying cargo** also drops a
  **cargo pod** with about half of what was left in its hold after the killer took its share. Drones, mines and
  jump gates leave nothing.
- **Wrecks and pods** drift to a stop where the ship died. A ship's wreck lasts 10 minutes, a pod 3 minutes and a
  station's wreck 15 minutes before it breaks up and is lost. Wrecks are grey shards (a broken square when zoomed
  out), pods small amber crates (a small amber box). You see them where your sensors reach.
- **Click one** to see what it was, whose it was, what it holds and how long it has left.
- **Any ship with a cargo hold collects a floating cargo pod** (owner: "a19: yes"): select it and right-click the pod; it
  flies right up to it (within 80) and loads 3 units a second. **Stripping a wreck needs a tractor beam**, and a beam
  also collects pods from farther (its range) and faster (4 or 9 a second). Research **Tractor Beams** (Logistics, cheap) for the Tractor Beam module and
  the **Salvage Tug** (a hauler built around a beam - it does not mine); **Salvage Rigs** gives the Heavy Tractor
  Beam (longer reach, more than twice the pull). In the Ship Designer you can fit a beam to any free hardpoint
  of any hull.
- **Select ships with a beam and right-click a wreck or pod.** They fly to it, stop close by and pull its material
  into the hold a few units a second - you see the beam - until the hold is full or the wreck is empty. The ship
  says so: "salvaging wreck of a Corvette - 120 left". Selected ships without a beam fly alongside; if none has
  one, the order is refused with the reason. When the last of a wreck is pulled in, the feed tells you.
- **Salvage is cargo:** your ships sell or deliver it like mined ore. Anyone may salvage anything - your enemies'
  wrecks and your own - and the AI's Salvage Tugs and miners with beams go for what their faction sees. A tug on
  its own waits a safe distance behind a fight of its own side and strips the wrecks when it is over.
- **Jettison cargo from a station.** Select your station, open its **Stock** tab and the **Jettison cargo** drawer: every
  ware it holds has a "Jettison..." button. Set the amount (-100, -10, +10, +100, All), press "Jettison N ...", then
  "Yes, jettison". The goods leave the holds and float in one cargo pod 300 units beyond the station's parking ring, on
  the side below the station, so they block no dock, queue or parking slot. Nothing is destroyed and no money moves.
  Cargo you jettison **never breaks up**: it floats until a ship collects it (any ship with a cargo hold: select it and
  right-click the pod). Its inspector says "cargo jettisoned from a station" and "breaks up:
  never". Anyone who sees it may salvage it, other factions too. Ore you jettisoned and bring back creates no money a
  second time (a station already created money for it when it first took it in).
- **What a ship can do comes from its modules.** Any ship with a mining laser and a hold can be ordered to mine
  (right-click a rock) or put on Auto-Mine - even a frigate with a drill on one of its hardpoints. A selection with no
  mining laser is refused: "This ship has no mining laser". The stock Salvage Tug carries no drill.
- **Mining focus.** A miner's Orders tab has a **Mining focus** drawer: pick the ores it should bring home (its jettison
  switch then dumps the other ore it cuts into a floating cargo pod). With **Auto-command fleet** on, your automation sets
  the focus of your miners that have none of yours to the ores your refineries are short of, and takes it off again when
  nothing is short ("(set by the automation)"); pick an ore yourself and the focus is yours. AI factions do the same.
  Ships with a hold (yours with Auto-command fleet on, and the AI's) also pick up floating cargo pods their sensors see
  nearby - never the cargo you jettisoned from your own stations.
- **One ship mines a rock at a time.** A miner that finds another ship (anyone's) mining its rock goes to a free rock
  nearby, or waits beside it: its activity reads "Waiting for Kestrel Miner #3 to finish mining".
- Ordering a ship to mine a busy rock still works: it waits its turn. The asteroid's inspector says who is mining it.

- **A full hold:** a salvaging ship of yours that leaves a wreck because its hold is full says so in the feed
  ("Salvage Tug #12 is full - 140 salvaged, 80 left in the wreck of a Corvette"). Zoomed far out, a wreck and the
  cargo pod it dropped no longer sit on top of each other: the pod's mark steps aside.

## Stations and outposts

- Your **capital** is your first (lowest-numbered) finished station. **Tab** cycles the camera through your
  stations.
- A **constructor** ship founds a new station: select it, press **F**, left-click a clear spot (or press Escape /
  right-click to cancel). It flies there and sets up a **construction site** (see below), which becomes an outpost
  when it is finished.
- A station under construction can be attacked; it has no guns and no shield. A finished station claims territory
  tiles around it (see Territory under [The screen](#the-screen)); it repairs ships **docked** at it only with a **repair bay** (see [Repairs](#repairs)).
- **Guns, shield, research and housing come from modules** you build (the base game gives your capital
  some of each, your supply station a gun and a shield, and a new outpost a hold, a gun battery and a shield generator): **Gun batteries** shoot at enemy
  ships in range (no battery: the station cannot shoot back), **shield generators** give the shield, **research labs**
  earn most of your research points, **habitats** house people (the population grows to fill them and adds a little
  research). The station's **Defence** tab lists its batteries and generators with their numbers, and the towers and
  mines you lay by hand.
- **Where you put a gun battery matters.** Each battery shoots from its own block and reaches only its range from
  there, so on a long station a battery at one end does not cover the other end. The batteries share one target
  (the nearest enemy ship, kept while any of them reaches it) and a battery that cannot reach it shoots the nearest
  enemy in its own reach. Enemy ships attack the block nearest them, not the centre: a station strung out with its
  only gun at the hub leaves its far end open. Spread batteries along a long station, and keep one near your docks.
  While you place a gun battery the map shows a dashed ring of what it will cover over the faint reach of the
  batteries you already have; automatic placement puts a battery where it covers the whole station best.
- **How heavily a station is fortified depends on its owner's temperament.** Computer factions add gun batteries and
  shield generators to their stations over time: a warlike faction fortifies heavily, a trading faction lightly and
  mostly at its capital and busiest stations, an expansionist one spreads its defences thin, and every faction answers
  the threats it knows of (a station shot at, a war, enemy stations or pirate hideouts it has charted nearby). No two
  factions are quite alike, even with the same personality. With **Auto-expand station** on, your own stations do the
  same, guided by your faction's personality sliders from the New game page; forbid or cap Gun Battery and Shield
  Generator in the build rules to keep the say yourself.

### Defence platforms

- A **defence platform** is a second kind of station: small, with a heavy gun battery, a shield and a small cargo
  hold. Research **Defence Platforms** first.
- **Found one** with a constructor: press **F** (or the Found station button) and choose **Defence platform** in the
  chooser, or press **L** to place one straight away; the chooser shows each choice's bill. It is built through a
  construction site like an outpost and may stand much closer to your stations than an outpost may.
- You can give a platform docks, repair bays, more gun batteries, shield generators and holds - not a yard, a lab or
  a habitat, and it builds no ships. Your haulers keep it supplied like any station. You can lay towers and mines at
  it by hand.
- A platform does **not** count as a station for victory or defeat: a faction whose last real station falls is out,
  whatever platforms it has left. The Empire dock lists platforms in their own group.
- The AI builds platforms too - more when it is warlike or at war - beside the station nearest its enemies, and a
  besieging fleet has to beat the platforms covering its target as well.


### Building your station out of blocks

A station is not one round shape: it is a **hub** with **blocks** attached to it - docks, ship yards and connectors -
and you decide where each block goes.

- Pick a station module in the **Build** gallery (or **Add a block...** on the station's **Layout** tab). The map
  zooms to the station, its free **attachment points** light up in cyan, and a ghost of the new block follows the
  cursor and snaps to the attachment point nearest it.
- **Green** = it fits there. **Red** = it does not, and the bar at the top says why: it would overlap a block, block a
  dock's mouth or a yard's launch side, or none of its attachment points faces that one. There is no size limit: a
  station can grow as big as you like (a mod can set one).
- **A bigger size is a bigger block**, so you can tell a module's size by looking at the station: a Tiny hold, gun,
  shield, habitat or amenity is 1 x 1 cell and a Huge one 3 x 4; a Tiny dock or repair bay is 1 x 2 and a Huge one
  4 x 4; a lab grows from 2 x 1 to 4 x 4; a yard or factory from 1 x 2 (Tiny) to 4 x 4. A bigger module needs more room.
- **E** or the **mouse wheel** turns the block a quarter turn. **Left-click** queues it at that spot; **Auto-place**
  lets the game choose a sensible spot; **right-click** or **Escape** cancels.
- A queued block remembers its spot (a dashed outline on the map; the Build tab says "at your chosen spot"). It is
  built there when its turn in the queue comes, and like every queued build it waits for its materials. If the spot
  is no longer free by then, the game puts it in the best free spot instead.
- **Docks** have a mouth: ships line up in front of it and fly in through it, so keep the space in front clear (the
  game will not let you build in front of a mouth). A bay's light shows green when it is free, amber when a ship is
  on its way in, red when one is docked. **Ship yards** launch their ships from their open side.
- A **Connector** is a cheap truss block with an attachment point on every side: string connectors out to put docks
  and yards wherever you like.
- The **Layout** tab shows a small plan of the station. Click a block there or on the map to see what it is (a dock's
  ship, a yard's job). **Dismantle block** takes a block apart and gives back half of its cost - only an outer block
  that nothing else hangs off, a dock no ship is using and a yard that is not building.
- **Selecting a block:** click a block on the map (or in the Layout plan). It gets a yellow frame and a soft yellow
  wash, and stays selected until you click elsewhere, select something else or press **Esc** (the first Esc only drops
  the block; the next opens the menu). The **Selected module** card at the top of the station's **Info** tab says what
  it is (name, kind, size, cells), what it does now in real numbers (a hold's room, a bay's repair rate, a gun's
  damage, cooldown and range, a shield's strength, a lab's research a minute, a habitat's housing, an amenity's
  attraction and medical care, a dock's or yard's largest hull and what it is doing), its staff and how well it works
  - or why it is **OFFLINE** (too few staff), **switched off** or short because the station's upkeep is unpaid - and
  its upkeep. On your own station it has **Switch off / on** and **Dismantle** buttons (a greyed Dismantle says why
  not). Every block, yours or a rival's, the hub and a block being built has an **Info** button: it opens the
  **Module window** with what the block is for and why you would build it, its size in cells, what it gives, for a
  factory the recipe per cycle and per minute and everything its ware is used for (factories, ships, ship modules,
  station modules), the build cost and time, staff, upkeep, power and the technology it needs. Esc or Close shuts it.
  The **Build** tab's module gallery has the same window behind each tile's **info** button. The block being built shows how far along it is. The line above the selection tray repeats the block's most
  important fact, so you see it even with the right-hand panel folded. A rival's block shows only its name, kind and
  size - what you can see from outside.

### Laser towers and mines

A station can ring itself with **laser towers** (an automatic point-defence gun on a stand that shoots the nearest
enemy in range; enemies can shoot it back) and **proximity mines** (a mine blows up when an enemy comes close; only
enemies set it off). You get them in two ways, by hand or automatically, and both draw on the same limit.

**By hand** (select your own finished station, open its **Build** tab, scroll to **Defences you lay**):

- **Lay laser tower** and **Lay mine** show how many this station has out of how many it may have ("3 / 5"), and the
  cost underneath (credits, materials, and for a tower how long it takes to build). A button is greyed with the reason
  when the technology is missing (towers need **Point Defence**, mines need **Minefields**) or the station is full.
- Click one: the map zooms out to show the station, a ghost follows the cursor (**green** = it may go there, **red** =
  the bar at the top says why not), and a dotted ring marks how far from the station you may build. **Left-click**
  orders it there; hold **Shift** to keep placing more; **right-click** or **Escape** cancels.
- You may put one anywhere inside the ring (900 units from the station's centre) **except**: on or right beside a
  block of the station, in front of a dock's mouth or a yard's launch side (ships come and go there), on the ring where
  ships wait for a free dock or on the ring where ships park (both are drawn faintly while you place), or close to
  another tower, mine or order of yours.
- It is **paid at once** from the station (credits and materials, exactly what the automation pays) and a tower is
  then built for about 50 seconds: a dashed marker with a filling bar shows on the map, and the Build tab lists it with
  an **x** to cancel (what you paid comes back in full). A mine is laid as soon as it is paid.
- **If the station cannot pay**, the order still goes in. It waits (the Build tab says "waiting for its materials and
  credits") and the station buys what it lacks, like any queued build, then builds it. Your orders ignore the credit
  reserve the automation keeps back and your **Build rules** - those only restrict what the automation does.
- **The limit is shared:** a station keeps at most **5 laser towers** and **4 mines**, counting towers that stand,
  ones being built and ones waiting. When it is full the button says so; **scrap** one to make room.
- **Scrapping:** click one of your laser towers on the map, then **Scrap tower** (press it twice to confirm). The
  station that laid it gets half its cost back.

**Automatically** (the station's **Automation** drawer, switch **Auto-deploy defences**): with the switch on, the
station lays towers and mines by itself, one every few seconds, until it reaches the limit. It does this only when:

- your faction has researched the technology (**Point Defence** for towers, **Minefields** for mines);
- your faction is **established**: the station has a ship yard big enough to build a Miner and your faction has at
  least 3 mining ships (before that every credit goes to the yard and the next miner);
- the station can pay: the same cost as laying one by hand, **and** it still has 1,500 credits left afterwards, so
  defences never starve your shipbuilding (this reserve does not apply to towers you order by hand);
- the faction's **Build rules** allow it (laser towers and mines can be forbidden or capped).

The automation fills a ring 350 units out (towers) and 520 units out (mines) and only the places that are left: it
never moves or removes a tower you placed, and a tower you ordered counts toward the limit while it is still being
built. Switch it off and it stops; what it already laid stays. Scrapping an automatic tower frees its place, so with
the switch on the station lays a new one.

### Scanner buoys (how to build one)

A **scanner buoy** is a small fixed sensor: your faction sees everything within **1,200 units** of it, as long as it
stands. Every faction starts with one (out toward the middle of the map); you can lay more to watch distant space -
the approaches to your stations, a wormhole mouth, the border with a rival.

**How to build one:**

1. Select one of your finished stations and open its **Defence** tab. Under **Defences you lay** press
   **Lay scanner buoy** (it shows how many buoys your faction has out of how many it may have, "1 / 8", and the cost:
   120 credits, 2 Scanning Arrays, 6 Steel). Laying buoys needs **Long-range Scanners** (Sensors).
2. The map zooms out round the station and a ghost buoy follows the cursor with **the ring it will see** (and a faint
   wider ring: no other buoy of yours may be inside it). **Green** = it may go there, **red** = the bar at the top
   says why not. Pan the map (or click the minimap) to aim far away.
3. **Left-click** to order it there (hold **Shift** to place more; **right-click** or **Escape** cancels).
4. The station pays at once (or, short of something, buys what it lacks first, like any queued build). Then **a ship
   of yours carries it out**: the station picks a free ship - a scout first, then a hauler, a salvager, a miner, a
   warship, a constructor last, the nearest first - that has an engine and fits one of the station's docking bays. It
   flies to the station, **docks in a bay** and takes the buoy aboard (a second or two), flies to the spot and drops
   it. The **Defences you lay** list says what is happening ("waiting for a ship to carry it", "Scout #12 is taking it
   aboard", "aboard Scout #12, 4200 units to go"); on the map a dashed marker with its ring shows the spot, with a line
   from the ship carrying it. The news says when it is dropped. Then the ship goes back to what it was doing.

**Where it may go:** **anywhere your faction has charted** (space your ships, stations or buoys have seen) - not only
near the station - but not on a station, and at least **1,500 units** from your other buoys (standing or ordered).

**The limit:** your faction may have **8** buoys in all (standing and ordered, from every station; your start buoy
counts). When it is full the button says so.

**Cancelling:** the **x** next to the order cancels it; what you paid comes back in full, and the ship carrying it (if
any) goes back to its own work.

**Losing one:** a buoy has a thin hull (60). A faction **at war** with you can shoot it down: its warships shoot a buoy
of yours they pass (only when nothing better is about), and you get a news line when one is lost. In peace nobody
touches it. You can do the same: right-click an enemy buoy you can see (a rival's buoy shows on your map while your
sensors reach it) with warships selected to attack it.

**Scuttling:** select one of your buoys (click its small square on the map) and press **Scuttle buoy** (twice to
confirm). It is gone, with its sight; nothing comes back (it is far from any station), but its place under the limit is
free. Selecting a buoy shows its owner, range, hull and the station that laid it.

**The AI builds them too:** a rival that is established lays a few buoys - more the less warlike it is - to watch the
approach to its stations, the wormhole mouths it knows and the border with rivals it knows, one at a time, and
replaces the ones it loses. Its buoys are carried out by its ships exactly like yours.

### Construction sites (outposts and jump gates)

- **What it costs:** an outpost or a gate has a bill of credits and materials (the placement banner and the button's
  tooltip show it before you send the constructor; in amber what is short right now: credits your faction pool does
  not have, materials your stations cannot spare). Your **faction pool** pays the credits when the site is set up, or
  as soon as it has them; no station's account pays for a site.
- **The constructor is not used up.** It takes along what of the bill fits its hold from the station it leaves,
  sets up the site, unloads into it and **stays to build it**. A site only makes progress while a constructor works
  at it; two or three constructors build faster. Give the constructor another order and the site pauses (its
  materials stay); right-click the site with a constructor (**help build**) to resume. When the site is finished
  the constructor is free for its next order (orders you queued behind it carry on).
- **Getting the materials there:** your cargo ships bring what is missing from your nearest station that has it to
  spare; your capital posts buy orders for what nobody has (traders bring it to the capital and your haulers carry it
  on); and you can deliver by hand - select a cargo ship and right-click the site ("deliver cargo").
- **Your own needs come before trade with others.** While a site of yours (or a station's queued build, or its food and
  medicine) lacks something one of your stations could spare, your free cargo ships take no new trade job; a trader already on a run finishes it, and
  the next free one goes to the site. Ships you gave an order (or fly by hand) are never taken: press **Clear orders**
  (X) to hand them back.
- **Who pays for the materials:** the station that gives a site its goods (the constructor's load, a supply run, a
  transfer you order) is paid by your **faction pool**, at the price sister stations pay each other. If the pool is
  empty it owes the station and pays it first when money comes in (the Money tab shows what it owes). What your
  capital buys from traders for a site is paid by the pool too.
- **Progress follows the deliveries:** the work can never get further than the share of the bill delivered, so a
  starved site visibly stops. Select a site to see its inspector: what it builds, progress and time left, the
  constructors working, the credits, a materials table (needed / delivered / on the way / on order) and what is
  holding it up in plain words, and what you can do about it ("Waiting for 80 Steel - 2 haulers on the way", "Still
  needs 18 Steel, nothing on the way - no hauler free: 2 traders are on trade runs for other factions (the next one to
  finish comes here); or deliver by hand", "the faction pool cannot afford the Steel (pool 0 cr): give the pool money
  or deliver by hand", "nobody you know sells Hull Parts ...", "Paused: no constructor working on it"). It speaks as
  soon as something is missing that nobody is bringing, before the work has caught up with the deliveries. On the map a site wears a progress ring: bright for
  the work done, faint for the materials delivered.
- **Cancel construction** (in the site's inspector; it asks once more) removes the site. Everything delivered is
  left in a **cargo pod** for anyone to salvage; the credits are lost. A site that is destroyed leaves its pod too.
  The feed tells you when a site is set up, gets its first delivery, is starving, is finished or is cancelled.
- Each of your ships has a home station; **B** sends the selected ships home.

**What a station is fitted with.** Select a station and read its inspector:

- **Defences:** every finished station has a built-in gun battery (it fires from its own block at the nearest enemy ship in its reach -
  damage per shot, shots per second and range are listed), a shield that recharges all the time (it grows with
  every module the station builds), the repair it gives ships docked at it (yours and your allies'), and - on your own stations - the
  laser towers and mines it has laid. A station still being built has no guns or shield yet.
  The guns kill attackers one at a time while every attacker fires at the station, so a station is a fortress
  against a handful of corvettes but falls to a big enough fleet (Cruisers with missiles count most). The AI
  sizes its attacks the same way: it sets out against a station only with a fleet that can break it, prefers
  outposts and stations it has already worn down, and does not sign a peace while it is about to take one.
- **Sensors:** every station, even one under construction, sees ships and stations within its scanner range.
- **Modules:** its docking bays (how many, how many are in use, by size, the biggest ship that can dock) and every
  module it has built, each saying what it gives ("Dock (Large) - adds a Large docking bay", "Ship Yard (Small) -
  builds ships up to Small").
- **Shipyard:** which ships its yard can build, and what it is building now.
- **Build times:** everything being built says how long it has left at normal speed rather than a percentage -
  "Corvette - 32 s left" in the yard, "Building: Ship Yard (Small) - 39 s left" for a module, "under construction -
  1 min 05 s left" for a new station or a jump gate.
- **Station names on the map:** zoomed out, each station shows its faction's name. Where several stations sit
  close together the names stack in a short column under their icons
  instead of piling on top of each other.
- **On the map**, the selected station shows its **gun range** (a solid red outline: a ring round every gun battery,
  drawn as one shape, labelled with the reach and the number of batteries) and its **scanner range** (a
  dashed blue ring), each labelled. The "scanner rings" checkbox still shows the faint scanner rings of all your
  units, buoys and stations. A selected scanner buoy of yours shows its scanner range too (a dashed ring in your colour,
  labelled "Scanner 1,200"); a rival's buoy shows none. A buoy being placed, or ordered and not laid yet, shows the same dashed ring.

- **Loading the kit:** a constructor ordered to found an outpost or build a gate first takes what of the bill fits
  its hold from your nearest station within 3,000 (it flies there and docks first if it is not already in a bay) - at
  the normal transfer rate, waiting at the station ("loading materials for the new outpost at Cinder Station (120
  loaded)") - then flies to the site. A constructor farther out than that leaves with an empty hold and your haulers
  bring the bill.

## Selected ships on the map

- **Where it is going:** every selected ship you may see (your own and your allies'; any ship when you watch without
  playing a faction) draws a **dotted line to where it is flying**, ending in a small diamond - whatever is driving
  it: your order, its fleet, or its own work (a mining trip, a trade run, a scout's next unexplored spot). A ship
  flying home for repairs draws its line in **green**. A route through a wormhole or jump gate is drawn in legs:
  dotted to the mouth, a dashed jump, dotted on from the far mouth.
- **What it sees and reaches:** the selected ship also shows its **scanner range** (dashed blue ring) and, if it is
  armed, its **weapon range** (solid red ring) - its real ranges, with module tier, power and research counted.
  With one ship selected the rings are labelled; with up to six selected each gets its rings; select more and only
  the lines are drawn, so the map stays readable.

## Docking

- **The rule: a ship must be docked in a bay of a station before it can do anything there.** Unloading ore,
  loading and unloading a supply run or a cargo transfer, buying and selling (at your stations and at other
  factions'), taking a constructor's materials aboard, refits and repairs - all of them happen only while the ship
  is parked in a bay. Floating next to a station does nothing, and nothing ever ties up on a station's hull.
- **A ship is always in one of three places at a station:** flying in to a bay that is reserved for it ("approaching
  bay 2 of Kestrel Reach"), parked in it ("docked at Kestrel Reach - unloading 60/120 aboard (5 s left)"), or
  waiting in the docking queue outside the station ("waiting for a berth at Kestrel Reach (3rd in line)").
- **Bay size is real.** A ship fits a bay of its own hull size or larger. A ship too big for every bay of a station
  cannot use it ("no dock large enough at Port Halcyon (needs a Large dock)"); a ship on its own goes to another of
  your (or an ally's) stations that has one. If none has, it waits off the station and you get one warning:
  "Cruiser #12 cannot dock anywhere: build a Large dock".
- **Who may dock:** your ships and your allies' always; another faction's trader may dock to buy and sell when a bay
  is free, as long as you are not at war - a faction at war is refused a bay.
- **A station is sanctuary for its guests.** Attacking a ship docked at a station is attacking the station's owner.
  So a ship parked in a bay of a station is safe from everyone who is **not at war with the station's owner** - even
  from factions at war with the ship itself. Nobody's ships, turrets, fleets, standing orders, towers or station guns
  pick it, no shot lands on it and no mine of theirs hurts it. Protection starts the moment the ship is in its bay and
  ends the moment it leaves it; flying in to a bay, waiting in the docking queue or sitting on the parking ring is not
  protected. It works the same at your stations, your allies' and anyone else's.
  - **Docking at a station that is at war is at your own risk:** whoever is at war with the station's owner may attack
    every ship docked there - and pirates are at war with everyone, so they may raid ships in any major's bays.
  - **Your orders:** right-clicking a ship that is protected says why instead of attacking: "Docked at Kestrel Reach
    (Hegemony): attacking it would be an attack on Hegemony - declare war on Hegemony first". If you really mean it,
    declare war on the station's owner in the Diplomacy screen (F1); then the attack goes through. An attack order
    already running ends when its target docks under someone's protection.
  - **Both ways:** a ship of yours docked at another faction's station does not fire from the bay at anyone who is not
    at war with that station's owner.
  - **The host answers:** when an enemy of yours attacks a ship docked at your station, your station counts as
    attacked - its guns fire on the attacker, your fleet commander and your allies respond as for an attack on you,
    and the news says "Red Pact attacked a Hegemony ship docked at your Kestrel Reach - an attack on you". When your own
    ship is attacked while docked at someone else's station, you hear of it too. A docked guest's inspector says
    "Under Hegemony's protection".
- **The docking queue:** a ship that finds every bay that fits it taken **waits in line outside the station**, on a
  ring of slots a little way off the hull, one beside the next. Your own ships and your allies' stand ahead of
  foreign traders (for up to a minute - after that a foreign trader takes its turn too); otherwise first come, first
  served. When a bay frees, the first ship in line that fits it flies
  in and everyone behind moves up one slot. A newcomer never jumps the queue. A ship just built waiting in the yard
  to launch takes the next bay that fits it ahead of the whole queue ("waiting for a free bay to launch" in the
  Build drawer).
- **A bay is freed the moment the job is done** - the hold is empty, the cargo is aboard, the hull is repaired, the
  refit is finished. A ship that only has to wait does it in the queue, never in a bay.
- **The parking ring:** ships you send to a station (move, guard, rally, return home) or that run to it for safety
  wait on a wider ring of slots around it, never on its centre. A damaged ship that runs to a station for safety
  waits there too (inside the station's cover, ready to fight) and does not take a bay; a ship that needs repairs docks
  for them as usual.
- **The Docks tab** of a station lists every bay - its size, which ship is in it and what it is doing with the time
  left, or "free" - then a ship waiting in the yard to launch, then the queue in order with how long each has waited.
  The station tray's cards show the docked, approaching and waiting ships too.
- **Undock:** select one of your ships that is docked (or waiting) and press **Undock** in the right dock's action
  row. It leaves the bay at once and gives up what it was there for (a repair trip, a refit not yet paid for, a
  supply or trade run, a transfer); a refit already under way cannot be stopped. A miner with ore aboard will come
  back to unload it.
- **More docks** (the Dock station module, in the build gallery) shorten the queue; the AI builds another dock when
  its queue stays long.

## Waypoints

- **Hold Shift and right-click** to add a waypoint: the order is queued behind what the ship is doing now instead of
  replacing it. It works for every order - move, mine an asteroid, attack, escort, dock and repair at a station,
  travel through a wormhole or gate - for one ship, several ships, or a whole fleet (the fleet's waypoints are
  queued for the fleet).
- The selected ship's dotted line goes on through **every waypoint in order**, numbered 1, 2, 3 on the map.
- The inspector lists them ("then: move to (12000, -400); then mine Asteroid #12") and shows **Shift + right-click:
  add a waypoint** as a reminder, and a **Clear waypoints** button that drops the queue (the current order stays).
- A plain right-click (no Shift) replaces the order and its waypoints; **X** clears everything.

## Repairs

- **A ship is repaired only while it is docked** in a bay of a finished station of your own or an ally's that has
  a **repair bay**. Floating next to a station does nothing, and a station without a repair bay repairs nothing
  ("no repair bay at X"; ships head for the nearest station with one). More repair bays repair faster.
- **Repairs cost materials:** mending a whole hull uses about a quarter of the ship's build materials (in units),
  taken from what the station holds most of. A station with an empty store cannot repair: the ship leaves
  ("repairs waiting for materials"). At an ally's station you pay the ally for the materials in credits.
- **Warships break off on their own** when their hull drops below what their crew will take (timid crews earlier,
  bold ones later). They fly to the nearest friendly station, dock, repair to 90 % and then go back to what they
  were doing: a fleet member rejoins its fleet, a ship you had given an order carries it on.
- **You can send any damaged ship yourself:** right-click one of your stations (or an ally's) with it selected. It
  docks and stays until fully repaired.
- **What it says:** the inspector's activity line reads "returning to Station #3 for repairs", then "docked at
  Station #3 - repairing (hull 61%, 40 s left)". The Empire list says it too: "repair trip", "docking",
  "repairing" or "waiting".
- **No free bay?** The ship joins the station's **docking queue** ("waiting for a berth at Station #3 (2nd in
  line)") and waits its turn. A ship too big for every bay of the station goes to the nearest of your (or an ally's)
  stations that has a bay big enough; with none, it waits and you are told to build a bigger dock.
- **A station under fire repairs slowly:** while it has been hit in the last 10 seconds, its crews repair docked
  ships at a quarter of the usual rate (yours, and the AI's defenders alike).

**How to survey an asteroid.** Fly any ship with a survey radar (Scouts and Miners carry one) within the radar's
range of the rock: its Survey range is shown in the module card (1,500 for the stock Survey Radar). The radar surveys
every rock that comes that close, whatever the ship is doing (flying past, holding, mining or docked); you do not
have to stop at a rock or order anything. Only your own ships' radars survey for you, and a ship with no power at
all surveys nothing.

**Asteroid colours.** A rock your faction has surveyed is tinted by the ore it holds (the colours are the
materials' colours; the key is on the **Market** screen, F2). A rock you have only spotted stays grey, and a rock
that is nearly mined out fades back to grey. Watching the AI without playing a faction, every rock any faction has
surveyed is tinted.

**Asteroids when zoomed out.** Rocks fade as you zoom out, but a rock your faction has **surveyed** keeps a small,
dim dot in its ore colour at every zoom (like mines and scanner buoys keep their marks), so you can see where your
known ore is from far away. Rocks you have only spotted still fade away, and nearly mined-out rocks are dropped. At
whole-map zoom the dots are thinned to one per few pixels. A rock drawn as a dot can be clicked (and right-clicked to
mine it); ships, stations and wormholes under the cursor still come first.

**Ore survey: what do the rocks around me hold?** Press **Y** (rebindable on the Controls screen) for the **Ore
survey** window: for a set of rocks it lists every ore with the **units** left, its **share** of all the ore counted and
how many **rocks** hold it, biggest first, so you can see which ores are plentiful before you decide what to build and
where. Pick what it covers with the chips at the top:

- **In sensor range** - the rocks your scanner ships, scanner buoys and stations cover right now.
- **All charted** - every rock on your charts, near or far.
- **Area** - an area you pick on the map. **Drag a box** over some rocks with **none of your ships** in it and the
  survey of that area opens by itself (a box that catches your ships still just selects them). Or press **Pick area**
  in the window: the next box you drag only sets the area and leaves your selection alone (Esc stops picking).
- **Near station** - the rocks within reach of one of your stations' miners (the distance a mining ship works from
  its home station, 5,000 units by default). Select one of your stations and press **Ore nearby** in its panel.

It only counts what your faction **knows**. Rocks you have never charted are not there for it; rocks you have charted
but not surveyed (analysed) are listed as a number of **unknown** rocks, and their ore is never counted. A surveyed rock
your sensors cover now counts with the ore it holds now; one outside your sensors counts **as last seen** (the window
says how many - someone may have mined them since). Ores marked **no refinery** are ones none of your stations can
refine at the moment. **Click an ore's name** to open its Reference page: which factories take it and what it is for.
The numbers refresh every couple of seconds while the window is open; **Close** or Esc shuts it.

**Field types.** In the Random galaxy and The Expanse every random asteroid field (not your home field) has a type, and its
rocks are rich in that type's ores: a **metal-rich field** in Iron and Tungsten, a **silicate field** in Silicon and
Aluminium, a **carbonaceous field** in Carbon and Copper, a **heavy field** in Uranium and Tungsten, an **ice field** mostly in Ice (for Water), and its rocks hold about twice the ore of another field's.
Rich, not only: a field still holds some of the other ores. Random fields keep well away from every start, so ice lies
further out. Your home field, the two starter rocks by your station and the lone rocks between the
fields hold the usual mix. You learn a field's type once you have **surveyed one of its rocks**: from then on a rock's panel
says "In a metal-rich field (rich in Iron and Tungsten)", the Ore survey says which field types its rocks lie in ("Field
types here: 2 metal-rich fields and 1 heavy field."), and the map labels the field by its type. Every type turns up in at
least two fields on a map with enough fields. On a map with fewer (the Small galaxy has eight random fields for five types),
every type gets one field first and the rest go to the types in their listed order (metal-rich, silicate, carbonaceous,
heavy, ice), so the Small galaxy has two each of the first three and one heavy and one ice field; the page only warns when
there are fewer random fields than types (that rule is the lead's decision, not the owner's). Set them on the New game page under **Rocks and ores...**, section FIELD
TYPES: switch them off (every field holds the usual mix), make them stronger or weaker, or leave a type out.

**Station badges** (on a zoomed-out station icon):

- **Top right**, in the faction's colour: how many ships are docked there.
- **Top left**, amber **+N**: how many ships it is building - the one in its yard plus the ones queued behind it.
- **Bottom left**, teal with a small block: how many station modules it is building - the one under way plus the
  queued ones.
- A station builds one ship and one module at a time; only your stations have a queue behind them, so an AI
  station shows 1 at most. A badge at zero is hidden, and a station that is itself still being built shows only its
  progress bar. You see what your own and your allies' stations build (all of them while watching without a
  faction).

## Fleets

- **Create a fleet:** select ships and press **G** (or **Create fleet** in the right dock's Orders tab, or the
  **Fleets** panel). The Fleets panel (**Fleets** in the top bar) is the overview: every fleet with its ships, hull,
  stance and order, and your transfer routes; click a fleet to select it. Its stance, formation, name and Disband are
  in the right dock's **Fleet** tab.
- **A fleet with no ships left is deleted** (its ships destroyed, or all taken out of it); the notifications say so
  when they were destroyed.
- **Stances:** Aggressive (engages anything hostile its sensors see), Defensive (fights only what attacks it or
  what it guards) and Passive (never engages; when attacked it pulls back to the nearest own station).
  **V** cycles the stance of the selected fleet; the right dock's Fleet tab shows the current one.
- **Formations:** Wedge or Line.
- **Orders:** with the whole fleet selected, right-click moves it in formation. Hold **Alt** and right-click to
  attack-move, **Shift** to queue a waypoint, **P** to add a patrol point; right-click one of your ships to guard
  it. **H** holds position, **X** clears orders. (These P / guard orders are one-off direct orders; for a patrol or
  guard the fleet keeps and returns to, give it a standing order, below.)
- **Standing orders:** what a fleet keeps doing until you change it, and goes back to by itself after anything
  interrupts it. Select the whole fleet; the Orders tab's **Standing order** block says the order and what the fleet
  is doing right now ("Patrol - 3 points, loop; now: chasing Corvette #12, returns after"). **Change** (key **U**)
  opens the choice; the digits **1-8** (or the buttons) pick one:
  - **Patrol:** click the route's points on the map (numbered as you click), then **U**, **Done** or a right-click.
    It flies the route round in a loop, or back and forth (switch it under Change).
  - **Guard:** click one of your stations, gates, construction sites or ships. It holds beside it (outside the
    station's parking ring) and goes for what attacks it or comes within the guard radius.
  - **Escort:** click one of your ships (a ship in a fleet: that whole fleet). It flies close to it and protects it.
  - **Defend:** click a point. It holds there and intercepts whatever hostile enters the radius (default 3000).
    While it is on station it also goes after any hostile ship its own sensors see, pirates included, even just
    outside the radius; it never chases further than twice the radius from the centre (6000 by default), then comes
    back. The order line says it: "Defend an area (x, y), radius 3000, chases to 6000".
  - **Hunt:** click one of your stations (or **U** for the fleet's home). It waits there and goes after hostile ships
    seen within the radius.
  - **Picket:** click a wormhole or jump gate you have charted. It holds just outside the mouth and stops what comes
    through.
  - **Blockade:** click a foreign station you know. It holds a ring outside the station's guns and stops the hostile
    ships that come and go (traders included). It never attacks the station itself: that is a direct order.
  - **Idle at home:** it waits beside its home station.

  Under **Change** you also set the **radius**, the **repair line** ("Repair below 40%": a ship under it docks in a
  bay to repair, then comes back; "crew decides" leaves it to the crew) and loop or back and forth; **Clear it**
  drops the order. **Esc** closes the choice or cancels a pick.
- **Interruptions:** any direct order (move, attack, hold...) interrupts the standing order; the Orders tab and the
  Empire list say "then back to: Patrol". When the order is done the fleet resumes the standing order by itself.
  **Hold** never ends on its own: **Resume it now** (or **X**, clear orders) sends it back. After a fight the fleet
  returns to its post; it never chases further than its leash from it. Ships away for repairs rejoin when repaired.
  If what the order is about is lost (the guarded station, the escorted ship), the order ends and the fleet holds.
- **What a standing order fights:** only hostile ships your faction can see (your ships', stations' and buoys'
  sensors) - never anything unseen, and never a station. Pirates count as hostile everywhere. A **Passive** fleet
  never picks a fight; it withdraws when hit. With **Aggressive** (and Defend, on station) it also engages what its
  own sensors see within its leash.
- **Manual ships** in a fleet fly with it on its standing order but take no initiative: they do not join a chase
  the order picked (they hold and answer fire) and are not sent to repair.
- While the fleet is selected, the map shows its standing order: the numbered patrol route, the guarded / defended /
  picketed area as a dashed ring (a Defend order also a fainter outer ring for how far it chases, labelled "area
  3000 - chases to 6000"), the blockade ring, a dotted line to its post or charge, and a line to whatever it
  is chasing. A fleet on a standing order counts as yours to command: the automation never borrows its ships.
- An order to the whole fleet goes to the fleet; an order to some of its ships goes to just those ships, and a
  ship's own order outranks its fleet's.
- **Rally points:** with only a station selected, right-click in space. Its **Rally Point** drawer can also put new
  ships straight into a fleet, or clear the point.

## Research

- **Other factions' research:** the Empire dock's Factions tab (its Research section) and the Diplomacy screen (F1, the selected
  faction's **Research** block) show what a faction researches. **Knowledge rule:** you see your own and your
  **allies'** research in full; for any other faction you only read "Research unknown - not an ally". Watching
  without a faction, you see everyone's. **View tech tree** opens that faction's tree on the Research screen
  **read-only** (a banner says whose it is; no Queue, Cancel or Auto-research).
- **T** (or the **Research** button) opens the Research screen: the technology tree - 60 technologies - in
  ten branches (Hulls, Weapons, Energy, Missiles, Defence, Propulsion, Sensors, Industry, Logistics, Stations; the
  coloured strip on the left of each box is its branch, named in the legend above the tree). Every
  technology unlocks something you can see (a ship, module, hull size, factory or station module); a bonus such as
  "+5% weapon damage" always comes with an unlock (the one exception is Automated Yards, which capital hulls need). Green
  technologies are known, the blue one is being researched, amber ones are queued, white ones can be researched now,
  grey ones need a prerequisite first and red ones are closed (only a mod closes technologies). A violet right edge
  marks a doctrine. The tree reads left to right: every prerequisite is a line from its right side into the
  technology it opens (the arrowhead), each with its own lane, so everything a technology needs sits to its left.
  "unlocks N" on a box counts the ships, modules and buildings it unlocks. **Click** a technology,
  or rest the mouse on one for a moment, and the tree lights up around it: the lines of everything it needs, all the
  way back, turn bright - green from a known prerequisite, amber from a missing one - and the lines to what it leads to
  blue; the boxes are outlined the same way, and technologies that its unlocks ALSO need ("unlocked together with",
  e.g. a ship that needs Turret Mounts and Heavy Hulls) are outlined pink; the rest dims a little (names stay
  readable). Click an empty spot
  in the tree to see the whole tree undimmed again. The details column lists **Needs** and **Leads to** with each
  technology's state ("known", "being researched", "queued #3", "not yet"); click one to jump to it. A technology no other one requires
  says so, how many things it unlocks, and lists the technologies those also need ("Heavy Hulls - for Freighter,
  Mining Barge"). **Hold the right
  mouse button and drag** to move the tree (it follows the mouse; a right click without a drag does nothing, and the
  map behind does not move). The mouse wheel scrolls the tree too; **Shift** + wheel (or the arrow buttons) scrolls it
  sideways. **Find** filters the tree by name, branch, fork or what a technology unlocks ("railgun", "missiles",
  "armour") and jumps to the first match.
- **Doctrines: three groups of specialised technologies. None closes another - you can research them all and field a mixed fleet:**
  - **Weapons doctrine:** *Mass Driver Doctrine* (railguns, siege artillery, the Hammer and Siege Cruiser: heavy hits
    that wreck hulls and stations, blunted by shields), *Directed Energy Doctrine* (pulse and beam lasers, plasma, the
    Lancer and Beam Cruiser: strip shields, weaker on bare hull, hungry for power) or *Missile Warfare Doctrine*
    (swarm pods, torpedoes, the Missile Frigate and Torpedo Cruiser: long reach, countered by point defence, decoys
    and jammers).
  - **Defence doctrine:** *Shield Supremacy* (Bastion and Phase shields) or *Heavy Armour Doctrine* (reactive armour,
    heavy plating, the Ironclad).
  - **Fleet doctrine:** *Fast Raiders* (the pulse booster and the Raider, with 5% less hull damage) or *Heavy Line*
    (the long-burn drive, with 10% more weapon reach; the drive also needs Advanced Refining for its Fuel Rods).
  Each doctrine technology unlocks its first ship or module at once (Directed Energy Doctrine gives you the Pulse
  Laser, the Laser Turret and the Lancer). Each doctrine's top technology is its capstone, with the big bonus: Siege
  Artillery, Beam Focusing, Heavy Torpedoes, Phase Shields and Heavy Plating.
  The AI factions prefer the doctrines that fit their character, so a warlike neighbour may field railguns first while a
  trading one fields lasers first. (A mod can still make two technologies close each other; such a technology says what it
  would close, and **Queue** asks for a second press.)
- **Click a technology** to see what it is, what it costs, how long it will take at your current rate and exactly
  what it unlocks (ships, modules, factories, hull sizes, defences, bonuses). **Queue** adds it to the end of your queue -
  with any prerequisite you are missing queued ahead of it. The queue at the bottom can be reordered (**^**) and
  emptied (**x**); cancelling a technology also cancels what was queued after it that needs it. Points already put
  into a technology are kept.
- **Research points** come from your finished stations: every station earns some, and more people earn more.
  Points you earn while nothing is queued are kept (up to a limit) for the next technology.
- **Middle and late technologies also cost wares** (every technology of 150 points or more: two wares, for example
  Shield Manufacturing 2 Plasma Conductors and 2 Microchips, Phase Shields 19 Shield Components and 19 Field Coils). Your
  **capital** pays them from its own store when research on the technology starts; the details panel shows the bill
  ("plus 2 Plasma Conductors, 2 Microchips from the capital's store when it starts"). The wares are always ones you can
  already make with what that technology needs first, never raw ore. Until the capital holds them the technology waits:
  its node reads "Waiting for wares", and the queue strip and details say what is missing with numbers ("Waiting for
  wares at Rook Spire: Microchips 0 of 2 - on order"). The bill counts as one of your capital's queued needs, like a queued build's
  (supply runs and buying for queued builds gather it where you have them switched on), and your advisor lists a research held up this way. Research picked by
  **Auto-research** never takes a ware below the stock reserve you set at the capital (it says "holding 20 Microchips in
  reserve (your reserve)"); research you queue yourself may use reserved stock. When Auto-research cannot pay its choice,
  it researches a technology it can pay in the meantime; it never reorders what you queued yourself.
- **Research you queued yourself moves on while #1 waits for wares.** When the first technology in your queue cannot be
  paid, research works on the next technology in your queue that can start (its prerequisites known and its bill, if
  any, payable now), in your queue's order. Your queue's order does not change: #1 keeps its place, its node still
  reads "Waiting for wares" and the queue strip shows it in the waiting colour, while the one being researched is
  highlighted and its details say "Being researched now (while #1 waits)". The details of #1 say what is missing with
  numbers and that it starts once the one being researched is done and the capital can pay. A technology already started
  this way is finished first. If nothing in your queue can start, research waits as before (points go to the bank). Moving
  the one being researched to the top of the queue makes it #1.
- **Auto-research** (on the Research screen, or the station's Automation drawer) lets the AI pick your next
  technology whenever your queue runs empty. It starts switched on.
- **What you start with:** no technology at all. What every faction can build from the start needs none: Small and
  Medium yards, docks and ships, the forward gun, shields, mining, couriers and station cargo holds. Turrets (Frigates, Laser Towers), constructors, Large and Huge hulls, missiles, drones
  (Carriers), mines, Mk2 module upgrades and the bonuses (faster mining, building, shields, scanners, research)
  are researched. The AI factions research too, each by its own priorities.

## Ship Designer and refits

- **F6** (or **Ship Designer...** in the build gallery) opens the designer. You do not start from a stock ship:
  1. **Hull size.** Pick a size. Sizes you have not researched yet are greyed out.
  2. **Hull.** Pick a hull of that size. Its card shows the picture, its hardpoints in words, hull strength, the
     hull's own cost and crew. A hull you have not researched is greyed and says "Needs ..."; you can still pick it
     and try fits on it, but not save it until it is researched (**Research...** opens the Research screen on it).
  3. **Mounts.** Every hull has one **engine mount**, one **thruster mount** and a number of free **hardpoints**
     (a Scout 7, a Frigate 12, a Cruiser or a Carrier 16). Click a mount in the list, or a socket on the hull
     picture, then pick a module. The engine mount takes only an engine and the thruster mount only a thruster -
     every ship needs both. Anything else goes on any hardpoint big enough for it. A new design starts with the
     hull's stock ship's modules on it, so you can change just what you want.
  4. **Role.** What your ships will do with it unordered: carrier, warship, mining, salvage, trade, recon or
     constructor. Only the roles the fit allows are offered (a warship needs a forward gun, mining a drill and a
     hold, salvage a tractor beam and a hold, trade and constructor a hold, recon a scanner, a carrier a drone bay).
     The first one offered is picked for you.
  5. **Name** it and **Save** (or **Save as new**).
- **The readout** on the right updates as you fit: the cost (credits, materials, yard time), the yard and dock size
  needed, hull, shield and crew, speed and turning, power used of what the engine makes, the guns, turrets and
  missiles (damage a second and range), cargo, mining and scanner range, and countermeasures, drones and tractor
  beam.
- **Why Save is greyed:** the **CHECKS** list says why - an empty engine or thruster mount, a module too big for
  its hardpoint, too many armour plates (at most 3 per ship), **not enough power** (the modules draw more than the
  engine makes), no job yet (nothing a role needs), or something not researched. A warship with no shield is only
  a warning.
- A saved design appears in the **build gallery** next to the stock ships, and **Build one** queues it at your
  selected station.
- **Refit:** select one of your ships and open its **Refit to...** drawer. It lists the designs of the same hull
  **and** role with what the refit adds, removes and costs. To change a ship's role, build a new one. The ship flies
  to a station with a bay big enough, **docks** (the refit holds that bay while the work goes on, so give busy
  stations more docks) and is out of action until the work is done; **Cancel refit** calls it off before it is paid
  for. Once it is paid and under way, Cancel refit asks first (the work done is lost); the ship keeps its old modules,
  the station gets back the materials it paid and gives back what it had recovered from the modules the refit would
  have taken out.
- The AI never designs ships; it builds only the stock ones.

### Choosing equipment

Every hardpoint offers several modules with different trade-offs, not just bigger numbers. The designer compares
the module you pick with the standard one of its kind (damage a second, range, how it fares against shields and
hull, power), and the **info** button opens the module window with every number.

- **Three weapon families.**
  - **Kinetic** (Gun, Autocannon, Railgun, Siege Turret): good against bare hull, blunted by shields. The Railgun
    and the Siege Turret hit very hard from far away, but turn too slowly to follow a small ship darting across
    their view - they are station breakers and big-ship killers.
  - **Energy** (Pulse Laser, Beam Laser, Plasma Blaster, Laser Turret): strip shields fast but do less to bare
    hull, and draw a lot of power. The Plasma Blaster has the most damage a second of any gun, at close range.
  - **Missiles** (Missile Launcher, Swarm Pods, Torpedo Tube): the longest reach and a heavy first salvo, then a
    slow reload; countermeasures, jammers and point defence stop many of them.
    Swarm Pods swamp shields with many small hits; a Torpedo smashes a station or a big hull, but a darting small
    ship slips most of it.
- **Engines:** Economy (cheap, a little slow), Cruise (a quarter faster, much less power), Combat (slower, 40% more
  power), Fusion (faster AND more power, rare metals). **Shields:** Reactive (thin, fast recharge), Bastion (huge,
  slow recharge), Phase (both, dear). Scanners, survey radars, holds, drills, thrusters, countermeasures and drone
  hangars each have cheap / standard / big versions too.
- **Power matters.** A stock ship's engine makes about half again what its own modules draw. Fill it with heavy
  guns, big shields and wide scanners and it runs **under-powered**: weapons, scanners and drills work at the
  supply/demand ratio. The designer will not save a design like that; fit a Combat or Fusion Drive to feed a heavy
  loadout.
- **Hardpoints.** Each hardpoint is small, medium or large. A heavy module (the Railgun, Siege Turret, Torpedo
  Tube, Heavy Hangar...) needs a large one: only Large and Huge hulls (and the Constructor and Salvage Tug) have
  them, so a Corvette cannot mount a Railgun but a Cruiser can. Apart from size, any module goes anywhere: a frigate
  can carry a drill, a freighter a gun. The designer draws the hull with its numbered sockets, lit green as you fit
  them, and a module too big for the chosen hardpoint says so.
- **Armour** stacks without using power, so a ship carries at most 3 armour plates.
- **Armour, afterburners, repair kits and jammers.** *Armour* plates add hull and take a flat amount off every hit
  (light guns barely scratch armour) but slow the ship. An *afterburner* gives a burst of speed: your crews fire it to
  catch a target or escape when badly hurt, and **N** fires the selected ships' afterburners. A *field repair kit*
  mends the ship, or a damaged friend close by, away from a dock - slowly, and it pays with materials from the ship's
  own hold (a warship refills its hold at your stations); a Field Tender keeps a siege line patched. A *jammer*
  makes enemy weapons reach less far against the ship and throws enemy missiles off. *Point-defence turrets* shoot
  down half the missiles aimed at their ship, and *laser turrets* shoot down some: a missile shot down ends in a small
  bright ring short of its target.
- **What beats what.** No family wins everything; each has an answer:
  - **Kinetic beats energy:** lasers come in many small hits, and armour takes a flat amount off each one. The
    Hammer (autocannon, turret, armour) beats the Lancer.
  - **Energy beats missiles:** laser turrets shoot missiles down and lasers strip the shields missiles rely on. The
    Lancer beats the Missile Frigate; the Beam Cruiser beats the Torpedo Cruiser.
  - **Missiles beat kinetic:** a missile salvo lands from beyond gun range on a slow, armoured ship. The Missile
    Frigate beats the Hammer; torpedoes break the Ironclad's heavy plating.
  - **Shields stop kinetic, energy strips shields:** the Bastion Cruiser shrugs off the Siege Cruiser's slugs but
    falls to the Beam Cruiser; heavy armour (the Ironclad) does the opposite.
  - **Point defence answers missiles:** the Picket escort (two guns, a point-defence turret and a jammer) holds off
    Missile Frigates but loses to plain gun ships.
  - A missile launcher fires its magazine in a quick salvo, then reloads slowly; a ship with two launchers fires
    both at once and empties twice as many rounds. Ships close until every forward gun reaches, so a short-range
    gun on a long-range ship still gets to fire.
- Advanced modules need research (the choice says what it needs, and a module behind a fork you closed says which
  fork closed it).

## Trade and the Market

- **Your traders only go where your faction has been.** A courier or freighter trades only with stations your
  faction has found (by scouts, buoys, any of your ships passing by, or a shared map). Until you know a buyer for your
  surplus, an empty trader helps look for one: it flies out to chart space your faction has not seen yet, within
  about 60,000 units of its home station (its orders read "Explore"), at most two traders at a time. It never flies to
  a station you have not found; it only charts the edge of your own map. The moment a buyer is charted it comes back
  to work. With nothing left to chart in reach it waits off its home station ("waiting for available trades").
- Every station has a **Trade** drawer with a policy per material:
  - **Auto** - the station orders what it is short of for its builds when it can afford to.
  - **Buy up to target** - posts a buy order; other factions' traders and your own free haulers fill it.
  - **Sell above target** - offers everything above the target.
  - **Hold (never sell)** - keeps it all.
  - The **-** / **+** buttons change the target.
- **Stock reserves.** Each row of the Trade drawer also has **Reserve [-] [number] [+]** (steps of 25, or type a
  number). The row then reads "stock 340, reserve 200". Nothing automatic takes that ware below the reserve at that
  station: not the station's manager (what it builds or orders), not the automation switches (auto-build ships,
  expand station, defences, refits, outposts and their kits, supply runs to your other stations and sites), not
  automatic repairs, and not traders or markets buying from the station (yours or anyone's). **Your own orders may
  use it:** ships and modules you queued, refits and repairs you ordered, cargo transfers, purchase orders and trade
  runs you placed. What is held back says so, for example "holding 200 Steel in reserve (your reserve)" in the
  manager's Now line and the Build drawer.
  - Not held back by a reserve: your factories using their inputs, and your people's food, medical supplies and
    energy.
  - **Copy these reserves to all my stations** gives every other station of yours this station's reserves;
    **Use these reserves for new stations** makes every station you found or take afterwards start with them.
  - A reserve is not **Hold**: Hold stops selling a ware and giving it to supply runs, but the station's own
    automatic builds still use it; a reserve also stops those, while your own orders still may use it.
  - Every station's manager also keeps a reserve, other factions' and yours: what its queued builds and
    factories need and 10 minutes of its people's food, medicine and energy. That is not sold or given away, but
    the station's own builds may use it. On your stations, a number you set replaces the manager's for that ware
    (0 too), and the drawer says whose it is ("Steel 200 (yours), Food 40 (manager)"). Beside each reserve the row says "spare N" (what automation may still use) or "held".
- The **Market** (**F2**) lists every station your ships have seen, with the prices they had then. Filter by
  material and sort by price or distance.
  - **FOR SALE** is what a station will actually sell you: its stock above what it keeps for itself (its builds,
    factories, reserve) and what is already held for other orders. Another faction's station shows what it had for
    sale when your ships last saw it (SEEN); your own station shows what can be taken from it now.
  - A station that sells none of a ware shows **"-"** and no **SELLS AT** price (greyed); one that does not buy a ware
    shows "-" under **BUYS AT**. "?" means a station charted in an older save: a ship must see it again.
  - Sorting by **Sells** puts the rows with nothing for sale last.
- **Buy here and deliver:** select one or more of your freighters or couriers, open the Market, click an offer and
  a station to deliver to.

### Trade routes with several stops

- **Traders make several stops per trip.** A trader buys at one station, sells part of its load at the next, fills
  the room that frees up with goods for a stop further on, and so on (up to 4 stops).
- **Orders are booked ahead.** When a trader plans a trip it places an order at every stop:
  - At a station it buys from, the goods are **held** for it. Nobody else can buy them, ship them or move them.
  - At a station it sells to, **room** is held so it is not turned away at the door.
  - The price is fixed when the order is placed. Money moves only as the goods move.
- **A station only grants what it can spare.** Its trade policy (Keep, Hold) and its queued builds come first.
- **Orders lapse.** A ship that has not arrived in good time (about 2.5 times its travel time, at least 5 minutes)
  loses its order and the goods are free again.
- **Orders are dropped** when the ship is destroyed, given another job, or can no longer get there (war, closed
  airspace, the station is gone). The trader then plans again with what it carries. It never keeps cargo forever:
  it sells it to the best buyer it knows, or takes it home.
- **Pirates and looting:** if held goods are taken, the order shrinks to what is left.
- **Your station's Trade drawer** shows:
  - each material's stock and how much of it is held for orders ("stock 300 (80 held)");
  - "Held for orders: 80 Gold (220 free)";
  - every order and expected delivery ("120 Iron on the way: Courier #4 (Free Traders) - lapses in 3:20"), each with
    **Cancel**. Cancelling another faction's order frees the goods; their trader plans again.
- **Your trade ship's inspector** has a **Trade route** section listing its stops; the current stop is marked.
- **Build your own route** in the Market:
  1. Select one or more trade ships.
  2. Open the Market (**F2**) and click an offer.
  3. Set the amount, then press **Add: buy here** or **Add: sell here**. Repeat for each stop.
  4. The route list shows each stop and the hold after it, and what a station cannot grant. It goes by what your
     ships last saw ("they can spare 300 when last seen 21:00 ago"), at the prices they saw.
  5. Press **Start route**. With several ships selected, each books what is left after the one before. The order is
     booked with what the stations have now; if that is less than was seen, the result says so ("they could spare
     300 when last seen 21:00 ago, fewer now").
- **Auto-trade** (the ship's standing orders) uses the same planner, within your stations' trade policies.
- **Three haulers:** the **Courier** (Small yard, 80 cargo, fast, cheap), the **Medium Freighter** (Medium yard,
  175 cargo, a little slower, no research needed) and the **Freighter** (Large yard, 300 cargo, slow, armed with a
  turret and a floating market other traders can sell to; needs **Bulk Freight**). Any of them runs trade routes,
  supply runs, buy orders and deliveries; the AI builds the biggest one it can afford and has the yard for.
- **Two miners and a barge:** the **Small Miner** (Small yard and Small bay, 75 cargo, speed 195), the **Miner** (Medium
  yard and bay, 100 cargo, speed 260) and the **Mining Barge** (Large, two drills, 250 cargo; needs **Bulk Mining**).
  The Small Miner and the Miner cut ore at the same rate. A ship docks only at a bay of its own size or bigger, so a
  station with only Small bays takes only the Small Miner. The AI builds the best miner its yard fits.

### Moving cargo between your own stations

- **How to open it:** select a ship with a cargo hold and press **C** (or **Transfer cargo...** in its inspector).
  The dialog starts at the station you last right-clicked, or the nearest one. From a station's **Trade** drawer,
  **Send to another station...** opens it there; the game then sends the nearest free hauler (or the cargo ship
  you have selected).
- **What you pick:** the From and To stations (**<** / **>**, **Swap**), an amount per material (**-** / **+**,
  **Max**), and the options:
  - **Repeat route** - keep shuttling until you stop it. With it come "Source keeps at least" and "Fill destination
    up to" (the route ends on its own when either is reached).
  - **As much as fits** - each trip fills the hold with the materials you marked.
  - **Ignore trade policy** - by default a transfer leaves what the source's trade policy keeps (a Buy or Sell
    target, everything on Hold) and what its queued builds need. Tick this to take it anyway.
  - **Queue after order** - the transfer waits until the ship's current order is done (like Shift for waypoints).
- **Several materials:** every material you list goes on every trip. If they do not all fit the hold, each one is
  cut in proportion and the dialog says so ("every material was cut to fit its hold: 40 Iron, 20 Titanium, 20
  Silicon").
- **What the ship does:** it flies to the source (through wormholes and gates it knows), docks, loads at the normal
  hauling rate, flies to the destination, docks and unloads. Its activity line says each step ("Transfer: loading 80
  Iron at Station #0 (40/80)"). If the source runs short it waits about 30 seconds, then leaves with what there is and
  the delivery line says so. What the source's trade policy or queued builds keep back is not waited for: the ship
  leaves at once, and the dialog and the delivery line say how much was kept and why ("Cinder Station kept 40
  Titanium back (trade policy or queued builds)").
- **To a construction site:** pick one of your sites as To. The dialog then shows the site's **bill** per material
  ("needs 120 more (80 on the way)"); a material the site does not need is greyed ("not needed by this site") and
  cannot be sent; **Max** takes what is still missing and not already on its way. There is no Repeat or "fill up to":
  the ship goes back and forth **until the site has everything** you listed, then stops by itself. A site has no
  docks, so the ship hands the goods over alongside it. If someone else delivered first, what is no longer needed goes
  back to the source ("60 Silicon was not needed and goes back to Cinder Station"); if the site is finished while the
  ship is on its way, the goods go into the new station's store.
- **The receiving station pays** the station the goods come from (the price sister stations pay each other); to a
  construction site your faction pool pays the source station. Every delivery gets a feed line ("Courier #4 delivered 80
  Iron to Station #12").
- **Stopping it:** **Stop this transfer route** in the ship's inspector, **Stop** in the dialog's list of your
  transfers or in the station's Trade drawer, or any new order to the ship. Cargo already aboard stays aboard.
- Automatic supply between your stations does not carry the goods straight back for 5 minutes after a delivery.
- **Your orders stick.** Once you have given a ship an order (a transfer, a move, anything) or flown it by hand, the
  automation never takes it over: the automatic supply runs (between stations and to construction sites) and
  automatic trade runs leave it alone, even when its job is done and it sits idle. Press **Clear orders** (X) on it
  to hand it back to the automation.
- **Auto-supply my stations off** at a station keeps its traders out of the automatic supply runs: none is taken for a run
  (not even for a queued build or a construction site), none waits idle for one, and a run not yet loading is dropped
  when you switch it off. Its surplus is not used to top other stations up either.
- A ship under manual control can be sent too: it carries the transfer and stays under manual control (it holds
  when the route is done).

- **Finding your routes:** the **Fleets** panel lists every transfer route with a **Stop** button, and a ship on a
  transfer has a **Transfer route** section at the top of its inspector (the route, what it is doing now and how to
  stop it).

### Ordering ships and wares from another station

A station can buy a ship from any station whose yard can build it - one of yours, or another faction's - and it can
buy a ware from another station and have it brought by a hauler. Both are paid from station to station: the buyer's
account pays the seller's account. Nothing is free and no money is made or lost on the way.

**Ordering a ship from another yard**

- Select the station that wants the ship and press **Build ships** in its **Build** tab. A station without a ship yard
  can press it too ("No ship yard here: Build ships orders them from another yard").
- At the top of the gallery, **Build at: this station** picks where the ship is built. Click it to go through every
  yard you may order from: your own yards first, then the yards of other factions your faction has charted and is not
  at war with, nearest first. It shows how many builds that yard has in hand.
- With another yard picked, each tile says that yard's answer: the price ("order: about 1,240 credits, paid when the
  build starts"), or why not ("Kestrel Reach builds and launches ships up to Small", "its makers cannot build it yet",
  "busy with 3 builds in hand"). Click a tile to place the order.
- **Price:** the ship's bill of materials at the yard's market prices plus the yard's labour, times 1.1 at your own
  yard or 1.4 at another faction's (both are tuning). The yard builds from its own stock and buys what it lacks, as it
  does for its own queue.
- **When you pay:** when the yard starts the build. An order waits in the yard's queue (first come, first served)
  until it is its turn, the yard has the materials, and your station can pay. A foreign yard takes no new order while
  it has 3 builds in hand.
- **Delivery:** the ship is yours. It launches from the yard's dock, flies to your station and makes it its home
  ("Courier #18, bought from Kestrel Reach for 420 credits, has arrived at Rook Spire").
- **Where to see it:** your station's Build tab lists "Ordered: Corvette from Kestrel Reach" with its state (queued,
  in the yard with its progress, on its way). The yard's own queue says "Corvette (Small) for Rook Spire".
- **Cancel:** the **x** on the row. A queued order costs nothing. One already in the yard is stopped; you get back
  what you paid less what the build used up that the yard could not get back (with the default cancel refunds,
  everything). A ship already on its way cannot be cancelled.

**Buying a ware with delivery (purchase orders)**

- In a station's **Trade** tab press **Order from another station...**. Pick the station it is delivered to, the ware,
  the station to buy from (your own stations first, then other factions' stations you have charted that sell it), and
  the amount. Each seller shows its price a unit, the delivery fee a unit and how much it can spare now.
- **What a seller sells:** only what it holds above what it keeps for itself. One of your stations keeps what the
  automatic supply keeps (its reserve, its factories' inputs, its queued builds, your trade policy); another faction's
  station sells what its market spares.
- **Price:** from your own station, the price your stations pay each other (half its market price); from another
  faction, its market's sell price. The station it is delivered to pays for what is actually loaded, as it is loaded.
- **Who carries it:** a free hauler with an empty hold - the seller's own first, then one from the station it goes to,
  then any of your haulers. It docks at both stations, as every ship does. Ships you have given orders to are never
  taken.
- **Delivery fee:** the station it goes to pays the hauler's home station 0.2 credits a unit plus 0.3 a unit for every
  10,000 of distance (tuning). Free when the hauler is the destination's own.
- **A short seller:** the order fills in parts as the seller has more to spare, for up to 30 minutes at the old pace, five hours at the shipped economy pace (`orders.purchaseExpiryMinutes` x `pace.economy`). Then it
  stops buying; what is aboard is still delivered.
- **Where to see it:** the Trade tab lists the purchase orders to and from the station ("120 of 300 delivered; 40 on
  the way; Courier #4 is carrying it to Rook Spire; buying for 22 more minutes; paid 96 credits + 30 delivery") with a
  **Cancel** button. The news says each delivery and when the order is done.
- **Cancel:** it buys nothing more; what is already aboard was paid for and is still delivered.

**Giving wares and ores to another faction (gifts of goods)**

- Open it from the **Diplomacy** screen (**Gift goods...**, under **Send gift: N cr**, with that faction picked) or
  from a station's **Trade** tab (**Gift to another faction...**, with that station giving).
- Pick the station that gives (one of yours), the ware or ore, the amount, a faction you have met and are not at war
  with, and one of its stations you have charted. The dialog says what it is worth to them and why it cannot be done
  when it cannot (not met, at war, no station of theirs charted, nothing to spare, no hauler that could carry it).
- **What a station gives:** only what it holds above what it keeps for itself (the same "spare" rule as a sale between
  your own stations). A short station gives in parts as it has more, for as long as a purchase order buys.
- **Who carries it:** a free hauler of yours with an empty hold, which docks at both stations. Theirs are never used.
- **Nobody pays anything:** no price, no delivery fee. No money is moved or made.
- **What it does:** as each unit is handed over, it counts like a gift of credits worth that unit at the receiving
  station's market buy price. 50 Steel that station buys at 6 credits is worth 300 credits, so it moves their opinion,
  goodwill, trust and alliance strain exactly as **Send gift: 300 cr** does. A station with no price for it gives no
  opinion.
- **Holds full:** the hauler waits in the bay and the gift's line says why ("Opal Yard's holds are full").
- **War, a station lost, cancel and running out of time** work as for a purchase order: war or a lost station ends it;
  Cancel and the time limit stop the loading, and what is aboard is still handed over.
- **Where to see it:** the dialog lists your gifts with **Cancel**; the giving station's Trade tab lists them too. The
  news says each delivery and the end, to both sides.
- **The AI gives goods too.** When an AI faction decides to send a gift (the same occasions and limits as its credit
  gifts) and its station can spare a ware that a station of yours it has charted posts a buy order for, it sends about
  300 credits' worth of that ware (tuning `strategy.giftCost`, valued at your station's buy price) with its own hauler
  instead of credits; the news names the giver. Goods that arrive simply join the station's stock.

## Diplomacy

- **F1** opens Diplomacy: every faction you have met, the state between you, what they think of you and why, and
  how strong they are compared with you - as far as you know: their strength is only the armed ships your ships,
  buoys and stations have seen in the last ten minutes or so ("not seen" when you have seen none). You have **met** a faction once your ships or stations have seen one of
  its stations or ships, or once you are at war, at truce or allied with it or it has sent you an offer; the others
  are one line, "4 factions not yet met".
- **Who is at war with whom.** A faction in a war you know of has a red **"at war"** under its name in the list
  (**"at war with you"** when it is your war). Select it and the line under its name says it plainly: **"AT WAR WITH
  YOU"** first when it is, then **"At war with: ..."** with each enemy's name in its colour (click a name to look at
  that faction), or **"Not at war with anyone you know of"**. Like the news, it only names enemies you have met: a war
  with a faction you have never met is not shown or hinted at. How long a war has run ("for 12:30") is shown for your
  own wars, and for theirs when you had met both sides by the time it began (you heard it declared).
- **You can only deal with factions you have met.** Declaring war, proposing peace or an alliance and sending a
  gift are refused for a faction your ships and stations have never come across, and the buttons say so ("You
  have not met them yet"). A faction that declares war on you has met you.
- **War is declared, never drifted into.** You fight only factions you are at war with. Declaring war needs a
  confirmation, and without a cause (a casus belli such as border friction) it costs you opinion with every other
  faction. The confirmation says who is stronger from what you have seen ("From what we have seen, they are about
  2.7 times stronger than you") and whether you know where any of their stations are. It never counts ships you have
  not seen: if you have seen none of their armed ships recently it says so plainly ("We have not seen any of their
  armed ships recently, so we cannot judge their strength"), so send a scout or lay a buoy first. The AI factions
  judge you the same way: only from what they have seen of your warships, and their CEO's judgement can be off.
- **Finding them:** you only know where a faction lives once your ships have seen one of its stations. A **Scout**
  explores on its own (see "Scouts" under Economy); right-click to send it somewhere yourself.
- **Peace** ends a war, and a **truce** then holds for a while.
- **How the war is going:** at war, Diplomacy shows the **war score** (ships lost and station hull lost on each side)
  and both sides' **exhaustion**. Their station damage in both is only what you have seen: the hull their stations had
  when your ships, buoys or stations last saw them ("War score, from what we have seen of their stations: ..."). A
  station you have never seen counts no damage, and the screen says so. The AI factions weigh peace the same way: from
  what they last saw of your stations.
- **Trust comes before an alliance: the ladder.** Agreements come in three rungs, and each needs the one below it:
  1. **Shared maps.** Each of you sees what the other has charted: stations, asteroids, wormholes and gates (never
     ships). A shared map does **not** share surveys: a rock you learn from their map is only spotted for you (ore
     unknown, not minable) until one of your own survey-radar ships passes it. They sign when they think well enough of you (traders need less). Stopping costs trust.
  2. **Defensive pact** (two and a half hours, renewable). Needs maps shared for 30 minutes and trust 20. If either of you is
     attacked, the other is called to defend: an AI with honour joins the war, one without refuses; you get an offer
     ("calls on your defensive pact") to accept (war on the attacker, a lot of trust) or decline (the pact ends and
     costs a lot of trust). Cancelling early costs trust too. When the term runs out it counts as completed and you can
     sign again.
  3. **Alliance** (permanent). Needs maps shared for 100 minutes, a defensive pact that ran its full term (or one
     defence honoured), trust 60, and the old gates (opinion, honour, no treachery, not at war with their allies).
- **Trust** (0 to 100) is what they think your word is worth, apart from how much they like you. It grows while maps
  are shared and a pact or alliance holds, with trade and gifts, while you fight a common enemy, and when a pact runs
  its term or you answer a call; it falls when you cancel, refuse a call, attack them, or declare war (all of it), and
  drifts back to 0 with no agreement. Factions without honour earn trust slowly. The Diplomacy screen shows it for the
  selected faction ("Trust: they trust you 34 / 100. Agreements: shared maps for 6 min; defensive pact, 9:12 left"),
  and what the next rung needs ("Next: Alliance - Not yet: they trust you 34 of the 60 an alliance needs."). The
  buttons are "Share maps" / "Stop sharing maps" and "Propose defensive pact" / "Cancel defensive pact"; a pact asks
  for confirmation first. The AI climbs the same ladder, one rung at a time, and offers you each rung.
- **An alliance binds you.** It is a defensive pact: if your ally is attacked, you are at war with the attacker
  at once - a notice pauses the game and tells you why - and if you are attacked, your allies join your war.
  Signing one asks for confirmation and says so first. "Propose alliance" can only be pressed when they would
  sign; otherwise it says why they would refuse ("Not yet: an alliance needs a defensive pact that ran its full term",
  "they remember your treachery", "you are at war with their ally
  Iron Dominion", "they hold a grievance against you (border friction)", "they do not think well enough of you
  (+12, they need +35)").
- **There is no limit on alliances.** You (and every AI faction) may hold as many as you can get. The Diplomacy
  screen lists each faction's allies ("Their allies: you, Iron Dominion, Free Traders"). Nobody signs with a faction
  at war with one of its allies, nor with a faction it holds a casus belli against. Declaring war asks for
  confirmation and names whose allies will join them, and which of your own allies (allied to you both) will stay
  out and end their alliance with you.
- **Allies really help.** An AI ally at war sends a fleet (keeping a home guard) to defend an allied station that
  is under attack: "An allied fleet from Solar Concord is on its way to your station #12". Allied ships repair at
  each other's stations.
- An ally that started a war itself does not drag you in, and an alliance binds direct partners only: your ally's
  other allies are not dragged into your wars. If two of your allies fight each other, you stay out of it and your
  alliance with the attacker ends (no treachery, no penalty); a notice pauses the game and says so.
- **Allies still mind their space.** Allied ships seen on your territory tiles (and yours on theirs) sour opinion
  too, at a quarter of the usual rate (an ally building into your tiles too), so allies competing for the same rocks slowly strain the alliance.
- **Allies are not a victory.** The game is won only when every other faction is eliminated. If every faction left is
  your ally, you have to break an alliance (treachery) and fight to finish the game.
- **An alliance has no end date.** It lasts until one of you ends it. The Diplomacy screen shows, for each ally,
  the **Standing of the alliance**: **Solid**, **Strained** or **On notice**, with the reasons (in the same list as
  their opinion of you, marked "alliance:") and what would help.
- **What strains an alliance:** their opinion of you falling low; you starting a war on a faction they are friendly
  with, or a war without a cause; you making a separate peace with an enemy they are still fighting; you breaking an
  alliance with someone else; and **not coming to their aid** - one of their stations is under attack by an enemy
  you are at war with, and for 3 minutes you neither send warships there nor destroy any of that enemy's ships.
- **What eases it:** destroying their enemies' ships, warships at (or a relief fleet sent to) their stations under
  attack, gifts, trade between you, and time without another incident. Honourable factions tolerate more strain.
- **Notice before they leave.** When the strain gets high, the ally gives notice: a News line ("Free Traders are
  reconsidering the alliance: you did not come to their aid at Kestrel Reach") and "On notice" on the Diplomacy
  screen. You then have at least 30 minutes to repair it; if the strain is still high after that, they leave in good
  order - no treachery for either side, a short truce, and no new alliance between you for 100 minutes.
- **Leaving an alliance yourself:** "Break alliance" (asks for confirmation) costs you opinion with that faction and
  hands it a casus belli; your other allies hold it against you too. Leaving an ally while it is under attack is
  desertion: every faction thinks less of you.
- **Gifts** of credits raise a faction's opinion of you; the slider sets the amount.
- **Offers:** AI factions offer peace and alliances and demand tribute (pay, or they declare war). They wait under
  "Offers waiting for your answer" with a timer. An offer you decline or let lapse is not repeated by that faction for 6 minutes, then 12, 24, up to 30 if you keep
  declining it (accepting one resets that). **Decline all** answers every waiting offer at once (a normal decline each).
- **Ignore their proposals** (top right of the selected faction): their peace, alliance, map and pact offers are declined
  at once, quietly, exactly as if you declined them (no other cost); their row says "(muted)". A call to defend your
  defensive pact and a tribute demand still come through, because ignoring those has consequences (the pact ends, war).
  "Stop ignoring them" undoes it. It is saved with the game.
- Every button that cannot be used says why next to it.

## Airspace

- **A faction's airspace is its territory:** the territory tiles it holds (see Territory under [The screen](#the-screen)).
  There are no airspace circles any more: a tile your station reaches but another faction holds (or that is contested)
  is not your airspace. Outposts and defence platforms claim tiles too; pirate hideouts do not (pirates ignore airspace
  and are always hostile).
- **You decide who may enter yours.** In **Diplomacy (F1)** select a faction; under **AIRSPACE** choose:
  - **Open**: any of their ships may enter.
  - **Civilian**: only their unarmed civil ships (traders, haulers, miners, constructors, salvage tugs) may enter.
    This keeps trade working while keeping warships and scouts out.
  - **Closed**: nothing of theirs may enter.
  Under the faction list, **Airspace for new contacts** is your default for every faction you have not set (it
  starts at Civilian). "They allow you" shows what that faction allows your ships.
- **Allies always have full access**, both ways, for as long as the alliance lasts (the buttons are locked). When
  an alliance ends, the old rule applies again. A faction at war with you is hostile anyway: airspace does not apply.
  Every ally does, however many you have. Shared maps and a defensive pact are NOT an alliance: they open no
  airspace (set the policy yourself). When your ships trespass in a faction's airspace, it trusts you less (more
  for armed ships), which slows the ladder.
- **Ships respect airspace by themselves.** Your automation and every AI faction plan their trips around airspace
  they may not enter (they fly round it, or stop at its edge), do not use wormholes or gates inside it, do not trade
  with a station inside it and do not mine rocks inside it. Only the tiles of stations your faction has found count, and
  never the tiles of a station that has one of your own stations within its reach.
- **When a rule tightens** (or an alliance ends), a ship already inside gets two minutes to leave and heads
  straight out.
- **Trespass.** A ship inside airspace it may not enter, once its two minutes are up (or at once if you ordered it
  in), is a trespasser: the owner hears of it, the trespasser's faction gets a warning, and the owner thinks a
  little less of that faction (more for a warship; it counts as border friction, which can lead to war). After a
  20-second warning the owner's station guns, defence platforms and warships may fire on it **without a war**.
- **Ordering your ship in anyway:** a move order into airspace closed to it goes ahead, but the news says so first
  ("Kestrel Reach airspace is closed to you: entering is trespass").
- **On the map:** the territory outline is the border. With the **Airspace** switch under the minimap (beside Rings,
  Routes and Names) on, a faction's outline gets a second line just inside it: **dashed amber** where only your civil
  ships may enter, **red** where it is closed to you (none where you may fly). A foreign station's inspector has an
  **Airspace** section that says what your ships may do there.

## Pirates

- **Pirate bands** are outlaws, not factions you can deal with. They are at war with every faction (yours too) from the
  start, they leave each other alone, and nothing can be negotiated: no war to declare, no peace, no alliance, no gift
  (Diplomacy says "Outlaws - no negotiation"). They never count for the standings, victory or defeat.
- **Their hideouts appear by themselves, at random, all game long** - after the first two and a half hours, a new hideout can turn
  up at any time, anywhere outside every station's scanner range, away from the other hideouts and the starting
  stations, near the traffic of a faction's stations, and never right under the eyes of anyone's sensors (it was there before you looked).
  You cannot time them. You know a hideout only once your sensors find it (its raiders may find you first; the feed says "A pirate
  hideout has been found: ..."); nobody announces a new one. The New game page's **Pirates** button sets how many bands
  may be about at once and how often new ones come: Off, Few, Normal (the Random galaxy default) or Many; a bigger galaxy
  has more. When a band is wiped out or breaks up, a new band (another name, another shade of red) can take its place
  later.
- **They live on loot.** A hideout's yard builds raiders, corvettes, salvage tugs and, once rich, a heavier ship, paid only
  with materials brought home: wrecks and cargo pods their tugs strip, cargo their raiders take from ships they destroy,
  and goods skimmed from stations. They never mine, trade or build stations. A band that brings home nothing for a long
  time breaks up: its hideout is abandoned and leaves a wreck.
- **What they do:** raiders hunt haulers, miners, tugs and lone ships they can see near their hideout, lie in wait near
  stations, run from stronger fleets and from station guns, and go home to unload and repair. Escort your haulers or keep
  warships near your miners in pirate country.
- **Fighting them:** your ships and station guns shoot pirates on sight; right-click a pirate ship to attack it. The AI
  factions send a strike force against a hideout they have found near their stations. Destroying a hideout ends its band
  (its ships fight on for a few minutes, then scatter) and leaves its hoard as a wreck worth salvaging.
- **Where you see them:** a notched-diamond map icon in the band's colour, a "Pirates" group in the Wars tab and in
  Diplomacy, the band's panel ("Pirate band - outlaws, live on salvage") and news lines when pirates destroy your ship,
  when you find a hideout and when one falls.

## Saving and loading

- **F5** quicksaves and **F8** loads the quicksave. The pause menu has **Save game** (with a name) and **Load
  game**; the main menu has **Continue** (your most recent save) and **Load game**.
- The game also **autosaves** every 5 minutes of play into 3 rotating slots, and when you quit. Both are set in
  **Settings**.
- A loaded game continues exactly as the original would have.
- A save made with mods says so in the load list and can switch to those mods.

### Sending a save to the developer

- Every save in the **Load game** / **Save game** list has a **Send to developer** button. The pause menu has
  **Send this game to the developer** (key `Ctrl+F12`): it first saves the game under a new name (`sent-` and the date
  and time; your own saves are never overwritten) and then sends that save.
- What is sent is one `.zip` file: the save, and a short `about.txt` with the game's version and build, the save
  format, your system, the mods in use and the last lines of `crash.log` (if there is one). A copy of the last ten
  is kept in the `Sent` folder of your SpaceFleet folder.
- The game sends nothing by itself: it runs a command **you** type in **Settings**, under **Sending saves**, in
  **Send saves with**. `{file}` in it is the full path of the `.zip`, `{name}` its file name. For example, to copy it
  with `scp` to a machine of yours: `scp -o BatchMode=yes {file} you@yourmachine:/some/folder/` (`BatchMode=yes`
  makes it fail at once instead of waiting for a password nobody can type). The command is run as a program with its
  arguments, not through a shell, so a path with spaces stays one argument; use quotes to keep words together.
- The banner says **Sent <save>** when the command worked, or **Sending failed:** and the first line of its error;
  the whole error is written to the game's log. A command that takes more than 60 seconds is stopped.
- While **Send saves with** is empty, sending is off: the button opens Settings at that field and says what to type.
- Without the game: `tools/send-saves.sh` (Linux, in the source repository) sends your newest save, or all of them,
  with `scp` to a destination you give it.

## Settings

- **Display:** window mode (windowed, borderless, exclusive fullscreen), window size (it reads **Maximized** while the
  window is maximized, and a size chosen there or with `F10` un-maximizes it first; sizes too big for the screen are
  skipped; borderless always covers the screen, and exclusive fullscreen shows the size the screen really uses: most
  Linux desktops on Wayland do not allow a video mode change), vertical sync, and **combat
  effects** (High, Low or Off): when a shot hits a shield, a curved flare lights the shield bubble on the side the shot
  came from (brighter and wider for a heavier hit; the whole bubble shimmers when the shield is nearly gone), a
  shield knocked down pops with a crackling ring and fades back in when it has recharged, and hull hits throw sparks
  and leave a brief scorch glow. Low keeps only the flares and sparks; Off hides them (shots and explosions still
  show). They only show zoomed in far enough to see ships, never on the strategic map.
- **Interface:** interface size (75% to 200%), **interface opacity** (40% to 100%: how solid the panels over the
  map are - lower lets the map and the background show through; text, borders and bars stay solid; the pause menu
  and other full screens never go below 85%) and the frame-rate readout.
- **Audio:** master and effects volume, mute.
- **Your faction:** the colour of your own faction, as a row of swatches under Audio. In a game it recolours that game
  at once - your ships, station blocks, map icons, labels, the minimap - and is saved with the game, so it comes back
  when you load it. From the main menu it sets the colour your next new game starts with (the New game page has the
  same swatches). Red is never offered. Watching the AI play (no faction of your own) has no colour to pick.
- **Saving:** autosave on or off, how often and how many files to keep.
- **Sending saves:** **Send saves with**, the command that sends a save to the developer (see
  [Sending a save to the developer](#sending-a-save-to-the-developer)); empty = off.
- **Camera:** edge scrolling, pan speed and zoom speed.
- **Game:** the speed a new game starts at; **Fast-forward may drop FPS** (on by default): when you play faster
  than 1x and your computer cannot keep up, the game lets the picture drop toward 30 frames a second (20 at 8x and
  faster) and gives the time to the world, so it runs closer to the speed you chose; vertical sync is released while
  that happens so no time is spent waiting for the monitor. Turn it off to keep the picture smooth and let the
  world run slower instead. 1x is never affected. When the world falls short, the top bar says so next to the
  speed (for example "4x" and "running at 2.6x"). Above 1x the world also runs on a processor core of its own while
  the picture is being drawn, so fast-forward keeps a smooth picture for longer before it has to give anything up;
  the picture then shows the world about one frame behind the clock, which you will not notice. 1x runs exactly as
  it always has. **Simulation threads**: how many processor cores the simulation may use for each step of the world
  ("Automatic" = 4, fewer on a small processor); more cores can make fast-forward faster in a big universe, and the
  game plays out the same either way.
- **Background:** the space behind the map.
  - **Background detail:** High (the default) and Low paint a deep-space sky for every game - nebulae, distant
    planets, galaxies, star clusters, now and then a sun or a comet - different for every galaxy and the same again
    when you load a save. Off shows the plain stars of older versions. Low uses about half the memory.
  - **Background brightness:** 25% to 150%. The sky also dims by itself as you zoom out to the whole map, so icons
    and labels stay readable (in a modded regional world each region has its own cloud and the gulfs are darker).
  - **Background animation:** twinkling stars, very slowly drifting clouds and the odd shooting star. Off keeps the
    background perfectly still.
  - The main menu shows a new sky each time the game starts.
- **News** (the **News...** button at the bottom of Settings): one row for every kind of news, grouped like the News
  panel's filters (Diplomacy first, then War, Economy, Other), with three controls each. The rows scroll.
  - **Show (On / Off):** Off keeps that kind out of the News panel. It then plays no sound and never pauses the game.
    Switch it On again and new lines of that kind show from then on (what came while it was Off is not brought
    back). An alarm-type piece of news that is switched Off still counts on the top bar's **Alerts** button and
    still pings the minimap. Offers can still be answered on the **Diplomacy** screen ("1 offer" on the top bar)
    when "Offer made to you" is Off. In a new setup **Salvage recovered** is **Off**; every other kind is On.
  - **Sound:** click it to open a list: **Usual** (the sound the game has always played for it: an alarm, a chime, or
    nothing - the button says which), **None**, or one of the news sounds (Alarm, Chime, Blip, Ping, Bell, Low tone,
    Triple beep). The sound you pick plays once so you can hear it; the list stays open so you can try others, and
    **Close** (or Esc, or the Sound button again) shuts it. A sound you pick plays for every line of that kind that
    reaches the News panel. The volume follows the Master and Effects volume settings. Mods can add news sounds.
  - **Pause (On / Off):** the game can pause itself when news reaches you, so you do not miss an offer while time
    runs fast (an offer still lapses after a minute of game time if you do not answer it). In a new setup the
    **Diplomacy** kinds are **On** (offers, answers, gifts, peace, truces, pacts, treaties, alliance notices, airspace
    policies, opinion changes) and every other kind is **Off**. A war declared, and an ally joining a war or standing
    aside, count as diplomacy and pause by default too.
  - Show, Sound and Pause are saved in `settings.json` and count for every game.
  - **Pause: factions (this game):** under the kinds, in a game, every faction you have met has a pause switch too. A
    faction switched **Off** never pauses the game, whatever the kind of news; switch it **On** again to undo that.
    These switches are saved with the game (not in `settings.json`).
  - The pause rule: a news line pauses the game when its kind is shown, its Pause is **On** and none of the other
    factions it names is switched **Off**. News that names no other faction follows its kind alone. Watching the AI
    play (no faction of your own) never pauses.
  - The pause is the ordinary pause: press the pause key (or the top bar's pause button) to go on. A banner at the top
    says **Paused:** and the news line, and the line is in the News panel as usual. Each piece of news pauses once;
    news that comes in while the game is already paused does nothing more. A running fight's line ("You lost 3 ships
    ...") pauses only when it first appears, not each time its count goes up.
- Changes apply at once and are saved straight away in `settings.json`.

## Mods

- **Mods...** on the main menu (or in Settings, from the main menu) opens the mod manager. Tick a mod to enable it,
  use **Up** / **Down** to change the load order and press **Apply**. A later mod wins where two change the same thing.
- Mods are found in the game's `Mods` folder, in your own `Mods` folder (see below) and in the folder named by the
  `SPACEFLEET_MODS` environment variable (those are always on).
- The game ships these example mods (all off until you enable them):
  - **Faster Economy** - ore sells, cargo moves and ships and stations build faster.
  - **Helium-3 and Railguns** - an 11th material and a second weapon.
  - **Gunship** - a new warship with its own hull, weapon and sprite.
  - **Frontier Worlds** - a seventh faction type, two world presets, a richer starting kit, two more objectives and a
    frontier sky (its own background colours and a nebula picture).
  - **Prefab Docks** - a cheaper dock and a faster ship yard next to the standard ones.
  - **Short-hop Gates** - a cheaper jump gate that reaches only 60,000 units, and a world with sixteen wormhole pairs.
  - **Salvage Contracts** - a code mod: clearing a wreck or cargo pod completely pays a cleanup bounty into your
    capital. Code mods run their own program, so they load only when you tick **Allow code mods**, and this one has
    to be built first (see its README).
- Making a mod: [MODDING.md](MODDING.md).

## Developer cheats (Dev tools)

For testing, building mods and poking at the world. On in any build made from the source (the Linux launcher, `dotnet run`); a public zip made for friends hides it unless the game is started with `--dev`. Settings > Developer cheats can turn it off. Using any cheat puts a "cheats used" mark on the
game: it shows on the Dev tools panel and the pause menu, and it is saved with the game.

- **Turn it on:** nothing to do in a build from source (Settings > Developer cheats must be on, as it is by default). In a public zip, start the game with `--dev`.
- **Open it:** the backquote key (`` ` ``) or the DEV button in the top bar. Escape closes the panel first.
- **The panel:** seven tabs (Economy, Research, Ships, Stations, World, Diplomacy, Views). Each row has preset
  buttons, boxes for its settings (the arrow buttons cycle the choices) and a Run or On / Off button. Hover a row to
  read its help. The panel can dock left or right and be dragged by its header.
- **The console:** the box at the bottom of the panel. Enter runs a line, Up / Down recall earlier lines, Escape
  leaves the box. `help` lists the commands and `help <command>` explains one. While you type, game hotkeys are muted.
- **Numbers:** `5k`, `2.5m`, `x10`, `50%` and `1,000` all work (a dot is always the decimal point). Factions are
  `me`, `enemy`, `any`, a number, or a name (a prefix is enough).
- **Cheats act on:** the selection (ships or a station), the point under the mouse cursor, or your faction.
  Things that finish "on the next tick" (finish, sites, module) need a step while the game is paused.
- **From outside:** every cheat also runs from the debug server: `/control/cheat?do=<id>&args=...` (`do=line&text=`
  runs a console line). See `CLAUDE.md`.

| Tab | Console command | What it does |
|---|---|---|
| Economy | `credits [amount]` (`money`, `cash`) | Adds credits to the selected station or your capital |
| Economy | `materials [amount\|fill\|empty] [material\|all]` (`mat`) | Adds to, fills or empties the store |
| Economy | `freebuilds [on\|off]` (`free`) | Your builds cost nothing |
| Economy | `instant [on\|off\|N]` (`buildspeed`) | Builds and research at once, or N times faster |
| Economy | `finish` | Finishes the selected station's ship build and module, or the selected site |
| Research | `tech [id\|name\|all]` (`grant`) | Grants a technology (default: the one selected in the Research screen) |
| Research | `researchclear` | Empties your research queue |
| Research | `researchrate [x]` | Multiplies your research points |
| Ships | `spawn [ship] [count] [me\|enemy\|any\|N\|name]` | Spawns ships at the cursor; your own designs work too |
| Ships | `dup [copies]` (`duplicate`) | Duplicates the selected ships |
| Ships | `heal` (`repair`) | Full hull and shield |
| Ships | `hull [%]` | Sets the hull percentage |
| Ships | `refill` | Refills missiles and shields |
| Ships | `tp` (`teleport`) | Moves the selected ships to the cursor |
| Ships | `owner [faction]` | Gives the selected ships to another faction |
| Ships | `kill` (`destroy`) | Destroys what is selected; it leaves a wreck |
| Ships | `god [on\|off]` (`invulnerable`) | Your ships and stations take no damage |
| Stations | `station [template] [faction]` | Founds and finishes a station at the cursor |
| Stations | `gate [gate] [faction]` (`jumpgate`) | Puts a finished jump gate at the cursor |
| Stations | `sites` | Finishes all your construction sites |
| Stations | `module [id] [size]` | Adds a module to the selected station |
| Stations | `killstation` | Destroys the selected station |
| World | `reveal` | Charts every station, portal and asteroid for your faction |
| World | `survey` | Your faction knows what every asteroid holds |
| World | `meet` | Your faction has met everyone |
| World | `camera [x y [zoom] \| cursor \| selected \| home]` (`cam`, `goto`) | Moves the camera |
| World | `speed [x]` | Game speed, up to x64 |
| World | `step [n]` | Advances n ticks at once |
| Diplomacy | `war a b`, `peace a b`, `truce a b`, `ally a b` (`alliance`) | Sets the state between any two factions |
| Diplomacy | `opinion a b value` | Sets an opinion, -100 to 100 |
| Diplomacy | `accept` | The AI accepts your next peace or alliance proposal |
| Diplomacy | `play faction` (`playas`) | Take over another faction (hot seat) |
| Diplomacy | `observe` | Hand your faction to the AI and watch |
| Views | `debugview` (`f3`), `aiview` (`ai`), `sensors`, `docking`, `perf` (`fps`) | Toggle the views and overlays |
| Views | `dump` | Writes the debug state to `SpaceFleet/dev/` |
| Views | `save [name]` | Writes a save named `dev-<time>` (or the name given) |
| Views | `help [command]` (`?`) | Lists or explains commands |

Known limits: `reveal` charts but cannot make a faction forget; "play as" reloads the world from memory (the sky is
repainted a little differently and the unsaved-progress counter resets); a construction site still needs a
constructor at work unless `instant` is on.

## Where things are kept

Everything lives in the `SpaceFleet` folder of your user settings directory: `~/.config/SpaceFleet` on Linux
(or `$XDG_CONFIG_HOME/SpaceFleet`) and `%APPDATA%\SpaceFleet` on Windows.

| What | Where |
|---|---|
| Settings | `SpaceFleet/settings.json` |
| Key bindings | `SpaceFleet/keybindings.json` |
| Saves | `SpaceFleet/Saves/` |
| Your mods | `SpaceFleet/Mods/` |
| Which mods are on, and their order | `SpaceFleet/mods.json` |
