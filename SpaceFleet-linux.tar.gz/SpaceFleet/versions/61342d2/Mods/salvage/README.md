# Salvage Contracts — the example code mod

The base game has salvage of its own (since G29): every destroyed ship leaves a **wreck**, a ship that was
carrying cargo also drops a **cargo pod**, and ships with a **tractor beam** strip them into their holds. This mod
builds on that mechanic instead of copying it: whoever clears a wreck or pod **completely** is paid a cleanup
**bounty** into their capital. A licensed Salvage Tug earns 50% more, and the Voidborn Raiders run salvage yards
that pay 50% more again.

It changes rules the base game cannot express in data, so it ships **code**: two plugin assemblies that you build
from the source in `src/`. The full guide is the "Code mods" chapter of `docs/MODDING.md`.

## Build it

From the repository root:

```
dotnet build content/examples/salvage/src/Salvage.Game -c Release
dotnet build SpaceFleet.slnx -c Release
```

- The first command builds both plugins and copies `Salvage.dll` (the simulation plugin) and `Salvage.Game.dll`
  (the frontend plugin) into this folder, next to `pack.json`. They are build products and are not committed.
- The second builds the game, which copies this folder (without `src/`) into its `Mods` folder.
- Only want the rules, for the headless harness? `dotnet build content/examples/salvage/src/Salvage -c Release`.

## Turn it on

In the game: **Mods...** on the startup screen, tick **Allow code mods**, tick **Salvage Contracts**, press
**Apply**. A code mod runs its own program on your computer, which is why it needs that second tick.

Headless:

```
mkdir /tmp/salvage-only && ln -s "$PWD/content/examples/salvage" /tmp/salvage-only/salvage
SPACEFLEET_MODS=/tmp/salvage-only SPACEFLEET_ALLOW_CODE_MODS=1 \
  dotnet run --project src/SpaceFleet.Harness -c Release -- playtest 18000 7
```

## What is in here

| File | What it is |
|---|---|
| `pack.json` | The manifest: `plugins`, `gamePlugins`, `apiVersion`. |
| `tuning.json` | The mod's own numbers, under `mods.salvage`: bounty per unit, station-wreck factor, jitter, ranges. |
| `ships.json` | Licenses the Salvage Tug (`extensions.salvage`). |
| `factions.json` | Gives the Voidborn Raiders a salvage yard (`extensions.salvage`). |
| `behaviours/bounty-hunter.json` | A utility tree using the mod's leaves (no ship uses it out of the box). |
| `src/Salvage/` | The simulation plugin: components, two systems, leaves, hooks, an event subscriber, hash, read-model. |
| `src/Salvage.Game/` | The frontend plugin: bounty markers, a HUD panel, an inspector drawer, **F7** = next wreck. |

Change the numbers in `tuning.json` without rebuilding anything; change the code and rebuild, then press
**Apply** on the Mods screen (or restart the game).
