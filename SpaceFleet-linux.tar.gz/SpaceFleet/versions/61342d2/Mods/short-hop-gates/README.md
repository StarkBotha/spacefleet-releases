# Short-hop Gates (example mod, G23)

Shows the two G23 tables a pack can extend:

- `jump-gates.json` adds a **Short-hop Gate**: half the price and build time of the core Jump Gate, weaker, and its
  link reaches only 60,000 units (`range`). It needs the core `jump-gates` technology.
- `world.json` adds the **Wormhole Maze** preset: the regional galaxy with sixteen wormhole pairs and narrower
  gulfs.

A pack can also draw gates and wormholes itself: a gate entry's `"sprite": "<name>"` uses `sprites/<name>.png`, and
`sprites/wormhole.png` replaces the procedural wormhole (the last pack that has one wins).
